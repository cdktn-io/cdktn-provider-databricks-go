/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#browse_only Catalog#browse_only}
    */
    readonly browseOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#comment Catalog#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#connection_name Catalog#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#custom_max_retention_hours Catalog#custom_max_retention_hours}
    */
    readonly customMaxRetentionHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#enable_predictive_optimization Catalog#enable_predictive_optimization}
    */
    readonly enablePredictiveOptimization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#force_destroy Catalog#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#id Catalog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#isolation_mode Catalog#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#metastore_id Catalog#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#name Catalog#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#options Catalog#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#owner Catalog#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#properties Catalog#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#provider_name Catalog#provider_name}
    */
    readonly providerName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#share_name Catalog#share_name}
    */
    readonly shareName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#storage_root Catalog#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * effective_predictive_optimization_flag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#effective_predictive_optimization_flag Catalog#effective_predictive_optimization_flag}
    */
    readonly effectivePredictiveOptimizationFlag?: CatalogEffectivePredictiveOptimizationFlag;
    /**
    * managed_encryption_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#managed_encryption_settings Catalog#managed_encryption_settings}
    */
    readonly managedEncryptionSettings?: CatalogManagedEncryptionSettings;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#provider_config Catalog#provider_config}
    */
    readonly providerConfig?: CatalogProviderConfig;
    /**
    * provisioning_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#provisioning_info Catalog#provisioning_info}
    */
    readonly provisioningInfo?: CatalogProvisioningInfo;
}
export interface CatalogEffectivePredictiveOptimizationFlag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#inherited_from_name Catalog#inherited_from_name}
    */
    readonly inheritedFromName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#inherited_from_type Catalog#inherited_from_type}
    */
    readonly inheritedFromType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#value Catalog#value}
    */
    readonly value: string;
}
export declare function catalogEffectivePredictiveOptimizationFlagToTerraform(struct?: CatalogEffectivePredictiveOptimizationFlagOutputReference | CatalogEffectivePredictiveOptimizationFlag): any;
export declare function catalogEffectivePredictiveOptimizationFlagToHclTerraform(struct?: CatalogEffectivePredictiveOptimizationFlagOutputReference | CatalogEffectivePredictiveOptimizationFlag): any;
export declare class CatalogEffectivePredictiveOptimizationFlagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogEffectivePredictiveOptimizationFlag | undefined;
    set internalValue(value: CatalogEffectivePredictiveOptimizationFlag | undefined);
    private _inheritedFromName?;
    get inheritedFromName(): string;
    set inheritedFromName(value: string);
    resetInheritedFromName(): void;
    get inheritedFromNameInput(): string | undefined;
    private _inheritedFromType?;
    get inheritedFromType(): string;
    set inheritedFromType(value: string);
    resetInheritedFromType(): void;
    get inheritedFromTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface CatalogManagedEncryptionSettingsAzureEncryptionSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#azure_cmk_access_connector_id Catalog#azure_cmk_access_connector_id}
    */
    readonly azureCmkAccessConnectorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#azure_cmk_managed_identity_id Catalog#azure_cmk_managed_identity_id}
    */
    readonly azureCmkManagedIdentityId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#azure_tenant_id Catalog#azure_tenant_id}
    */
    readonly azureTenantId: string;
}
export declare function catalogManagedEncryptionSettingsAzureEncryptionSettingsToTerraform(struct?: CatalogManagedEncryptionSettingsAzureEncryptionSettingsOutputReference | CatalogManagedEncryptionSettingsAzureEncryptionSettings): any;
export declare function catalogManagedEncryptionSettingsAzureEncryptionSettingsToHclTerraform(struct?: CatalogManagedEncryptionSettingsAzureEncryptionSettingsOutputReference | CatalogManagedEncryptionSettingsAzureEncryptionSettings): any;
export declare class CatalogManagedEncryptionSettingsAzureEncryptionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogManagedEncryptionSettingsAzureEncryptionSettings | undefined;
    set internalValue(value: CatalogManagedEncryptionSettingsAzureEncryptionSettings | undefined);
    private _azureCmkAccessConnectorId?;
    get azureCmkAccessConnectorId(): string;
    set azureCmkAccessConnectorId(value: string);
    resetAzureCmkAccessConnectorId(): void;
    get azureCmkAccessConnectorIdInput(): string | undefined;
    private _azureCmkManagedIdentityId?;
    get azureCmkManagedIdentityId(): string;
    set azureCmkManagedIdentityId(value: string);
    resetAzureCmkManagedIdentityId(): void;
    get azureCmkManagedIdentityIdInput(): string | undefined;
    private _azureTenantId?;
    get azureTenantId(): string;
    set azureTenantId(value: string);
    get azureTenantIdInput(): string | undefined;
}
export interface CatalogManagedEncryptionSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#azure_key_vault_key_id Catalog#azure_key_vault_key_id}
    */
    readonly azureKeyVaultKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#customer_managed_key_id Catalog#customer_managed_key_id}
    */
    readonly customerManagedKeyId?: string;
    /**
    * azure_encryption_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#azure_encryption_settings Catalog#azure_encryption_settings}
    */
    readonly azureEncryptionSettings?: CatalogManagedEncryptionSettingsAzureEncryptionSettings;
}
export declare function catalogManagedEncryptionSettingsToTerraform(struct?: CatalogManagedEncryptionSettingsOutputReference | CatalogManagedEncryptionSettings): any;
export declare function catalogManagedEncryptionSettingsToHclTerraform(struct?: CatalogManagedEncryptionSettingsOutputReference | CatalogManagedEncryptionSettings): any;
export declare class CatalogManagedEncryptionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogManagedEncryptionSettings | undefined;
    set internalValue(value: CatalogManagedEncryptionSettings | undefined);
    private _azureKeyVaultKeyId?;
    get azureKeyVaultKeyId(): string;
    set azureKeyVaultKeyId(value: string);
    resetAzureKeyVaultKeyId(): void;
    get azureKeyVaultKeyIdInput(): string | undefined;
    private _customerManagedKeyId?;
    get customerManagedKeyId(): string;
    set customerManagedKeyId(value: string);
    resetCustomerManagedKeyId(): void;
    get customerManagedKeyIdInput(): string | undefined;
    private _azureEncryptionSettings;
    get azureEncryptionSettings(): CatalogManagedEncryptionSettingsAzureEncryptionSettingsOutputReference;
    putAzureEncryptionSettings(value: CatalogManagedEncryptionSettingsAzureEncryptionSettings): void;
    resetAzureEncryptionSettings(): void;
    get azureEncryptionSettingsInput(): CatalogManagedEncryptionSettingsAzureEncryptionSettings | undefined;
}
export interface CatalogProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#workspace_id Catalog#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function catalogProviderConfigToTerraform(struct?: CatalogProviderConfigOutputReference | CatalogProviderConfig): any;
export declare function catalogProviderConfigToHclTerraform(struct?: CatalogProviderConfigOutputReference | CatalogProviderConfig): any;
export declare class CatalogProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogProviderConfig | undefined;
    set internalValue(value: CatalogProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface CatalogProvisioningInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#state Catalog#state}
    */
    readonly state?: string;
}
export declare function catalogProvisioningInfoToTerraform(struct?: CatalogProvisioningInfoOutputReference | CatalogProvisioningInfo): any;
export declare function catalogProvisioningInfoToHclTerraform(struct?: CatalogProvisioningInfoOutputReference | CatalogProvisioningInfo): any;
export declare class CatalogProvisioningInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogProvisioningInfo | undefined;
    set internalValue(value: CatalogProvisioningInfo | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog databricks_catalog}
*/
export declare class Catalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_catalog";
    /**
    * Generates CDKTN code for importing a Catalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Catalog to import
    * @param importFromId The id of the existing Catalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Catalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/catalog databricks_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CatalogConfig);
    private _browseOnly?;
    get browseOnly(): boolean | cdktn.IResolvable;
    set browseOnly(value: boolean | cdktn.IResolvable);
    resetBrowseOnly(): void;
    get browseOnlyInput(): boolean | cdktn.IResolvable | undefined;
    get catalogType(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    get createdAt(): number;
    get createdBy(): string;
    private _customMaxRetentionHours?;
    get customMaxRetentionHours(): number;
    set customMaxRetentionHours(value: number);
    resetCustomMaxRetentionHours(): void;
    get customMaxRetentionHoursInput(): number | undefined;
    private _enablePredictiveOptimization?;
    get enablePredictiveOptimization(): string;
    set enablePredictiveOptimization(value: string);
    resetEnablePredictiveOptimization(): void;
    get enablePredictiveOptimizationInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get fullName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _providerName?;
    get providerName(): string;
    set providerName(value: string);
    resetProviderName(): void;
    get providerNameInput(): string | undefined;
    get securableType(): string;
    private _shareName?;
    get shareName(): string;
    set shareName(value: string);
    resetShareName(): void;
    get shareNameInput(): string | undefined;
    get storageLocation(): string;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    get updatedAt(): number;
    get updatedBy(): string;
    private _effectivePredictiveOptimizationFlag;
    get effectivePredictiveOptimizationFlag(): CatalogEffectivePredictiveOptimizationFlagOutputReference;
    putEffectivePredictiveOptimizationFlag(value: CatalogEffectivePredictiveOptimizationFlag): void;
    resetEffectivePredictiveOptimizationFlag(): void;
    get effectivePredictiveOptimizationFlagInput(): CatalogEffectivePredictiveOptimizationFlag | undefined;
    private _managedEncryptionSettings;
    get managedEncryptionSettings(): CatalogManagedEncryptionSettingsOutputReference;
    putManagedEncryptionSettings(value: CatalogManagedEncryptionSettings): void;
    resetManagedEncryptionSettings(): void;
    get managedEncryptionSettingsInput(): CatalogManagedEncryptionSettings | undefined;
    private _providerConfig;
    get providerConfig(): CatalogProviderConfigOutputReference;
    putProviderConfig(value: CatalogProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): CatalogProviderConfig | undefined;
    private _provisioningInfo;
    get provisioningInfo(): CatalogProvisioningInfoOutputReference;
    putProvisioningInfo(value: CatalogProvisioningInfo): void;
    resetProvisioningInfo(): void;
    get provisioningInfoInput(): CatalogProvisioningInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
