/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#binding_type WorkspaceBinding#binding_type}
    */
    readonly bindingType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#catalog_name WorkspaceBinding#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#id WorkspaceBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#securable_name WorkspaceBinding#securable_name}
    */
    readonly securableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#securable_type WorkspaceBinding#securable_type}
    */
    readonly securableType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#workspace_id WorkspaceBinding#workspace_id}
    */
    readonly workspaceId: number;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#provider_config WorkspaceBinding#provider_config}
    */
    readonly providerConfig?: WorkspaceBindingProviderConfig;
}
export interface WorkspaceBindingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#workspace_id WorkspaceBinding#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceBindingProviderConfigToTerraform(struct?: WorkspaceBindingProviderConfigOutputReference | WorkspaceBindingProviderConfig): any;
export declare function workspaceBindingProviderConfigToHclTerraform(struct?: WorkspaceBindingProviderConfigOutputReference | WorkspaceBindingProviderConfig): any;
export declare class WorkspaceBindingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceBindingProviderConfig | undefined;
    set internalValue(value: WorkspaceBindingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding databricks_workspace_binding}
*/
export declare class WorkspaceBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_binding";
    /**
    * Generates CDKTN code for importing a WorkspaceBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceBinding to import
    * @param importFromId The id of the existing WorkspaceBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_binding databricks_workspace_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceBindingConfig
    */
    constructor(scope: Construct, id: string, config: WorkspaceBindingConfig);
    private _bindingType?;
    get bindingType(): string;
    set bindingType(value: string);
    resetBindingType(): void;
    get bindingTypeInput(): string | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _securableName?;
    get securableName(): string;
    set securableName(value: string);
    resetSecurableName(): void;
    get securableNameInput(): string | undefined;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    resetSecurableType(): void;
    get securableTypeInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    get workspaceIdInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): WorkspaceBindingProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceBindingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): WorkspaceBindingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
