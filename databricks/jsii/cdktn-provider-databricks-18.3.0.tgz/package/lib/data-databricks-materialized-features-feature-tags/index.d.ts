/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMaterializedFeaturesFeatureTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#feature_name DataDatabricksMaterializedFeaturesFeatureTags#feature_name}
    */
    readonly featureName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#page_size DataDatabricksMaterializedFeaturesFeatureTags#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#provider_config DataDatabricksMaterializedFeaturesFeatureTags#provider_config}
    */
    readonly providerConfig?: DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#table_name DataDatabricksMaterializedFeaturesFeatureTags#table_name}
    */
    readonly tableName: string;
}
export interface DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#workspace_id DataDatabricksMaterializedFeaturesFeatureTags#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfigToTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfigToHclTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMaterializedFeaturesFeatureTagsFeatureTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#key DataDatabricksMaterializedFeaturesFeatureTags#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#provider_config DataDatabricksMaterializedFeaturesFeatureTags#provider_config}
    */
    readonly providerConfig?: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig;
}
export declare function dataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsToTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTags): any;
export declare function dataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsToHclTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTags): any;
export declare class DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMaterializedFeaturesFeatureTagsFeatureTags | undefined;
    set internalValue(value: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsProviderConfig | undefined;
    get value(): string;
}
export declare class DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMaterializedFeaturesFeatureTagsFeatureTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsOutputReference;
}
export interface DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#workspace_id DataDatabricksMaterializedFeaturesFeatureTags#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMaterializedFeaturesFeatureTagsProviderConfigToTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMaterializedFeaturesFeatureTagsProviderConfigToHclTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMaterializedFeaturesFeatureTagsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags databricks_materialized_features_feature_tags}
*/
export declare class DataDatabricksMaterializedFeaturesFeatureTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_materialized_features_feature_tags";
    /**
    * Generates CDKTN code for importing a DataDatabricksMaterializedFeaturesFeatureTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMaterializedFeaturesFeatureTags to import
    * @param importFromId The id of the existing DataDatabricksMaterializedFeaturesFeatureTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMaterializedFeaturesFeatureTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/materialized_features_feature_tags databricks_materialized_features_feature_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMaterializedFeaturesFeatureTagsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMaterializedFeaturesFeatureTagsConfig);
    private _featureName?;
    get featureName(): string;
    set featureName(value: string);
    get featureNameInput(): string | undefined;
    private _featureTags;
    get featureTags(): DataDatabricksMaterializedFeaturesFeatureTagsFeatureTagsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMaterializedFeaturesFeatureTagsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMaterializedFeaturesFeatureTagsProviderConfig | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
