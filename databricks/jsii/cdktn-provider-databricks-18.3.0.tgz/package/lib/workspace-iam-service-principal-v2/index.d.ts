/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceIamServicePrincipalV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2#account_sp_status WorkspaceIamServicePrincipalV2#account_sp_status}
    */
    readonly accountSpStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2#application_id WorkspaceIamServicePrincipalV2#application_id}
    */
    readonly applicationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2#display_name WorkspaceIamServicePrincipalV2#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2#external_id WorkspaceIamServicePrincipalV2#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2#provider_config WorkspaceIamServicePrincipalV2#provider_config}
    */
    readonly providerConfig?: WorkspaceIamServicePrincipalV2ProviderConfig;
}
export interface WorkspaceIamServicePrincipalV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2#workspace_id WorkspaceIamServicePrincipalV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceIamServicePrincipalV2ProviderConfigToTerraform(struct?: WorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceIamServicePrincipalV2ProviderConfigToHclTerraform(struct?: WorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceIamServicePrincipalV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2 databricks_workspace_iam_service_principal_v2}
*/
export declare class WorkspaceIamServicePrincipalV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_iam_service_principal_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceIamServicePrincipalV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceIamServicePrincipalV2 to import
    * @param importFromId The id of the existing WorkspaceIamServicePrincipalV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceIamServicePrincipalV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_service_principal_v2 databricks_workspace_iam_service_principal_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceIamServicePrincipalV2Config
    */
    constructor(scope: Construct, id: string, config: WorkspaceIamServicePrincipalV2Config);
    get accountId(): string;
    private _accountSpStatus?;
    get accountSpStatus(): string;
    set accountSpStatus(value: string);
    get accountSpStatusInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    resetApplicationId(): void;
    get applicationIdInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): WorkspaceIamServicePrincipalV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceIamServicePrincipalV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceIamServicePrincipalV2ProviderConfig | undefined;
    get servicePrincipalId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
