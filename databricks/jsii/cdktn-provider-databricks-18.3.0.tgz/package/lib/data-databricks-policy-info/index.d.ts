/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPolicyInfoConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#name DataDatabricksPolicyInfo#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#on_securable_fullname DataDatabricksPolicyInfo#on_securable_fullname}
    */
    readonly onSecurableFullname: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#on_securable_type DataDatabricksPolicyInfo#on_securable_type}
    */
    readonly onSecurableType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#provider_config DataDatabricksPolicyInfo#provider_config}
    */
    readonly providerConfig?: DataDatabricksPolicyInfoProviderConfig;
}
export interface DataDatabricksPolicyInfoColumnMaskUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#alias DataDatabricksPolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#constant DataDatabricksPolicyInfo#constant}
    */
    readonly constant?: string;
}
export declare function dataDatabricksPolicyInfoColumnMaskUsingToTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoColumnMaskUsingToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoColumnMaskUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
}
export declare class DataDatabricksPolicyInfoColumnMaskUsingList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfoColumnMaskUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfoColumnMaskUsingOutputReference;
}
export interface DataDatabricksPolicyInfoColumnMask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#function_name DataDatabricksPolicyInfo#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#on_column DataDatabricksPolicyInfo#on_column}
    */
    readonly onColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#using DataDatabricksPolicyInfo#using}
    */
    readonly using?: DataDatabricksPolicyInfoColumnMaskUsing[] | cdktn.IResolvable;
}
export declare function dataDatabricksPolicyInfoColumnMaskToTerraform(struct?: DataDatabricksPolicyInfoColumnMask): any;
export declare function dataDatabricksPolicyInfoColumnMaskToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMask): any;
export declare class DataDatabricksPolicyInfoColumnMaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoColumnMask | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMask | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _onColumn?;
    get onColumn(): string;
    set onColumn(value: string);
    get onColumnInput(): string | undefined;
    private _using;
    get using(): DataDatabricksPolicyInfoColumnMaskUsingList;
    putUsing(value: DataDatabricksPolicyInfoColumnMaskUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | DataDatabricksPolicyInfoColumnMaskUsing[] | undefined;
}
export interface DataDatabricksPolicyInfoGrant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#privileges DataDatabricksPolicyInfo#privileges}
    */
    readonly privileges: string[];
}
export declare function dataDatabricksPolicyInfoGrantToTerraform(struct?: DataDatabricksPolicyInfoGrant): any;
export declare function dataDatabricksPolicyInfoGrantToHclTerraform(struct?: DataDatabricksPolicyInfoGrant): any;
export declare class DataDatabricksPolicyInfoGrantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoGrant | undefined;
    set internalValue(value: DataDatabricksPolicyInfoGrant | undefined);
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
}
export interface DataDatabricksPolicyInfoMatchColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#alias DataDatabricksPolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#condition DataDatabricksPolicyInfo#condition}
    */
    readonly condition?: string;
}
export declare function dataDatabricksPolicyInfoMatchColumnsToTerraform(struct?: DataDatabricksPolicyInfoMatchColumns): any;
export declare function dataDatabricksPolicyInfoMatchColumnsToHclTerraform(struct?: DataDatabricksPolicyInfoMatchColumns): any;
export declare class DataDatabricksPolicyInfoMatchColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfoMatchColumns | undefined;
    set internalValue(value: DataDatabricksPolicyInfoMatchColumns | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
}
export declare class DataDatabricksPolicyInfoMatchColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfoMatchColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfoMatchColumnsOutputReference;
}
export interface DataDatabricksPolicyInfoProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#workspace_id DataDatabricksPolicyInfo#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPolicyInfoProviderConfigToTerraform(struct?: DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoProviderConfigToHclTerraform(struct?: DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPolicyInfoRowFilterUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#alias DataDatabricksPolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#constant DataDatabricksPolicyInfo#constant}
    */
    readonly constant?: string;
}
export declare function dataDatabricksPolicyInfoRowFilterUsingToTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoRowFilterUsingToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoRowFilterUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
}
export declare class DataDatabricksPolicyInfoRowFilterUsingList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfoRowFilterUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfoRowFilterUsingOutputReference;
}
export interface DataDatabricksPolicyInfoRowFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#function_name DataDatabricksPolicyInfo#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#using DataDatabricksPolicyInfo#using}
    */
    readonly using?: DataDatabricksPolicyInfoRowFilterUsing[] | cdktn.IResolvable;
}
export declare function dataDatabricksPolicyInfoRowFilterToTerraform(struct?: DataDatabricksPolicyInfoRowFilter): any;
export declare function dataDatabricksPolicyInfoRowFilterToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilter): any;
export declare class DataDatabricksPolicyInfoRowFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoRowFilter | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilter | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _using;
    get using(): DataDatabricksPolicyInfoRowFilterUsingList;
    putUsing(value: DataDatabricksPolicyInfoRowFilterUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | DataDatabricksPolicyInfoRowFilterUsing[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info databricks_policy_info}
*/
export declare class DataDatabricksPolicyInfo extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_policy_info";
    /**
    * Generates CDKTN code for importing a DataDatabricksPolicyInfo resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPolicyInfo to import
    * @param importFromId The id of the existing DataDatabricksPolicyInfo that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPolicyInfo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/policy_info databricks_policy_info} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPolicyInfoConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPolicyInfoConfig);
    private _columnMask;
    get columnMask(): DataDatabricksPolicyInfoColumnMaskOutputReference;
    get comment(): string;
    get createdAt(): number;
    get createdBy(): string;
    get exceptPrincipals(): string[];
    get forSecurableType(): string;
    private _grant;
    get grant(): DataDatabricksPolicyInfoGrantOutputReference;
    get id(): string;
    private _matchColumns;
    get matchColumns(): DataDatabricksPolicyInfoMatchColumnsList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onSecurableFullname?;
    get onSecurableFullname(): string;
    set onSecurableFullname(value: string);
    get onSecurableFullnameInput(): string | undefined;
    private _onSecurableType?;
    get onSecurableType(): string;
    set onSecurableType(value: string);
    get onSecurableTypeInput(): string | undefined;
    get policyType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPolicyInfoProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPolicyInfoProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPolicyInfoProviderConfig | undefined;
    private _rowFilter;
    get rowFilter(): DataDatabricksPolicyInfoRowFilterOutputReference;
    get toPrincipals(): string[];
    get updatedAt(): number;
    get updatedBy(): string;
    get whenCondition(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
