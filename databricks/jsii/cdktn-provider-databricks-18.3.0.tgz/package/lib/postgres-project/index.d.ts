/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#initial_branch_spec PostgresProject#initial_branch_spec}
    */
    readonly initialBranchSpec?: PostgresProjectInitialBranchSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#initial_endpoint_spec PostgresProject#initial_endpoint_spec}
    */
    readonly initialEndpointSpec?: PostgresProjectInitialEndpointSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#project_id PostgresProject#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#provider_config PostgresProject#provider_config}
    */
    readonly providerConfig?: PostgresProjectProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#purge_on_delete PostgresProject#purge_on_delete}
    */
    readonly purgeOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#spec PostgresProject#spec}
    */
    readonly spec?: PostgresProjectSpec;
}
export interface PostgresProjectInitialBranchSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#is_protected PostgresProject#is_protected}
    */
    readonly isProtected?: boolean | cdktn.IResolvable;
}
export declare function postgresProjectInitialBranchSpecToTerraform(struct?: PostgresProjectInitialBranchSpec | cdktn.IResolvable): any;
export declare function postgresProjectInitialBranchSpecToHclTerraform(struct?: PostgresProjectInitialBranchSpec | cdktn.IResolvable): any;
export declare class PostgresProjectInitialBranchSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectInitialBranchSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresProjectInitialBranchSpec | cdktn.IResolvable | undefined);
    private _isProtected?;
    get isProtected(): boolean | cdktn.IResolvable;
    set isProtected(value: boolean | cdktn.IResolvable);
    resetIsProtected(): void;
    get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PostgresProjectInitialEndpointSpecGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#enable_readable_secondaries PostgresProject#enable_readable_secondaries}
    */
    readonly enableReadableSecondaries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#max PostgresProject#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#min PostgresProject#min}
    */
    readonly min: number;
}
export declare function postgresProjectInitialEndpointSpecGroupToTerraform(struct?: PostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable): any;
export declare function postgresProjectInitialEndpointSpecGroupToHclTerraform(struct?: PostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable): any;
export declare class PostgresProjectInitialEndpointSpecGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable | undefined);
    private _enableReadableSecondaries?;
    get enableReadableSecondaries(): boolean | cdktn.IResolvable;
    set enableReadableSecondaries(value: boolean | cdktn.IResolvable);
    resetEnableReadableSecondaries(): void;
    get enableReadableSecondariesInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface PostgresProjectInitialEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#autoscaling_limit_max_cu PostgresProject#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#autoscaling_limit_min_cu PostgresProject#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#group PostgresProject#group}
    */
    readonly group?: PostgresProjectInitialEndpointSpecGroup;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#no_suspension PostgresProject#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#suspend_timeout_duration PostgresProject#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function postgresProjectInitialEndpointSpecToTerraform(struct?: PostgresProjectInitialEndpointSpec | cdktn.IResolvable): any;
export declare function postgresProjectInitialEndpointSpecToHclTerraform(struct?: PostgresProjectInitialEndpointSpec | cdktn.IResolvable): any;
export declare class PostgresProjectInitialEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectInitialEndpointSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresProjectInitialEndpointSpec | cdktn.IResolvable | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _group;
    get group(): PostgresProjectInitialEndpointSpecGroupOutputReference;
    putGroup(value: PostgresProjectInitialEndpointSpecGroup): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | PostgresProjectInitialEndpointSpecGroup | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface PostgresProjectProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#workspace_id PostgresProject#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresProjectProviderConfigToTerraform(struct?: PostgresProjectProviderConfig | cdktn.IResolvable): any;
export declare function postgresProjectProviderConfigToHclTerraform(struct?: PostgresProjectProviderConfig | cdktn.IResolvable): any;
export declare class PostgresProjectProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresProjectProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresProjectSpecCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#key PostgresProject#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#value PostgresProject#value}
    */
    readonly value?: string;
}
export declare function postgresProjectSpecCustomTagsToTerraform(struct?: PostgresProjectSpecCustomTags | cdktn.IResolvable): any;
export declare function postgresProjectSpecCustomTagsToHclTerraform(struct?: PostgresProjectSpecCustomTags | cdktn.IResolvable): any;
export declare class PostgresProjectSpecCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PostgresProjectSpecCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresProjectSpecCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class PostgresProjectSpecCustomTagsList extends cdktn.ComplexList {
    internalValue?: PostgresProjectSpecCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PostgresProjectSpecCustomTagsOutputReference;
}
export interface PostgresProjectSpecDefaultEndpointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#autoscaling_limit_max_cu PostgresProject#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#autoscaling_limit_min_cu PostgresProject#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#no_suspension PostgresProject#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#pg_settings PostgresProject#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#suspend_timeout_duration PostgresProject#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function postgresProjectSpecDefaultEndpointSettingsToTerraform(struct?: PostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable): any;
export declare function postgresProjectSpecDefaultEndpointSettingsToHclTerraform(struct?: PostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable): any;
export declare class PostgresProjectSpecDefaultEndpointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface PostgresProjectSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#budget_policy_id PostgresProject#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#custom_tags PostgresProject#custom_tags}
    */
    readonly customTags?: PostgresProjectSpecCustomTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#default_branch PostgresProject#default_branch}
    */
    readonly defaultBranch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#default_endpoint_settings PostgresProject#default_endpoint_settings}
    */
    readonly defaultEndpointSettings?: PostgresProjectSpecDefaultEndpointSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#display_name PostgresProject#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#enable_pg_native_login PostgresProject#enable_pg_native_login}
    */
    readonly enablePgNativeLogin?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#history_retention_duration PostgresProject#history_retention_duration}
    */
    readonly historyRetentionDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#pg_version PostgresProject#pg_version}
    */
    readonly pgVersion?: number;
}
export declare function postgresProjectSpecToTerraform(struct?: PostgresProjectSpec | cdktn.IResolvable): any;
export declare function postgresProjectSpecToHclTerraform(struct?: PostgresProjectSpec | cdktn.IResolvable): any;
export declare class PostgresProjectSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresProjectSpec | cdktn.IResolvable | undefined);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _customTags;
    get customTags(): PostgresProjectSpecCustomTagsList;
    putCustomTags(value: PostgresProjectSpecCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | PostgresProjectSpecCustomTags[] | undefined;
    private _defaultBranch?;
    get defaultBranch(): string;
    set defaultBranch(value: string);
    resetDefaultBranch(): void;
    get defaultBranchInput(): string | undefined;
    private _defaultEndpointSettings;
    get defaultEndpointSettings(): PostgresProjectSpecDefaultEndpointSettingsOutputReference;
    putDefaultEndpointSettings(value: PostgresProjectSpecDefaultEndpointSettings): void;
    resetDefaultEndpointSettings(): void;
    get defaultEndpointSettingsInput(): cdktn.IResolvable | PostgresProjectSpecDefaultEndpointSettings | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enablePgNativeLogin?;
    get enablePgNativeLogin(): boolean | cdktn.IResolvable;
    set enablePgNativeLogin(value: boolean | cdktn.IResolvable);
    resetEnablePgNativeLogin(): void;
    get enablePgNativeLoginInput(): boolean | cdktn.IResolvable | undefined;
    private _historyRetentionDuration?;
    get historyRetentionDuration(): string;
    set historyRetentionDuration(value: string);
    resetHistoryRetentionDuration(): void;
    get historyRetentionDurationInput(): string | undefined;
    private _pgVersion?;
    get pgVersion(): number;
    set pgVersion(value: number);
    resetPgVersion(): void;
    get pgVersionInput(): number | undefined;
}
export interface PostgresProjectStatusCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#key PostgresProject#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#value PostgresProject#value}
    */
    readonly value?: string;
}
export declare function postgresProjectStatusCustomTagsToTerraform(struct?: PostgresProjectStatusCustomTags): any;
export declare function postgresProjectStatusCustomTagsToHclTerraform(struct?: PostgresProjectStatusCustomTags): any;
export declare class PostgresProjectStatusCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PostgresProjectStatusCustomTags | undefined;
    set internalValue(value: PostgresProjectStatusCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class PostgresProjectStatusCustomTagsList extends cdktn.ComplexList {
    internalValue?: PostgresProjectStatusCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PostgresProjectStatusCustomTagsOutputReference;
}
export interface PostgresProjectStatusDefaultEndpointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#autoscaling_limit_max_cu PostgresProject#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#autoscaling_limit_min_cu PostgresProject#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#no_suspension PostgresProject#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#pg_settings PostgresProject#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#suspend_timeout_duration PostgresProject#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function postgresProjectStatusDefaultEndpointSettingsToTerraform(struct?: PostgresProjectStatusDefaultEndpointSettings): any;
export declare function postgresProjectStatusDefaultEndpointSettingsToHclTerraform(struct?: PostgresProjectStatusDefaultEndpointSettings): any;
export declare class PostgresProjectStatusDefaultEndpointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectStatusDefaultEndpointSettings | undefined;
    set internalValue(value: PostgresProjectStatusDefaultEndpointSettings | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface PostgresProjectStatus {
}
export declare function postgresProjectStatusToTerraform(struct?: PostgresProjectStatus): any;
export declare function postgresProjectStatusToHclTerraform(struct?: PostgresProjectStatus): any;
export declare class PostgresProjectStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresProjectStatus | undefined;
    set internalValue(value: PostgresProjectStatus | undefined);
    get branchLogicalSizeLimitBytes(): number;
    get budgetPolicyId(): string;
    get computeLastActiveTime(): string;
    private _customTags;
    get customTags(): PostgresProjectStatusCustomTagsList;
    get defaultBranch(): string;
    private _defaultEndpointSettings;
    get defaultEndpointSettings(): PostgresProjectStatusDefaultEndpointSettingsOutputReference;
    get displayName(): string;
    get enablePgNativeLogin(): cdktn.IResolvable;
    get historyRetentionDuration(): string;
    get owner(): string;
    get pgVersion(): number;
    get projectId(): string;
    get syntheticStorageSizeBytes(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project databricks_postgres_project}
*/
export declare class PostgresProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_project";
    /**
    * Generates CDKTN code for importing a PostgresProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresProject to import
    * @param importFromId The id of the existing PostgresProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/postgres_project databricks_postgres_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresProjectConfig
    */
    constructor(scope: Construct, id: string, config: PostgresProjectConfig);
    get createTime(): string;
    get deleteTime(): string;
    private _initialBranchSpec;
    get initialBranchSpec(): PostgresProjectInitialBranchSpecOutputReference;
    putInitialBranchSpec(value: PostgresProjectInitialBranchSpec): void;
    resetInitialBranchSpec(): void;
    get initialBranchSpecInput(): cdktn.IResolvable | PostgresProjectInitialBranchSpec | undefined;
    private _initialEndpointSpec;
    get initialEndpointSpec(): PostgresProjectInitialEndpointSpecOutputReference;
    putInitialEndpointSpec(value: PostgresProjectInitialEndpointSpec): void;
    resetInitialEndpointSpec(): void;
    get initialEndpointSpecInput(): cdktn.IResolvable | PostgresProjectInitialEndpointSpec | undefined;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresProjectProviderConfigOutputReference;
    putProviderConfig(value: PostgresProjectProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresProjectProviderConfig | undefined;
    private _purgeOnDelete?;
    get purgeOnDelete(): boolean | cdktn.IResolvable;
    set purgeOnDelete(value: boolean | cdktn.IResolvable);
    resetPurgeOnDelete(): void;
    get purgeOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    get purgeTime(): string;
    private _spec;
    get spec(): PostgresProjectSpecOutputReference;
    putSpec(value: PostgresProjectSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresProjectSpec | undefined;
    private _status;
    get status(): PostgresProjectStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
