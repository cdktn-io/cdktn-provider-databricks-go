/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MetastoreAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#api MetastoreAssignment#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#default_catalog_name MetastoreAssignment#default_catalog_name}
    */
    readonly defaultCatalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#id MetastoreAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#metastore_id MetastoreAssignment#metastore_id}
    */
    readonly metastoreId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#workspace_id MetastoreAssignment#workspace_id}
    */
    readonly workspaceId: number;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#provider_config MetastoreAssignment#provider_config}
    */
    readonly providerConfig?: MetastoreAssignmentProviderConfig;
}
export interface MetastoreAssignmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#workspace_id MetastoreAssignment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function metastoreAssignmentProviderConfigToTerraform(struct?: MetastoreAssignmentProviderConfigOutputReference | MetastoreAssignmentProviderConfig): any;
export declare function metastoreAssignmentProviderConfigToHclTerraform(struct?: MetastoreAssignmentProviderConfigOutputReference | MetastoreAssignmentProviderConfig): any;
export declare class MetastoreAssignmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreAssignmentProviderConfig | undefined;
    set internalValue(value: MetastoreAssignmentProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment databricks_metastore_assignment}
*/
export declare class MetastoreAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_metastore_assignment";
    /**
    * Generates CDKTN code for importing a MetastoreAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MetastoreAssignment to import
    * @param importFromId The id of the existing MetastoreAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MetastoreAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/metastore_assignment databricks_metastore_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MetastoreAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: MetastoreAssignmentConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _defaultCatalogName?;
    get defaultCatalogName(): string;
    set defaultCatalogName(value: string);
    resetDefaultCatalogName(): void;
    get defaultCatalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    get metastoreIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    get workspaceIdInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): MetastoreAssignmentProviderConfigOutputReference;
    putProviderConfig(value: MetastoreAssignmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): MetastoreAssignmentProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
