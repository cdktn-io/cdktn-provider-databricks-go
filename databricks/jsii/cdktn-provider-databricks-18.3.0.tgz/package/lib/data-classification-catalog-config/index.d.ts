/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataClassificationCatalogConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#auto_tag_configs DataClassificationCatalogConfig#auto_tag_configs}
    */
    readonly autoTagConfigs?: DataClassificationCatalogConfigAutoTagConfigs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#excluded_schemas DataClassificationCatalogConfig#excluded_schemas}
    */
    readonly excludedSchemas?: DataClassificationCatalogConfigExcludedSchemas;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#included_schemas DataClassificationCatalogConfig#included_schemas}
    */
    readonly includedSchemas?: DataClassificationCatalogConfigIncludedSchemas;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#parent DataClassificationCatalogConfig#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#provider_config DataClassificationCatalogConfig#provider_config}
    */
    readonly providerConfig?: DataClassificationCatalogConfigProviderConfig;
}
export interface DataClassificationCatalogConfigAutoTagConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#auto_tagging_mode DataClassificationCatalogConfig#auto_tagging_mode}
    */
    readonly autoTaggingMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#classification_tag DataClassificationCatalogConfig#classification_tag}
    */
    readonly classificationTag: string;
}
export declare function dataClassificationCatalogConfigAutoTagConfigsToTerraform(struct?: DataClassificationCatalogConfigAutoTagConfigs | cdktn.IResolvable): any;
export declare function dataClassificationCatalogConfigAutoTagConfigsToHclTerraform(struct?: DataClassificationCatalogConfigAutoTagConfigs | cdktn.IResolvable): any;
export declare class DataClassificationCatalogConfigAutoTagConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataClassificationCatalogConfigAutoTagConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: DataClassificationCatalogConfigAutoTagConfigs | cdktn.IResolvable | undefined);
    private _autoTaggingMode?;
    get autoTaggingMode(): string;
    set autoTaggingMode(value: string);
    get autoTaggingModeInput(): string | undefined;
    private _classificationTag?;
    get classificationTag(): string;
    set classificationTag(value: string);
    get classificationTagInput(): string | undefined;
}
export declare class DataClassificationCatalogConfigAutoTagConfigsList extends cdktn.ComplexList {
    internalValue?: DataClassificationCatalogConfigAutoTagConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataClassificationCatalogConfigAutoTagConfigsOutputReference;
}
export interface DataClassificationCatalogConfigExcludedSchemas {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#names DataClassificationCatalogConfig#names}
    */
    readonly names: string[];
}
export declare function dataClassificationCatalogConfigExcludedSchemasToTerraform(struct?: DataClassificationCatalogConfigExcludedSchemas | cdktn.IResolvable): any;
export declare function dataClassificationCatalogConfigExcludedSchemasToHclTerraform(struct?: DataClassificationCatalogConfigExcludedSchemas | cdktn.IResolvable): any;
export declare class DataClassificationCatalogConfigExcludedSchemasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataClassificationCatalogConfigExcludedSchemas | cdktn.IResolvable | undefined;
    set internalValue(value: DataClassificationCatalogConfigExcludedSchemas | cdktn.IResolvable | undefined);
    private _names?;
    get names(): string[];
    set names(value: string[]);
    get namesInput(): string[] | undefined;
}
export interface DataClassificationCatalogConfigIncludedSchemas {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#names DataClassificationCatalogConfig#names}
    */
    readonly names: string[];
}
export declare function dataClassificationCatalogConfigIncludedSchemasToTerraform(struct?: DataClassificationCatalogConfigIncludedSchemas | cdktn.IResolvable): any;
export declare function dataClassificationCatalogConfigIncludedSchemasToHclTerraform(struct?: DataClassificationCatalogConfigIncludedSchemas | cdktn.IResolvable): any;
export declare class DataClassificationCatalogConfigIncludedSchemasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataClassificationCatalogConfigIncludedSchemas | cdktn.IResolvable | undefined;
    set internalValue(value: DataClassificationCatalogConfigIncludedSchemas | cdktn.IResolvable | undefined);
    private _names?;
    get names(): string[];
    set names(value: string[]);
    get namesInput(): string[] | undefined;
}
export interface DataClassificationCatalogConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#workspace_id DataClassificationCatalogConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataClassificationCatalogConfigProviderConfigToTerraform(struct?: DataClassificationCatalogConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataClassificationCatalogConfigProviderConfigToHclTerraform(struct?: DataClassificationCatalogConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataClassificationCatalogConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataClassificationCatalogConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataClassificationCatalogConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config databricks_data_classification_catalog_config}
*/
export declare class DataClassificationCatalogConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_data_classification_catalog_config";
    /**
    * Generates CDKTN code for importing a DataClassificationCatalogConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataClassificationCatalogConfig to import
    * @param importFromId The id of the existing DataClassificationCatalogConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataClassificationCatalogConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/data_classification_catalog_config databricks_data_classification_catalog_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataClassificationCatalogConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataClassificationCatalogConfigConfig);
    private _autoTagConfigs;
    get autoTagConfigs(): DataClassificationCatalogConfigAutoTagConfigsList;
    putAutoTagConfigs(value: DataClassificationCatalogConfigAutoTagConfigs[] | cdktn.IResolvable): void;
    resetAutoTagConfigs(): void;
    get autoTagConfigsInput(): cdktn.IResolvable | DataClassificationCatalogConfigAutoTagConfigs[] | undefined;
    private _excludedSchemas;
    get excludedSchemas(): DataClassificationCatalogConfigExcludedSchemasOutputReference;
    putExcludedSchemas(value: DataClassificationCatalogConfigExcludedSchemas): void;
    resetExcludedSchemas(): void;
    get excludedSchemasInput(): cdktn.IResolvable | DataClassificationCatalogConfigExcludedSchemas | undefined;
    private _includedSchemas;
    get includedSchemas(): DataClassificationCatalogConfigIncludedSchemasOutputReference;
    putIncludedSchemas(value: DataClassificationCatalogConfigIncludedSchemas): void;
    resetIncludedSchemas(): void;
    get includedSchemasInput(): cdktn.IResolvable | DataClassificationCatalogConfigIncludedSchemas | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataClassificationCatalogConfigProviderConfigOutputReference;
    putProviderConfig(value: DataClassificationCatalogConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataClassificationCatalogConfigProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
