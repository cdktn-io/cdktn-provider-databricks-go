/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWarehousesDefaultWarehouseOverridesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides#page_size DataDatabricksWarehousesDefaultWarehouseOverrides#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides#provider_config DataDatabricksWarehousesDefaultWarehouseOverrides#provider_config}
    */
    readonly providerConfig?: DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig;
}
export interface DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides#workspace_id DataDatabricksWarehousesDefaultWarehouseOverrides#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfigToTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfigToHclTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverrides {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides#name DataDatabricksWarehousesDefaultWarehouseOverrides#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides#provider_config DataDatabricksWarehousesDefaultWarehouseOverrides#provider_config}
    */
    readonly providerConfig?: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig;
}
export declare function dataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesToTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverrides): any;
export declare function dataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesToHclTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverrides): any;
export declare class DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverrides | undefined;
    set internalValue(value: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverrides | undefined);
    get defaultWarehouseOverrideId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesProviderConfig | undefined;
    get type(): string;
    get warehouseId(): string;
}
export declare class DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesOutputReference;
}
export interface DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides#workspace_id DataDatabricksWarehousesDefaultWarehouseOverrides#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWarehousesDefaultWarehouseOverridesProviderConfigToTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWarehousesDefaultWarehouseOverridesProviderConfigToHclTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides databricks_warehouses_default_warehouse_overrides}
*/
export declare class DataDatabricksWarehousesDefaultWarehouseOverrides extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_warehouses_default_warehouse_overrides";
    /**
    * Generates CDKTN code for importing a DataDatabricksWarehousesDefaultWarehouseOverrides resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWarehousesDefaultWarehouseOverrides to import
    * @param importFromId The id of the existing DataDatabricksWarehousesDefaultWarehouseOverrides that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWarehousesDefaultWarehouseOverrides to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/warehouses_default_warehouse_overrides databricks_warehouses_default_warehouse_overrides} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWarehousesDefaultWarehouseOverridesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksWarehousesDefaultWarehouseOverridesConfig);
    private _defaultWarehouseOverrides;
    get defaultWarehouseOverrides(): DataDatabricksWarehousesDefaultWarehouseOverridesDefaultWarehouseOverridesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWarehousesDefaultWarehouseOverridesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
