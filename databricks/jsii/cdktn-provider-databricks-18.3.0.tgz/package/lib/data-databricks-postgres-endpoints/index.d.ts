/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresEndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#page_size DataDatabricksPostgresEndpoints#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#parent DataDatabricksPostgresEndpoints#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#provider_config DataDatabricksPostgresEndpoints#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresEndpointsProviderConfig;
}
export interface DataDatabricksPostgresEndpointsEndpointsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#workspace_id DataDatabricksPostgresEndpoints#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresEndpointsEndpointsProviderConfigToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresEndpointsEndpointsProviderConfigToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresEndpointsEndpointsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresEndpointsEndpointsSpecGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#enable_readable_secondaries DataDatabricksPostgresEndpoints#enable_readable_secondaries}
    */
    readonly enableReadableSecondaries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#max DataDatabricksPostgresEndpoints#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#min DataDatabricksPostgresEndpoints#min}
    */
    readonly min: number;
}
export declare function dataDatabricksPostgresEndpointsEndpointsSpecGroupToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsSpecGroup | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresEndpointsEndpointsSpecGroupToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsSpecGroup | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresEndpointsEndpointsSpecGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsSpecGroup | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsSpecGroup | cdktn.IResolvable | undefined);
    private _enableReadableSecondaries?;
    get enableReadableSecondaries(): boolean | cdktn.IResolvable;
    set enableReadableSecondaries(value: boolean | cdktn.IResolvable);
    resetEnableReadableSecondaries(): void;
    get enableReadableSecondariesInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface DataDatabricksPostgresEndpointsEndpointsSpecSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#pg_settings DataDatabricksPostgresEndpoints#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksPostgresEndpointsEndpointsSpecSettingsToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsSpecSettings | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresEndpointsEndpointsSpecSettingsToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsSpecSettings | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresEndpointsEndpointsSpecSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsSpecSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsSpecSettings | cdktn.IResolvable | undefined);
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksPostgresEndpointsEndpointsSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#autoscaling_limit_max_cu DataDatabricksPostgresEndpoints#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#autoscaling_limit_min_cu DataDatabricksPostgresEndpoints#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#disabled DataDatabricksPostgresEndpoints#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#endpoint_type DataDatabricksPostgresEndpoints#endpoint_type}
    */
    readonly endpointType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#group DataDatabricksPostgresEndpoints#group}
    */
    readonly group?: DataDatabricksPostgresEndpointsEndpointsSpecGroup;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#no_suspension DataDatabricksPostgresEndpoints#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#settings DataDatabricksPostgresEndpoints#settings}
    */
    readonly settings?: DataDatabricksPostgresEndpointsEndpointsSpecSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#suspend_timeout_duration DataDatabricksPostgresEndpoints#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresEndpointsEndpointsSpecToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsSpec): any;
export declare function dataDatabricksPostgresEndpointsEndpointsSpecToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsSpec): any;
export declare class DataDatabricksPostgresEndpointsEndpointsSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsSpec | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsSpec | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    get endpointTypeInput(): string | undefined;
    private _group;
    get group(): DataDatabricksPostgresEndpointsEndpointsSpecGroupOutputReference;
    putGroup(value: DataDatabricksPostgresEndpointsEndpointsSpecGroup): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | DataDatabricksPostgresEndpointsEndpointsSpecGroup | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _settings;
    get settings(): DataDatabricksPostgresEndpointsEndpointsSpecSettingsOutputReference;
    putSettings(value: DataDatabricksPostgresEndpointsEndpointsSpecSettings): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | DataDatabricksPostgresEndpointsEndpointsSpecSettings | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresEndpointsEndpointsStatusGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#max DataDatabricksPostgresEndpoints#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#min DataDatabricksPostgresEndpoints#min}
    */
    readonly min: number;
}
export declare function dataDatabricksPostgresEndpointsEndpointsStatusGroupToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatusGroup): any;
export declare function dataDatabricksPostgresEndpointsEndpointsStatusGroupToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatusGroup): any;
export declare class DataDatabricksPostgresEndpointsEndpointsStatusGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsStatusGroup | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsStatusGroup | undefined);
    get enableReadableSecondaries(): cdktn.IResolvable;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface DataDatabricksPostgresEndpointsEndpointsStatusHosts {
}
export declare function dataDatabricksPostgresEndpointsEndpointsStatusHostsToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatusHosts): any;
export declare function dataDatabricksPostgresEndpointsEndpointsStatusHostsToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatusHosts): any;
export declare class DataDatabricksPostgresEndpointsEndpointsStatusHostsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsStatusHosts | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsStatusHosts | undefined);
    get host(): string;
    get readOnlyHost(): string;
    get readOnlyPooledHost(): string;
    get readWritePooledHost(): string;
}
export interface DataDatabricksPostgresEndpointsEndpointsStatusSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#pg_settings DataDatabricksPostgresEndpoints#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksPostgresEndpointsEndpointsStatusSettingsToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatusSettings): any;
export declare function dataDatabricksPostgresEndpointsEndpointsStatusSettingsToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatusSettings): any;
export declare class DataDatabricksPostgresEndpointsEndpointsStatusSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsStatusSettings | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsStatusSettings | undefined);
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksPostgresEndpointsEndpointsStatus {
}
export declare function dataDatabricksPostgresEndpointsEndpointsStatusToTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatus): any;
export declare function dataDatabricksPostgresEndpointsEndpointsStatusToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpointsStatus): any;
export declare class DataDatabricksPostgresEndpointsEndpointsStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsEndpointsStatus | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpointsStatus | undefined);
    get autoscalingLimitMaxCu(): number;
    get autoscalingLimitMinCu(): number;
    get currentState(): string;
    get disabled(): cdktn.IResolvable;
    get endpointId(): string;
    get endpointType(): string;
    private _group;
    get group(): DataDatabricksPostgresEndpointsEndpointsStatusGroupOutputReference;
    private _hosts;
    get hosts(): DataDatabricksPostgresEndpointsEndpointsStatusHostsOutputReference;
    get lastActiveTime(): string;
    get pendingState(): string;
    private _settings;
    get settings(): DataDatabricksPostgresEndpointsEndpointsStatusSettingsOutputReference;
    get suspendTimeoutDuration(): string;
}
export interface DataDatabricksPostgresEndpointsEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#name DataDatabricksPostgresEndpoints#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#provider_config DataDatabricksPostgresEndpoints#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresEndpointsEndpointsProviderConfig;
}
export declare function dataDatabricksPostgresEndpointsEndpointsToTerraform(struct?: DataDatabricksPostgresEndpointsEndpoints): any;
export declare function dataDatabricksPostgresEndpointsEndpointsToHclTerraform(struct?: DataDatabricksPostgresEndpointsEndpoints): any;
export declare class DataDatabricksPostgresEndpointsEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresEndpointsEndpoints | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsEndpoints | undefined);
    get createTime(): string;
    get endpointId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresEndpointsEndpointsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresEndpointsEndpointsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresEndpointsEndpointsProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresEndpointsEndpointsSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresEndpointsEndpointsStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
}
export declare class DataDatabricksPostgresEndpointsEndpointsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresEndpointsEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresEndpointsEndpointsOutputReference;
}
export interface DataDatabricksPostgresEndpointsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#workspace_id DataDatabricksPostgresEndpoints#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresEndpointsProviderConfigToTerraform(struct?: DataDatabricksPostgresEndpointsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresEndpointsProviderConfigToHclTerraform(struct?: DataDatabricksPostgresEndpointsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresEndpointsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints databricks_postgres_endpoints}
*/
export declare class DataDatabricksPostgresEndpoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_endpoints";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresEndpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresEndpoints to import
    * @param importFromId The id of the existing DataDatabricksPostgresEndpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresEndpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/postgres_endpoints databricks_postgres_endpoints} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresEndpointsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresEndpointsConfig);
    private _endpoints;
    get endpoints(): DataDatabricksPostgresEndpointsEndpointsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresEndpointsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresEndpointsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresEndpointsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
