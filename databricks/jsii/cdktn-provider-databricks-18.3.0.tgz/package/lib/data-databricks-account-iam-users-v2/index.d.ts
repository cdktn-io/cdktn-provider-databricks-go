/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountIamUsersV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2#filter DataDatabricksAccountIamUsersV2#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2#page_size DataDatabricksAccountIamUsersV2#page_size}
    */
    readonly pageSize?: number;
}
export interface DataDatabricksAccountIamUsersV2UsersFullName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2#family_name DataDatabricksAccountIamUsersV2#family_name}
    */
    readonly familyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2#given_name DataDatabricksAccountIamUsersV2#given_name}
    */
    readonly givenName?: string;
}
export declare function dataDatabricksAccountIamUsersV2UsersFullNameToTerraform(struct?: DataDatabricksAccountIamUsersV2UsersFullName): any;
export declare function dataDatabricksAccountIamUsersV2UsersFullNameToHclTerraform(struct?: DataDatabricksAccountIamUsersV2UsersFullName): any;
export declare class DataDatabricksAccountIamUsersV2UsersFullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountIamUsersV2UsersFullName | undefined;
    set internalValue(value: DataDatabricksAccountIamUsersV2UsersFullName | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    resetFamilyName(): void;
    get familyNameInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
}
export interface DataDatabricksAccountIamUsersV2Users {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2#user_id DataDatabricksAccountIamUsersV2#user_id}
    */
    readonly userId: string;
}
export declare function dataDatabricksAccountIamUsersV2UsersToTerraform(struct?: DataDatabricksAccountIamUsersV2Users): any;
export declare function dataDatabricksAccountIamUsersV2UsersToHclTerraform(struct?: DataDatabricksAccountIamUsersV2Users): any;
export declare class DataDatabricksAccountIamUsersV2UsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountIamUsersV2Users | undefined;
    set internalValue(value: DataDatabricksAccountIamUsersV2Users | undefined);
    get accountId(): string;
    get accountUserStatus(): string;
    get externalId(): string;
    private _fullName;
    get fullName(): DataDatabricksAccountIamUsersV2UsersFullNameOutputReference;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    get username(): string;
}
export declare class DataDatabricksAccountIamUsersV2UsersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountIamUsersV2Users[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountIamUsersV2UsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2 databricks_account_iam_users_v2}
*/
export declare class DataDatabricksAccountIamUsersV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_iam_users_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountIamUsersV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountIamUsersV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountIamUsersV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountIamUsersV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_users_v2 databricks_account_iam_users_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountIamUsersV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAccountIamUsersV2Config);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _users;
    get users(): DataDatabricksAccountIamUsersV2UsersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
