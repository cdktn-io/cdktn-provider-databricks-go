/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSqlWarehouseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#auto_stop_mins DataDatabricksSqlWarehouse#auto_stop_mins}
    */
    readonly autoStopMins?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#cluster_size DataDatabricksSqlWarehouse#cluster_size}
    */
    readonly clusterSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#creator_name DataDatabricksSqlWarehouse#creator_name}
    */
    readonly creatorName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#data_source_id DataDatabricksSqlWarehouse#data_source_id}
    */
    readonly dataSourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#enable_photon DataDatabricksSqlWarehouse#enable_photon}
    */
    readonly enablePhoton?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#enable_serverless_compute DataDatabricksSqlWarehouse#enable_serverless_compute}
    */
    readonly enableServerlessCompute?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#id DataDatabricksSqlWarehouse#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#instance_profile_arn DataDatabricksSqlWarehouse#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#jdbc_url DataDatabricksSqlWarehouse#jdbc_url}
    */
    readonly jdbcUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#max_num_clusters DataDatabricksSqlWarehouse#max_num_clusters}
    */
    readonly maxNumClusters?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#min_num_clusters DataDatabricksSqlWarehouse#min_num_clusters}
    */
    readonly minNumClusters?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#name DataDatabricksSqlWarehouse#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#num_active_sessions DataDatabricksSqlWarehouse#num_active_sessions}
    */
    readonly numActiveSessions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#num_clusters DataDatabricksSqlWarehouse#num_clusters}
    */
    readonly numClusters?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#spot_instance_policy DataDatabricksSqlWarehouse#spot_instance_policy}
    */
    readonly spotInstancePolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#state DataDatabricksSqlWarehouse#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#warehouse_type DataDatabricksSqlWarehouse#warehouse_type}
    */
    readonly warehouseType?: string;
    /**
    * channel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#channel DataDatabricksSqlWarehouse#channel}
    */
    readonly channel?: DataDatabricksSqlWarehouseChannel;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#health DataDatabricksSqlWarehouse#health}
    */
    readonly health?: DataDatabricksSqlWarehouseHealth;
    /**
    * odbc_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#odbc_params DataDatabricksSqlWarehouse#odbc_params}
    */
    readonly odbcParams?: DataDatabricksSqlWarehouseOdbcParams;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#provider_config DataDatabricksSqlWarehouse#provider_config}
    */
    readonly providerConfig?: DataDatabricksSqlWarehouseProviderConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#tags DataDatabricksSqlWarehouse#tags}
    */
    readonly tags?: DataDatabricksSqlWarehouseTags;
}
export interface DataDatabricksSqlWarehouseChannel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#dbsql_version DataDatabricksSqlWarehouse#dbsql_version}
    */
    readonly dbsqlVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#name DataDatabricksSqlWarehouse#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksSqlWarehouseChannelToTerraform(struct?: DataDatabricksSqlWarehouseChannelOutputReference | DataDatabricksSqlWarehouseChannel): any;
export declare function dataDatabricksSqlWarehouseChannelToHclTerraform(struct?: DataDatabricksSqlWarehouseChannelOutputReference | DataDatabricksSqlWarehouseChannel): any;
export declare class DataDatabricksSqlWarehouseChannelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSqlWarehouseChannel | undefined;
    set internalValue(value: DataDatabricksSqlWarehouseChannel | undefined);
    private _dbsqlVersion?;
    get dbsqlVersion(): string;
    set dbsqlVersion(value: string);
    resetDbsqlVersion(): void;
    get dbsqlVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DataDatabricksSqlWarehouseHealthFailureReason {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#code DataDatabricksSqlWarehouse#code}
    */
    readonly code?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#parameters DataDatabricksSqlWarehouse#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#type DataDatabricksSqlWarehouse#type}
    */
    readonly type?: string;
}
export declare function dataDatabricksSqlWarehouseHealthFailureReasonToTerraform(struct?: DataDatabricksSqlWarehouseHealthFailureReasonOutputReference | DataDatabricksSqlWarehouseHealthFailureReason): any;
export declare function dataDatabricksSqlWarehouseHealthFailureReasonToHclTerraform(struct?: DataDatabricksSqlWarehouseHealthFailureReasonOutputReference | DataDatabricksSqlWarehouseHealthFailureReason): any;
export declare class DataDatabricksSqlWarehouseHealthFailureReasonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSqlWarehouseHealthFailureReason | undefined;
    set internalValue(value: DataDatabricksSqlWarehouseHealthFailureReason | undefined);
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DataDatabricksSqlWarehouseHealth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#details DataDatabricksSqlWarehouse#details}
    */
    readonly details?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#message DataDatabricksSqlWarehouse#message}
    */
    readonly message?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#status DataDatabricksSqlWarehouse#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#summary DataDatabricksSqlWarehouse#summary}
    */
    readonly summary?: string;
    /**
    * failure_reason block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#failure_reason DataDatabricksSqlWarehouse#failure_reason}
    */
    readonly failureReason?: DataDatabricksSqlWarehouseHealthFailureReason;
}
export declare function dataDatabricksSqlWarehouseHealthToTerraform(struct?: DataDatabricksSqlWarehouseHealthOutputReference | DataDatabricksSqlWarehouseHealth): any;
export declare function dataDatabricksSqlWarehouseHealthToHclTerraform(struct?: DataDatabricksSqlWarehouseHealthOutputReference | DataDatabricksSqlWarehouseHealth): any;
export declare class DataDatabricksSqlWarehouseHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSqlWarehouseHealth | undefined;
    set internalValue(value: DataDatabricksSqlWarehouseHealth | undefined);
    private _details?;
    get details(): string;
    set details(value: string);
    resetDetails(): void;
    get detailsInput(): string | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    resetSummary(): void;
    get summaryInput(): string | undefined;
    private _failureReason;
    get failureReason(): DataDatabricksSqlWarehouseHealthFailureReasonOutputReference;
    putFailureReason(value: DataDatabricksSqlWarehouseHealthFailureReason): void;
    resetFailureReason(): void;
    get failureReasonInput(): DataDatabricksSqlWarehouseHealthFailureReason | undefined;
}
export interface DataDatabricksSqlWarehouseOdbcParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#hostname DataDatabricksSqlWarehouse#hostname}
    */
    readonly hostname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#path DataDatabricksSqlWarehouse#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#port DataDatabricksSqlWarehouse#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#protocol DataDatabricksSqlWarehouse#protocol}
    */
    readonly protocol?: string;
}
export declare function dataDatabricksSqlWarehouseOdbcParamsToTerraform(struct?: DataDatabricksSqlWarehouseOdbcParamsOutputReference | DataDatabricksSqlWarehouseOdbcParams): any;
export declare function dataDatabricksSqlWarehouseOdbcParamsToHclTerraform(struct?: DataDatabricksSqlWarehouseOdbcParamsOutputReference | DataDatabricksSqlWarehouseOdbcParams): any;
export declare class DataDatabricksSqlWarehouseOdbcParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSqlWarehouseOdbcParams | undefined;
    set internalValue(value: DataDatabricksSqlWarehouseOdbcParams | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export interface DataDatabricksSqlWarehouseProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#workspace_id DataDatabricksSqlWarehouse#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSqlWarehouseProviderConfigToTerraform(struct?: DataDatabricksSqlWarehouseProviderConfigOutputReference | DataDatabricksSqlWarehouseProviderConfig): any;
export declare function dataDatabricksSqlWarehouseProviderConfigToHclTerraform(struct?: DataDatabricksSqlWarehouseProviderConfigOutputReference | DataDatabricksSqlWarehouseProviderConfig): any;
export declare class DataDatabricksSqlWarehouseProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSqlWarehouseProviderConfig | undefined;
    set internalValue(value: DataDatabricksSqlWarehouseProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSqlWarehouseTagsCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#key DataDatabricksSqlWarehouse#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#value DataDatabricksSqlWarehouse#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksSqlWarehouseTagsCustomTagsToTerraform(struct?: DataDatabricksSqlWarehouseTagsCustomTags | cdktn.IResolvable): any;
export declare function dataDatabricksSqlWarehouseTagsCustomTagsToHclTerraform(struct?: DataDatabricksSqlWarehouseTagsCustomTags | cdktn.IResolvable): any;
export declare class DataDatabricksSqlWarehouseTagsCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksSqlWarehouseTagsCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSqlWarehouseTagsCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksSqlWarehouseTagsCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksSqlWarehouseTagsCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksSqlWarehouseTagsCustomTagsOutputReference;
}
export interface DataDatabricksSqlWarehouseTags {
    /**
    * custom_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#custom_tags DataDatabricksSqlWarehouse#custom_tags}
    */
    readonly customTags?: DataDatabricksSqlWarehouseTagsCustomTags[] | cdktn.IResolvable;
}
export declare function dataDatabricksSqlWarehouseTagsToTerraform(struct?: DataDatabricksSqlWarehouseTagsOutputReference | DataDatabricksSqlWarehouseTags): any;
export declare function dataDatabricksSqlWarehouseTagsToHclTerraform(struct?: DataDatabricksSqlWarehouseTagsOutputReference | DataDatabricksSqlWarehouseTags): any;
export declare class DataDatabricksSqlWarehouseTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSqlWarehouseTags | undefined;
    set internalValue(value: DataDatabricksSqlWarehouseTags | undefined);
    private _customTags;
    get customTags(): DataDatabricksSqlWarehouseTagsCustomTagsList;
    putCustomTags(value: DataDatabricksSqlWarehouseTagsCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | DataDatabricksSqlWarehouseTagsCustomTags[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse databricks_sql_warehouse}
*/
export declare class DataDatabricksSqlWarehouse extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_sql_warehouse";
    /**
    * Generates CDKTN code for importing a DataDatabricksSqlWarehouse resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSqlWarehouse to import
    * @param importFromId The id of the existing DataDatabricksSqlWarehouse that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSqlWarehouse to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/sql_warehouse databricks_sql_warehouse} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSqlWarehouseConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksSqlWarehouseConfig);
    private _autoStopMins?;
    get autoStopMins(): number;
    set autoStopMins(value: number);
    resetAutoStopMins(): void;
    get autoStopMinsInput(): number | undefined;
    private _clusterSize?;
    get clusterSize(): string;
    set clusterSize(value: string);
    resetClusterSize(): void;
    get clusterSizeInput(): string | undefined;
    private _creatorName?;
    get creatorName(): string;
    set creatorName(value: string);
    resetCreatorName(): void;
    get creatorNameInput(): string | undefined;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    resetDataSourceId(): void;
    get dataSourceIdInput(): string | undefined;
    private _enablePhoton?;
    get enablePhoton(): boolean | cdktn.IResolvable;
    set enablePhoton(value: boolean | cdktn.IResolvable);
    resetEnablePhoton(): void;
    get enablePhotonInput(): boolean | cdktn.IResolvable | undefined;
    private _enableServerlessCompute?;
    get enableServerlessCompute(): boolean | cdktn.IResolvable;
    set enableServerlessCompute(value: boolean | cdktn.IResolvable);
    resetEnableServerlessCompute(): void;
    get enableServerlessComputeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _jdbcUrl?;
    get jdbcUrl(): string;
    set jdbcUrl(value: string);
    resetJdbcUrl(): void;
    get jdbcUrlInput(): string | undefined;
    private _maxNumClusters?;
    get maxNumClusters(): number;
    set maxNumClusters(value: number);
    resetMaxNumClusters(): void;
    get maxNumClustersInput(): number | undefined;
    private _minNumClusters?;
    get minNumClusters(): number;
    set minNumClusters(value: number);
    resetMinNumClusters(): void;
    get minNumClustersInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _numActiveSessions?;
    get numActiveSessions(): number;
    set numActiveSessions(value: number);
    resetNumActiveSessions(): void;
    get numActiveSessionsInput(): number | undefined;
    private _numClusters?;
    get numClusters(): number;
    set numClusters(value: number);
    resetNumClusters(): void;
    get numClustersInput(): number | undefined;
    private _spotInstancePolicy?;
    get spotInstancePolicy(): string;
    set spotInstancePolicy(value: string);
    resetSpotInstancePolicy(): void;
    get spotInstancePolicyInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _warehouseType?;
    get warehouseType(): string;
    set warehouseType(value: string);
    resetWarehouseType(): void;
    get warehouseTypeInput(): string | undefined;
    private _channel;
    get channel(): DataDatabricksSqlWarehouseChannelOutputReference;
    putChannel(value: DataDatabricksSqlWarehouseChannel): void;
    resetChannel(): void;
    get channelInput(): DataDatabricksSqlWarehouseChannel | undefined;
    private _health;
    get health(): DataDatabricksSqlWarehouseHealthOutputReference;
    putHealth(value: DataDatabricksSqlWarehouseHealth): void;
    resetHealth(): void;
    get healthInput(): DataDatabricksSqlWarehouseHealth | undefined;
    private _odbcParams;
    get odbcParams(): DataDatabricksSqlWarehouseOdbcParamsOutputReference;
    putOdbcParams(value: DataDatabricksSqlWarehouseOdbcParams): void;
    resetOdbcParams(): void;
    get odbcParamsInput(): DataDatabricksSqlWarehouseOdbcParams | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSqlWarehouseProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSqlWarehouseProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksSqlWarehouseProviderConfig | undefined;
    private _tags;
    get tags(): DataDatabricksSqlWarehouseTagsOutputReference;
    putTags(value: DataDatabricksSqlWarehouseTags): void;
    resetTags(): void;
    get tagsInput(): DataDatabricksSqlWarehouseTags | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
