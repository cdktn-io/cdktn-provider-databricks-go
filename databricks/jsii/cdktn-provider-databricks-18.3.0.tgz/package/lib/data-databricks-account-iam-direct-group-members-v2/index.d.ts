/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountIamDirectGroupMembersV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_direct_group_members_v2#group_id DataDatabricksAccountIamDirectGroupMembersV2#group_id}
    */
    readonly groupId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_direct_group_members_v2#page_size DataDatabricksAccountIamDirectGroupMembersV2#page_size}
    */
    readonly pageSize?: number;
}
export interface DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_direct_group_members_v2#group_id DataDatabricksAccountIamDirectGroupMembersV2#group_id}
    */
    readonly groupId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_direct_group_members_v2#principal_id DataDatabricksAccountIamDirectGroupMembersV2#principal_id}
    */
    readonly principalId: number;
}
export declare function dataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembersToTerraform(struct?: DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembers): any;
export declare function dataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembersToHclTerraform(struct?: DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembers): any;
export declare class DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembers | undefined;
    set internalValue(value: DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembers | undefined);
    get displayName(): string;
    get externalId(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    get groupIdInput(): number | undefined;
    get membershipSource(): string;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
}
export declare class DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_direct_group_members_v2 databricks_account_iam_direct_group_members_v2}
*/
export declare class DataDatabricksAccountIamDirectGroupMembersV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_iam_direct_group_members_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountIamDirectGroupMembersV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountIamDirectGroupMembersV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountIamDirectGroupMembersV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_direct_group_members_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountIamDirectGroupMembersV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/account_iam_direct_group_members_v2 databricks_account_iam_direct_group_members_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountIamDirectGroupMembersV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountIamDirectGroupMembersV2Config);
    private _directGroupMembers;
    get directGroupMembers(): DataDatabricksAccountIamDirectGroupMembersV2DirectGroupMembersList;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    get groupIdInput(): number | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
