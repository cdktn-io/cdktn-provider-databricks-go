/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDisasterRecoveryFailoverGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#name DataDatabricksDisasterRecoveryFailoverGroup#name}
    */
    readonly name: string;
}
export interface DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#name DataDatabricksDisasterRecoveryFailoverGroup#name}
    */
    readonly name: string;
}
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsToTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs): any;
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsToHclTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs): any;
export declare class DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs | undefined;
    set internalValue(value: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsOutputReference;
}
export interface DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#region DataDatabricksDisasterRecoveryFailoverGroup#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#uri DataDatabricksDisasterRecoveryFailoverGroup#uri}
    */
    readonly uri: string;
}
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionToTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion): any;
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionToHclTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion): any;
export declare class DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion | undefined;
    set internalValue(value: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export declare class DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionOutputReference;
}
export interface DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#name DataDatabricksDisasterRecoveryFailoverGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#uri_by_region DataDatabricksDisasterRecoveryFailoverGroup#uri_by_region}
    */
    readonly uriByRegion: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | cdktn.IResolvable;
}
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsToTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable): any;
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsToHclTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable): any;
export declare class DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _uriByRegion;
    get uriByRegion(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionList;
    putUriByRegion(value: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | cdktn.IResolvable): void;
    get uriByRegionInput(): cdktn.IResolvable | DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | undefined;
}
export declare class DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsOutputReference;
}
export interface DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#catalogs DataDatabricksDisasterRecoveryFailoverGroup#catalogs}
    */
    readonly catalogs: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#data_replication_workspace_set DataDatabricksDisasterRecoveryFailoverGroup#data_replication_workspace_set}
    */
    readonly dataReplicationWorkspaceSet: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#location_mappings DataDatabricksDisasterRecoveryFailoverGroup#location_mappings}
    */
    readonly locationMappings?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | cdktn.IResolvable;
}
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsToTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssets): any;
export declare function dataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsToHclTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssets): any;
export declare class DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssets | undefined;
    set internalValue(value: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssets | undefined);
    private _catalogs;
    get catalogs(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsList;
    putCatalogs(value: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | cdktn.IResolvable): void;
    get catalogsInput(): cdktn.IResolvable | DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | undefined;
    private _dataReplicationWorkspaceSet?;
    get dataReplicationWorkspaceSet(): string;
    set dataReplicationWorkspaceSet(value: string);
    get dataReplicationWorkspaceSetInput(): string | undefined;
    private _locationMappings;
    get locationMappings(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsList;
    putLocationMappings(value: DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | cdktn.IResolvable): void;
    resetLocationMappings(): void;
    get locationMappingsInput(): cdktn.IResolvable | DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | undefined;
}
export interface DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#name DataDatabricksDisasterRecoveryFailoverGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#replicate_workspace_assets DataDatabricksDisasterRecoveryFailoverGroup#replicate_workspace_assets}
    */
    readonly replicateWorkspaceAssets?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#stable_url_names DataDatabricksDisasterRecoveryFailoverGroup#stable_url_names}
    */
    readonly stableUrlNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#workspace_ids DataDatabricksDisasterRecoveryFailoverGroup#workspace_ids}
    */
    readonly workspaceIds: string[];
}
export declare function dataDatabricksDisasterRecoveryFailoverGroupWorkspaceSetsToTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSets): any;
export declare function dataDatabricksDisasterRecoveryFailoverGroupWorkspaceSetsToHclTerraform(struct?: DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSets): any;
export declare class DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSets | undefined;
    set internalValue(value: DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSets | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _replicateWorkspaceAssets?;
    get replicateWorkspaceAssets(): boolean | cdktn.IResolvable;
    set replicateWorkspaceAssets(value: boolean | cdktn.IResolvable);
    resetReplicateWorkspaceAssets(): void;
    get replicateWorkspaceAssetsInput(): boolean | cdktn.IResolvable | undefined;
    private _stableUrlNames?;
    get stableUrlNames(): string[];
    set stableUrlNames(value: string[]);
    resetStableUrlNames(): void;
    get stableUrlNamesInput(): string[] | undefined;
    private _workspaceIds?;
    get workspaceIds(): string[];
    set workspaceIds(value: string[]);
    get workspaceIdsInput(): string[] | undefined;
}
export declare class DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSetsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group databricks_disaster_recovery_failover_group}
*/
export declare class DataDatabricksDisasterRecoveryFailoverGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_disaster_recovery_failover_group";
    /**
    * Generates CDKTN code for importing a DataDatabricksDisasterRecoveryFailoverGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDisasterRecoveryFailoverGroup to import
    * @param importFromId The id of the existing DataDatabricksDisasterRecoveryFailoverGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDisasterRecoveryFailoverGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/disaster_recovery_failover_group databricks_disaster_recovery_failover_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDisasterRecoveryFailoverGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDisasterRecoveryFailoverGroupConfig);
    get createTime(): string;
    get effectivePrimaryRegion(): string;
    get etag(): string;
    get initialPrimaryRegion(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get regions(): string[];
    get replicationPoint(): string;
    get state(): string;
    private _unityCatalogAssets;
    get unityCatalogAssets(): DataDatabricksDisasterRecoveryFailoverGroupUnityCatalogAssetsOutputReference;
    get updateTime(): string;
    private _workspaceSets;
    get workspaceSets(): DataDatabricksDisasterRecoveryFailoverGroupWorkspaceSetsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
