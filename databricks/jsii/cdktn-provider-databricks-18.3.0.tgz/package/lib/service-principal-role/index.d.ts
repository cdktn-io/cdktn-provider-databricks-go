/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServicePrincipalRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role#api ServicePrincipalRole#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role#id ServicePrincipalRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role#role ServicePrincipalRole#role}
    */
    readonly role: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role#service_principal_id ServicePrincipalRole#service_principal_id}
    */
    readonly servicePrincipalId: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role#provider_config ServicePrincipalRole#provider_config}
    */
    readonly providerConfig?: ServicePrincipalRoleProviderConfig;
}
export interface ServicePrincipalRoleProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role#workspace_id ServicePrincipalRole#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function servicePrincipalRoleProviderConfigToTerraform(struct?: ServicePrincipalRoleProviderConfigOutputReference | ServicePrincipalRoleProviderConfig): any;
export declare function servicePrincipalRoleProviderConfigToHclTerraform(struct?: ServicePrincipalRoleProviderConfigOutputReference | ServicePrincipalRoleProviderConfig): any;
export declare class ServicePrincipalRoleProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServicePrincipalRoleProviderConfig | undefined;
    set internalValue(value: ServicePrincipalRoleProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role databricks_service_principal_role}
*/
export declare class ServicePrincipalRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_service_principal_role";
    /**
    * Generates CDKTN code for importing a ServicePrincipalRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServicePrincipalRole to import
    * @param importFromId The id of the existing ServicePrincipalRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServicePrincipalRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/service_principal_role databricks_service_principal_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServicePrincipalRoleConfig
    */
    constructor(scope: Construct, id: string, config: ServicePrincipalRoleConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): ServicePrincipalRoleProviderConfigOutputReference;
    putProviderConfig(value: ServicePrincipalRoleProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ServicePrincipalRoleProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
