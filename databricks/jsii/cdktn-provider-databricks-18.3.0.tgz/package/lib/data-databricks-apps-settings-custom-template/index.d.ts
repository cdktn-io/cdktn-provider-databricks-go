/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppsSettingsCustomTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#name DataDatabricksAppsSettingsCustomTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#provider_config DataDatabricksAppsSettingsCustomTemplate#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppsSettingsCustomTemplateProviderConfig;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#permission DataDatabricksAppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#permission DataDatabricksAppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#permission DataDatabricksAppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#permission DataDatabricksAppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#permission DataDatabricksAppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#permission DataDatabricksAppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#securable_type DataDatabricksAppsSettingsCustomTemplate#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#description DataDatabricksAppsSettingsCustomTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#experiment_spec DataDatabricksAppsSettingsCustomTemplate#experiment_spec}
    */
    readonly experimentSpec?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#job_spec DataDatabricksAppsSettingsCustomTemplate#job_spec}
    */
    readonly jobSpec?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#name DataDatabricksAppsSettingsCustomTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#secret_spec DataDatabricksAppsSettingsCustomTemplate#secret_spec}
    */
    readonly secretSpec?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#serving_endpoint_spec DataDatabricksAppsSettingsCustomTemplate#serving_endpoint_spec}
    */
    readonly servingEndpointSpec?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#sql_warehouse_spec DataDatabricksAppsSettingsCustomTemplate#sql_warehouse_spec}
    */
    readonly sqlWarehouseSpec?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#uc_securable_spec DataDatabricksAppsSettingsCustomTemplate#uc_securable_spec}
    */
    readonly ucSecurableSpec?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experimentSpec;
    get experimentSpec(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpecOutputReference;
    putExperimentSpec(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec): void;
    resetExperimentSpec(): void;
    get experimentSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | undefined;
    private _jobSpec;
    get jobSpec(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpecOutputReference;
    putJobSpec(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec): void;
    resetJobSpec(): void;
    get jobSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsJobSpec | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secretSpec;
    get secretSpec(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpecOutputReference;
    putSecretSpec(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec): void;
    resetSecretSpec(): void;
    get secretSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | undefined;
    private _servingEndpointSpec;
    get servingEndpointSpec(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecOutputReference;
    putServingEndpointSpec(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec): void;
    resetServingEndpointSpec(): void;
    get servingEndpointSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | undefined;
    private _sqlWarehouseSpec;
    get sqlWarehouseSpec(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecOutputReference;
    putSqlWarehouseSpec(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec): void;
    resetSqlWarehouseSpec(): void;
    get sqlWarehouseSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | undefined;
    private _ucSecurableSpec;
    get ucSecurableSpec(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecOutputReference;
    putUcSecurableSpec(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec): void;
    resetUcSecurableSpec(): void;
    get ucSecurableSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | undefined;
}
export declare class DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsOutputReference;
}
export interface DataDatabricksAppsSettingsCustomTemplateManifest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#description DataDatabricksAppsSettingsCustomTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#name DataDatabricksAppsSettingsCustomTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#resource_specs DataDatabricksAppsSettingsCustomTemplate#resource_specs}
    */
    readonly resourceSpecs?: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#version DataDatabricksAppsSettingsCustomTemplate#version}
    */
    readonly version: number;
}
export declare function dataDatabricksAppsSettingsCustomTemplateManifestToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifest): any;
export declare function dataDatabricksAppsSettingsCustomTemplateManifestToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateManifest): any;
export declare class DataDatabricksAppsSettingsCustomTemplateManifestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateManifest | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateManifest | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceSpecs;
    get resourceSpecs(): DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecsList;
    putResourceSpecs(value: DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs[] | cdktn.IResolvable): void;
    resetResourceSpecs(): void;
    get resourceSpecsInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateManifestResourceSpecs[] | undefined;
    private _version?;
    get version(): number;
    set version(value: number);
    get versionInput(): number | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplateProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#workspace_id DataDatabricksAppsSettingsCustomTemplate#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplateProviderConfigToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplateProviderConfigToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplateProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template databricks_apps_settings_custom_template}
*/
export declare class DataDatabricksAppsSettingsCustomTemplate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_apps_settings_custom_template";
    /**
    * Generates CDKTN code for importing a DataDatabricksAppsSettingsCustomTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAppsSettingsCustomTemplate to import
    * @param importFromId The id of the existing DataDatabricksAppsSettingsCustomTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAppsSettingsCustomTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/apps_settings_custom_template databricks_apps_settings_custom_template} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppsSettingsCustomTemplateConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAppsSettingsCustomTemplateConfig);
    get creator(): string;
    get description(): string;
    get gitProvider(): string;
    get gitRepo(): string;
    private _manifest;
    get manifest(): DataDatabricksAppsSettingsCustomTemplateManifestOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get path(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppsSettingsCustomTemplateProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppsSettingsCustomTemplateProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplateProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
