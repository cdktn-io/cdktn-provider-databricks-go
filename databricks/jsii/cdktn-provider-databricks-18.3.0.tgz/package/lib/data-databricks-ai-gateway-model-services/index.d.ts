/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiGatewayModelServicesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#page_size DataDatabricksAiGatewayModelServices#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#parent DataDatabricksAiGatewayModelServices#parent}
    */
    readonly parent?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#provider_config DataDatabricksAiGatewayModelServices#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayModelServicesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#view DataDatabricksAiGatewayModelServices#view}
    */
    readonly view?: string;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#disabled DataDatabricksAiGatewayModelServices#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#parent DataDatabricksAiGatewayModelServices#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#table_name_prefix DataDatabricksAiGatewayModelServices#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTableToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTableToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get table(): string;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#key DataDatabricksAiGatewayModelServices#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#principal DataDatabricksAiGatewayModelServices#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#renewal_period DataDatabricksAiGatewayModelServices#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#request_tag_key DataDatabricksAiGatewayModelServices#request_tag_key}
    */
    readonly requestTagKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#request_tag_value DataDatabricksAiGatewayModelServices#request_tag_value}
    */
    readonly requestTagValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#requests DataDatabricksAiGatewayModelServices#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#tokens DataDatabricksAiGatewayModelServices#tokens}
    */
    readonly tokens?: number;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRateLimitsToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRateLimitsToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requestTagKey?;
    get requestTagKey(): string;
    set requestTagKey(value: string);
    resetRequestTagKey(): void;
    get requestTagKeyInput(): string | undefined;
    private _requestTagValue?;
    get requestTagValue(): string;
    set requestTagValue(value: string);
    resetRequestTagValue(): void;
    get requestTagValueInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimitsOutputReference;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model DataDatabricksAiGatewayModelServices#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#native_api_types DataDatabricksAiGatewayModelServices#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTargetToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTargetToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model_provider_service DataDatabricksAiGatewayModelServices#model_provider_service}
    */
    readonly modelProviderService: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#target DataDatabricksAiGatewayModelServices#target}
    */
    readonly target: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable | undefined);
    private _modelProviderService?;
    get modelProviderService(): string;
    set modelProviderService(value: string);
    get modelProviderServiceInput(): string | undefined;
    private _target;
    get target(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTargetOutputReference;
    putTarget(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget): void;
    get targetInput(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigTarget | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model DataDatabricksAiGatewayModelServices#model}
    */
    readonly model: string;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model_serving_endpoint DataDatabricksAiGatewayModelServices#model_serving_endpoint}
    */
    readonly modelServingEndpoint: string;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined);
    get model(): string;
    private _modelServingEndpoint?;
    get modelServingEndpoint(): string;
    set modelServingEndpoint(value: string);
    get modelServingEndpointInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#destination_type DataDatabricksAiGatewayModelServices#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#external_model_config DataDatabricksAiGatewayModelServices#external_model_config}
    */
    readonly externalModelConfig?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#name DataDatabricksAiGatewayModelServices#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#pay_per_token_config DataDatabricksAiGatewayModelServices#pay_per_token_config}
    */
    readonly payPerTokenConfig?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#provisioned_throughput_config DataDatabricksAiGatewayModelServices#provisioned_throughput_config}
    */
    readonly provisionedThroughputConfig?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#traffic_percentage DataDatabricksAiGatewayModelServices#traffic_percentage}
    */
    readonly trafficPercentage?: number;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations | cdktn.IResolvable | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _externalModelConfig;
    get externalModelConfig(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfigOutputReference;
    putExternalModelConfig(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig): void;
    resetExternalModelConfig(): void;
    get externalModelConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsExternalModelConfig | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _payPerTokenConfig;
    get payPerTokenConfig(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfigOutputReference;
    putPayPerTokenConfig(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig): void;
    resetPayPerTokenConfig(): void;
    get payPerTokenConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsPayPerTokenConfig | undefined;
    private _provisionedThroughputConfig;
    get provisionedThroughputConfig(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfigOutputReference;
    putProvisionedThroughputConfig(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig): void;
    resetProvisionedThroughputConfig(): void;
    get provisionedThroughputConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsProvisionedThroughputConfig | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    resetTrafficPercentage(): void;
    get trafficPercentageInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsOutputReference;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model DataDatabricksAiGatewayModelServices#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#native_api_types DataDatabricksAiGatewayModelServices#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTargetToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTargetToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model_provider_service DataDatabricksAiGatewayModelServices#model_provider_service}
    */
    readonly modelProviderService: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#target DataDatabricksAiGatewayModelServices#target}
    */
    readonly target: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable | undefined);
    private _modelProviderService?;
    get modelProviderService(): string;
    set modelProviderService(value: string);
    get modelProviderServiceInput(): string | undefined;
    private _target;
    get target(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTargetOutputReference;
    putTarget(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget): void;
    get targetInput(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigTarget | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model DataDatabricksAiGatewayModelServices#model}
    */
    readonly model: string;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#model_serving_endpoint DataDatabricksAiGatewayModelServices#model_serving_endpoint}
    */
    readonly modelServingEndpoint: string;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined);
    get model(): string;
    private _modelServingEndpoint?;
    get modelServingEndpoint(): string;
    set modelServingEndpoint(value: string);
    get modelServingEndpointInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#destination_type DataDatabricksAiGatewayModelServices#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#external_model_config DataDatabricksAiGatewayModelServices#external_model_config}
    */
    readonly externalModelConfig?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#name DataDatabricksAiGatewayModelServices#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#pay_per_token_config DataDatabricksAiGatewayModelServices#pay_per_token_config}
    */
    readonly payPerTokenConfig?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#provisioned_throughput_config DataDatabricksAiGatewayModelServices#provisioned_throughput_config}
    */
    readonly provisionedThroughputConfig?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#traffic_percentage DataDatabricksAiGatewayModelServices#traffic_percentage}
    */
    readonly trafficPercentage?: number;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations | cdktn.IResolvable | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _externalModelConfig;
    get externalModelConfig(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfigOutputReference;
    putExternalModelConfig(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig): void;
    resetExternalModelConfig(): void;
    get externalModelConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsExternalModelConfig | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _payPerTokenConfig;
    get payPerTokenConfig(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfigOutputReference;
    putPayPerTokenConfig(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig): void;
    resetPayPerTokenConfig(): void;
    get payPerTokenConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsPayPerTokenConfig | undefined;
    private _provisionedThroughputConfig;
    get provisionedThroughputConfig(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfigOutputReference;
    putProvisionedThroughputConfig(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig): void;
    resetProvisionedThroughputConfig(): void;
    get provisionedThroughputConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsProvisionedThroughputConfig | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    resetTrafficPercentage(): void;
    get trafficPercentageInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsOutputReference;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#destinations DataDatabricksAiGatewayModelServices#destinations}
    */
    readonly destinations?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations[] | cdktn.IResolvable;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback | cdktn.IResolvable | undefined);
    private _destinations;
    get destinations(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinationsList;
    putDestinations(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackDestinations[] | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting {
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplittingToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplittingToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplittingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting | cdktn.IResolvable | undefined);
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfigRouting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#destinations DataDatabricksAiGatewayModelServices#destinations}
    */
    readonly destinations?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#fallback DataDatabricksAiGatewayModelServices#fallback}
    */
    readonly fallback?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#first_token_timeout DataDatabricksAiGatewayModelServices#first_token_timeout}
    */
    readonly firstTokenTimeout?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#traffic_splitting DataDatabricksAiGatewayModelServices#traffic_splitting}
    */
    readonly trafficSplitting?: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRouting | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigRoutingToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfigRouting | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfigRouting | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRouting | cdktn.IResolvable | undefined);
    private _destinations;
    get destinations(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinationsList;
    putDestinations(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingDestinations[] | undefined;
    private _fallback;
    get fallback(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallbackOutputReference;
    putFallback(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback): void;
    resetFallback(): void;
    get fallbackInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingFallback | undefined;
    private _firstTokenTimeout?;
    get firstTokenTimeout(): string;
    set firstTokenTimeout(value: string);
    resetFirstTokenTimeout(): void;
    get firstTokenTimeoutInput(): string | undefined;
    private _trafficSplitting;
    get trafficSplitting(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplittingOutputReference;
    putTrafficSplitting(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting): void;
    resetTrafficSplitting(): void;
    get trafficSplittingInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingTrafficSplitting | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#inference_table DataDatabricksAiGatewayModelServices#inference_table}
    */
    readonly inferenceTable?: DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#rate_limits DataDatabricksAiGatewayModelServices#rate_limits}
    */
    readonly rateLimits?: DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#routing DataDatabricksAiGatewayModelServices#routing}
    */
    readonly routing?: DataDatabricksAiGatewayModelServicesModelServicesConfigRouting;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfig): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesConfig): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesConfig | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesConfig | undefined);
    private _inferenceTable;
    get inferenceTable(): DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTableOutputReference;
    putInferenceTable(value: DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable): void;
    resetInferenceTable(): void;
    get inferenceTableInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigInferenceTable | undefined;
    private _rateLimits;
    get rateLimits(): DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimitsList;
    putRateLimits(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRateLimits[] | undefined;
    private _routing;
    get routing(): DataDatabricksAiGatewayModelServicesModelServicesConfigRoutingOutputReference;
    putRouting(value: DataDatabricksAiGatewayModelServicesModelServicesConfigRouting): void;
    resetRouting(): void;
    get routingInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesConfigRouting | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServicesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#workspace_id DataDatabricksAiGatewayModelServices#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesProviderConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServicesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServicesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServicesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServicesModelServices {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#name DataDatabricksAiGatewayModelServices#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#provider_config DataDatabricksAiGatewayModelServices#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayModelServicesModelServicesProviderConfig;
}
export declare function dataDatabricksAiGatewayModelServicesModelServicesToTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServices): any;
export declare function dataDatabricksAiGatewayModelServicesModelServicesToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesModelServices): any;
export declare class DataDatabricksAiGatewayModelServicesModelServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelServicesModelServices | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesModelServices | undefined);
    get comment(): string;
    private _config;
    get config(): DataDatabricksAiGatewayModelServicesModelServicesConfigOutputReference;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get owner(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayModelServicesModelServicesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayModelServicesModelServicesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesModelServicesProviderConfig | undefined;
    get supportedApiTypes(): string[];
    get updateTime(): string;
    get updatedBy(): string;
}
export declare class DataDatabricksAiGatewayModelServicesModelServicesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelServicesModelServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelServicesModelServicesOutputReference;
}
export interface DataDatabricksAiGatewayModelServicesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#workspace_id DataDatabricksAiGatewayModelServices#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayModelServicesProviderConfigToTerraform(struct?: DataDatabricksAiGatewayModelServicesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServicesProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServicesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServicesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServicesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServicesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services databricks_ai_gateway_model_services}
*/
export declare class DataDatabricksAiGatewayModelServices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_gateway_model_services";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiGatewayModelServices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiGatewayModelServices to import
    * @param importFromId The id of the existing DataDatabricksAiGatewayModelServices that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiGatewayModelServices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/data-sources/ai_gateway_model_services databricks_ai_gateway_model_services} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiGatewayModelServicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAiGatewayModelServicesConfig);
    private _modelServices;
    get modelServices(): DataDatabricksAiGatewayModelServicesModelServicesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayModelServicesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayModelServicesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServicesProviderConfig | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
