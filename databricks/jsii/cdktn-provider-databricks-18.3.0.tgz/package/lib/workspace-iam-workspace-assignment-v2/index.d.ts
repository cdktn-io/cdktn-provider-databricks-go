/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceIamWorkspaceAssignmentV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2#entitlements WorkspaceIamWorkspaceAssignmentV2#entitlements}
    */
    readonly entitlements?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2#principal_id WorkspaceIamWorkspaceAssignmentV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2#provider_config WorkspaceIamWorkspaceAssignmentV2#provider_config}
    */
    readonly providerConfig?: WorkspaceIamWorkspaceAssignmentV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2#workspace_id WorkspaceIamWorkspaceAssignmentV2#workspace_id}
    */
    readonly workspaceId?: number;
}
export interface WorkspaceIamWorkspaceAssignmentV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2#workspace_id WorkspaceIamWorkspaceAssignmentV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceIamWorkspaceAssignmentV2ProviderConfigToTerraform(struct?: WorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceIamWorkspaceAssignmentV2ProviderConfigToHclTerraform(struct?: WorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceIamWorkspaceAssignmentV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2 databricks_workspace_iam_workspace_assignment_v2}
*/
export declare class WorkspaceIamWorkspaceAssignmentV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_iam_workspace_assignment_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceIamWorkspaceAssignmentV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceIamWorkspaceAssignmentV2 to import
    * @param importFromId The id of the existing WorkspaceIamWorkspaceAssignmentV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceIamWorkspaceAssignmentV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.128.0/docs/resources/workspace_iam_workspace_assignment_v2 databricks_workspace_iam_workspace_assignment_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceIamWorkspaceAssignmentV2Config
    */
    constructor(scope: Construct, id: string, config: WorkspaceIamWorkspaceAssignmentV2Config);
    get accountId(): string;
    get effectiveEntitlements(): string[];
    private _entitlements?;
    get entitlements(): string[];
    set entitlements(value: string[]);
    resetEntitlements(): void;
    get entitlementsInput(): string[] | undefined;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): WorkspaceIamWorkspaceAssignmentV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceIamWorkspaceAssignmentV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceIamWorkspaceAssignmentV2ProviderConfig | undefined;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    resetWorkspaceId(): void;
    get workspaceIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
