/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonSessionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session#name DataDatabricksMasonSession#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session#provider_config DataDatabricksMasonSession#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonSessionProviderConfig;
}
export interface DataDatabricksMasonSessionProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session#workspace_id DataDatabricksMasonSession#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonSessionProviderConfigToTerraform(struct?: DataDatabricksMasonSessionProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonSessionProviderConfigToHclTerraform(struct?: DataDatabricksMasonSessionProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonSessionProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonSessionProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonSessionProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session databricks_mason_session}
*/
export declare class DataDatabricksMasonSession extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_session";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonSession resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonSession to import
    * @param importFromId The id of the existing DataDatabricksMasonSession that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonSession to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session databricks_mason_session} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonSessionConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMasonSessionConfig);
    get actorId(): string;
    get createTime(): string;
    get lastActivityTime(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentSessionId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonSessionProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonSessionProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonSessionProviderConfig | undefined;
    get rootSessionId(): string;
    get sessionId(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
