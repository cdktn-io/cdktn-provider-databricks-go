/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonSessionStoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores#page_size DataDatabricksMasonSessionStores#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores#provider_config DataDatabricksMasonSessionStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonSessionStoresProviderConfig;
}
export interface DataDatabricksMasonSessionStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores#workspace_id DataDatabricksMasonSessionStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonSessionStoresProviderConfigToTerraform(struct?: DataDatabricksMasonSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonSessionStoresProviderConfigToHclTerraform(struct?: DataDatabricksMasonSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonSessionStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonSessionStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonSessionStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMasonSessionStoresSessionStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores#workspace_id DataDatabricksMasonSessionStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonSessionStoresSessionStoresProviderConfigToTerraform(struct?: DataDatabricksMasonSessionStoresSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonSessionStoresSessionStoresProviderConfigToHclTerraform(struct?: DataDatabricksMasonSessionStoresSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonSessionStoresSessionStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonSessionStoresSessionStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonSessionStoresSessionStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMasonSessionStoresSessionStores {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores#name DataDatabricksMasonSessionStores#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores#provider_config DataDatabricksMasonSessionStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonSessionStoresSessionStoresProviderConfig;
}
export declare function dataDatabricksMasonSessionStoresSessionStoresToTerraform(struct?: DataDatabricksMasonSessionStoresSessionStores): any;
export declare function dataDatabricksMasonSessionStoresSessionStoresToHclTerraform(struct?: DataDatabricksMasonSessionStoresSessionStores): any;
export declare class DataDatabricksMasonSessionStoresSessionStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMasonSessionStoresSessionStores | undefined;
    set internalValue(value: DataDatabricksMasonSessionStoresSessionStores | undefined);
    get createTime(): string;
    get creatorUserId(): string;
    get description(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonSessionStoresSessionStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonSessionStoresSessionStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonSessionStoresSessionStoresProviderConfig | undefined;
    get updateTime(): string;
}
export declare class DataDatabricksMasonSessionStoresSessionStoresList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMasonSessionStoresSessionStores[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMasonSessionStoresSessionStoresOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores databricks_mason_session_stores}
*/
export declare class DataDatabricksMasonSessionStores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_session_stores";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonSessionStores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonSessionStores to import
    * @param importFromId The id of the existing DataDatabricksMasonSessionStores that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonSessionStores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_stores databricks_mason_session_stores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonSessionStoresConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksMasonSessionStoresConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonSessionStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonSessionStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonSessionStoresProviderConfig | undefined;
    private _sessionStores;
    get sessionStores(): DataDatabricksMasonSessionStoresSessionStoresList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
