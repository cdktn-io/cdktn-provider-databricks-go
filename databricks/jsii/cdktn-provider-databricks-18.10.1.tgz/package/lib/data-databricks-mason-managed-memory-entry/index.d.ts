/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonManagedMemoryEntryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entry#name DataDatabricksMasonManagedMemoryEntry#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entry#provider_config DataDatabricksMasonManagedMemoryEntry#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonManagedMemoryEntryProviderConfig;
}
export interface DataDatabricksMasonManagedMemoryEntryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entry#workspace_id DataDatabricksMasonManagedMemoryEntry#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonManagedMemoryEntryProviderConfigToTerraform(struct?: DataDatabricksMasonManagedMemoryEntryProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonManagedMemoryEntryProviderConfigToHclTerraform(struct?: DataDatabricksMasonManagedMemoryEntryProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonManagedMemoryEntryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryEntryProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryEntryProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entry databricks_mason_managed_memory_entry}
*/
export declare class DataDatabricksMasonManagedMemoryEntry extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_managed_memory_entry";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonManagedMemoryEntry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonManagedMemoryEntry to import
    * @param importFromId The id of the existing DataDatabricksMasonManagedMemoryEntry that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonManagedMemoryEntry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entry databricks_mason_managed_memory_entry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonManagedMemoryEntryConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMasonManagedMemoryEntryConfig);
    get actorId(): string;
    get content(): string;
    get createTime(): string;
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get path(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonManagedMemoryEntryProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonManagedMemoryEntryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonManagedMemoryEntryProviderConfig | undefined;
    get sessionId(): string;
    get sourceType(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
