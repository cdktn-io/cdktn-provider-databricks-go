/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonSessionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#filter DataDatabricksMasonSessions#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#order_by DataDatabricksMasonSessions#order_by}
    */
    readonly orderBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#page_size DataDatabricksMasonSessions#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#parent DataDatabricksMasonSessions#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#provider_config DataDatabricksMasonSessions#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonSessionsProviderConfig;
}
export interface DataDatabricksMasonSessionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#workspace_id DataDatabricksMasonSessions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonSessionsProviderConfigToTerraform(struct?: DataDatabricksMasonSessionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonSessionsProviderConfigToHclTerraform(struct?: DataDatabricksMasonSessionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonSessionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonSessionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonSessionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMasonSessionsSessionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#workspace_id DataDatabricksMasonSessions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonSessionsSessionsProviderConfigToTerraform(struct?: DataDatabricksMasonSessionsSessionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonSessionsSessionsProviderConfigToHclTerraform(struct?: DataDatabricksMasonSessionsSessionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonSessionsSessionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonSessionsSessionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonSessionsSessionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMasonSessionsSessions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#name DataDatabricksMasonSessions#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#provider_config DataDatabricksMasonSessions#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonSessionsSessionsProviderConfig;
}
export declare function dataDatabricksMasonSessionsSessionsToTerraform(struct?: DataDatabricksMasonSessionsSessions): any;
export declare function dataDatabricksMasonSessionsSessionsToHclTerraform(struct?: DataDatabricksMasonSessionsSessions): any;
export declare class DataDatabricksMasonSessionsSessionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMasonSessionsSessions | undefined;
    set internalValue(value: DataDatabricksMasonSessionsSessions | undefined);
    get actorId(): string;
    get createTime(): string;
    get lastActivityTime(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentSessionId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonSessionsSessionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonSessionsSessionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonSessionsSessionsProviderConfig | undefined;
    get rootSessionId(): string;
    get sessionId(): string;
    get updateTime(): string;
}
export declare class DataDatabricksMasonSessionsSessionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMasonSessionsSessions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMasonSessionsSessionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions databricks_mason_sessions}
*/
export declare class DataDatabricksMasonSessions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_sessions";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonSessions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonSessions to import
    * @param importFromId The id of the existing DataDatabricksMasonSessions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonSessions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_sessions databricks_mason_sessions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonSessionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMasonSessionsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonSessionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonSessionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonSessionsProviderConfig | undefined;
    private _sessions;
    get sessions(): DataDatabricksMasonSessionsSessionsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
