/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonSessionStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_store#name DataDatabricksMasonSessionStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_store#provider_config DataDatabricksMasonSessionStore#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonSessionStoreProviderConfig;
}
export interface DataDatabricksMasonSessionStoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_store#workspace_id DataDatabricksMasonSessionStore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonSessionStoreProviderConfigToTerraform(struct?: DataDatabricksMasonSessionStoreProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonSessionStoreProviderConfigToHclTerraform(struct?: DataDatabricksMasonSessionStoreProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonSessionStoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonSessionStoreProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonSessionStoreProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_store databricks_mason_session_store}
*/
export declare class DataDatabricksMasonSessionStore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_session_store";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonSessionStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonSessionStore to import
    * @param importFromId The id of the existing DataDatabricksMasonSessionStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonSessionStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_session_store databricks_mason_session_store} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonSessionStoreConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMasonSessionStoreConfig);
    get createTime(): string;
    get creatorUserId(): string;
    get description(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonSessionStoreProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonSessionStoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonSessionStoreProviderConfig | undefined;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
