/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MasonManagedMemoryStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store#description MasonManagedMemoryStore#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store#display_name MasonManagedMemoryStore#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store#managed_memory_store_id MasonManagedMemoryStore#managed_memory_store_id}
    */
    readonly managedMemoryStoreId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store#provider_config MasonManagedMemoryStore#provider_config}
    */
    readonly providerConfig?: MasonManagedMemoryStoreProviderConfig;
}
export interface MasonManagedMemoryStoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store#workspace_id MasonManagedMemoryStore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function masonManagedMemoryStoreProviderConfigToTerraform(struct?: MasonManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare function masonManagedMemoryStoreProviderConfigToHclTerraform(struct?: MasonManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare class MasonManagedMemoryStoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MasonManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: MasonManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface MasonManagedMemoryStoreStorageBackend {
}
export declare function masonManagedMemoryStoreStorageBackendToTerraform(struct?: MasonManagedMemoryStoreStorageBackend): any;
export declare function masonManagedMemoryStoreStorageBackendToHclTerraform(struct?: MasonManagedMemoryStoreStorageBackend): any;
export declare class MasonManagedMemoryStoreStorageBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MasonManagedMemoryStoreStorageBackend | undefined;
    set internalValue(value: MasonManagedMemoryStoreStorageBackend | undefined);
    get backendId(): string;
    get backendType(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store databricks_mason_managed_memory_store}
*/
export declare class MasonManagedMemoryStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mason_managed_memory_store";
    /**
    * Generates CDKTN code for importing a MasonManagedMemoryStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MasonManagedMemoryStore to import
    * @param importFromId The id of the existing MasonManagedMemoryStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MasonManagedMemoryStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/mason_managed_memory_store databricks_mason_managed_memory_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MasonManagedMemoryStoreConfig
    */
    constructor(scope: Construct, id: string, config: MasonManagedMemoryStoreConfig);
    get createTime(): string;
    get creatorUserId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _managedMemoryStoreId?;
    get managedMemoryStoreId(): string;
    set managedMemoryStoreId(value: string);
    get managedMemoryStoreIdInput(): string | undefined;
    get name(): string;
    get ownerUserId(): string;
    private _providerConfig;
    get providerConfig(): MasonManagedMemoryStoreProviderConfigOutputReference;
    putProviderConfig(value: MasonManagedMemoryStoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | MasonManagedMemoryStoreProviderConfig | undefined;
    private _storageBackend;
    get storageBackend(): MasonManagedMemoryStoreStorageBackendOutputReference;
    get updateTime(): string;
    get workspaceId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
