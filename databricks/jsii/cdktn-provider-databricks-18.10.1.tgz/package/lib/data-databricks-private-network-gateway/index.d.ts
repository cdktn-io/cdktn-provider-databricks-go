/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPrivateNetworkGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#name DataDatabricksPrivateNetworkGateway#name}
    */
    readonly name: string;
}
export interface DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#role_arn DataDatabricksPrivateNetworkGateway#role_arn}
    */
    readonly roleArn: string;
}
export declare function dataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRoleToTerraform(struct?: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole): any;
export declare function dataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRoleToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole): any;
export declare class DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | undefined);
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#subnet_id DataDatabricksPrivateNetworkGateway#subnet_id}
    */
    readonly subnetId: string;
}
export declare function dataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsToTerraform(struct?: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets): any;
export declare function dataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets): any;
export declare class DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets | undefined);
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
}
export declare class DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsOutputReference;
}
export interface DataDatabricksPrivateNetworkGatewayAwsCloudConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#cross_account_role DataDatabricksPrivateNetworkGateway#cross_account_role}
    */
    readonly crossAccountRole: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#gateway_subnets DataDatabricksPrivateNetworkGateway#gateway_subnets}
    */
    readonly gatewaySubnets: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#security_group_ids DataDatabricksPrivateNetworkGateway#security_group_ids}
    */
    readonly securityGroupIds: string[];
}
export declare function dataDatabricksPrivateNetworkGatewayAwsCloudConnectionToTerraform(struct?: DataDatabricksPrivateNetworkGatewayAwsCloudConnection): any;
export declare function dataDatabricksPrivateNetworkGatewayAwsCloudConnectionToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewayAwsCloudConnection): any;
export declare class DataDatabricksPrivateNetworkGatewayAwsCloudConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewayAwsCloudConnection | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewayAwsCloudConnection | undefined);
    private _crossAccountRole;
    get crossAccountRole(): DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRoleOutputReference;
    putCrossAccountRole(value: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole): void;
    get crossAccountRoleInput(): DataDatabricksPrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | undefined;
    private _gatewaySubnets;
    get gatewaySubnets(): DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsList;
    putGatewaySubnets(value: DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable): void;
    get gatewaySubnetsInput(): cdktn.IResolvable | DataDatabricksPrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    get securityGroupIdsInput(): string[] | undefined;
}
export interface DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#resource_id DataDatabricksPrivateNetworkGateway#resource_id}
    */
    readonly resourceId: string;
}
export declare function dataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnetToTerraform(struct?: DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet): any;
export declare function dataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnetToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet): any;
export declare class DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | undefined);
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
}
export interface DataDatabricksPrivateNetworkGatewayAzureCloudConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#gateway_subnet DataDatabricksPrivateNetworkGateway#gateway_subnet}
    */
    readonly gatewaySubnet: DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet;
}
export declare function dataDatabricksPrivateNetworkGatewayAzureCloudConnectionToTerraform(struct?: DataDatabricksPrivateNetworkGatewayAzureCloudConnection): any;
export declare function dataDatabricksPrivateNetworkGatewayAzureCloudConnectionToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewayAzureCloudConnection): any;
export declare class DataDatabricksPrivateNetworkGatewayAzureCloudConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewayAzureCloudConnection | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewayAzureCloudConnection | undefined);
    private _gatewaySubnet;
    get gatewaySubnet(): DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnetOutputReference;
    putGatewaySubnet(value: DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet): void;
    get gatewaySubnetInput(): DataDatabricksPrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | undefined;
}
export interface DataDatabricksPrivateNetworkGatewayDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#destination_type DataDatabricksPrivateNetworkGateway#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#value DataDatabricksPrivateNetworkGateway#value}
    */
    readonly value: string;
}
export declare function dataDatabricksPrivateNetworkGatewayDestinationsToTerraform(struct?: DataDatabricksPrivateNetworkGatewayDestinations): any;
export declare function dataDatabricksPrivateNetworkGatewayDestinationsToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewayDestinations): any;
export declare class DataDatabricksPrivateNetworkGatewayDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPrivateNetworkGatewayDestinations | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewayDestinations | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPrivateNetworkGatewayDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPrivateNetworkGatewayDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPrivateNetworkGatewayDestinationsOutputReference;
}
export interface DataDatabricksPrivateNetworkGatewayPrivateDnsResolvers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#resolver_type DataDatabricksPrivateNetworkGateway#resolver_type}
    */
    readonly resolverType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#value DataDatabricksPrivateNetworkGateway#value}
    */
    readonly value: string;
}
export declare function dataDatabricksPrivateNetworkGatewayPrivateDnsResolversToTerraform(struct?: DataDatabricksPrivateNetworkGatewayPrivateDnsResolvers): any;
export declare function dataDatabricksPrivateNetworkGatewayPrivateDnsResolversToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewayPrivateDnsResolvers): any;
export declare class DataDatabricksPrivateNetworkGatewayPrivateDnsResolversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPrivateNetworkGatewayPrivateDnsResolvers | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewayPrivateDnsResolvers | undefined);
    private _resolverType?;
    get resolverType(): string;
    set resolverType(value: string);
    get resolverTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPrivateNetworkGatewayPrivateDnsResolversList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPrivateNetworkGatewayPrivateDnsResolvers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPrivateNetworkGatewayPrivateDnsResolversOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway databricks_private_network_gateway}
*/
export declare class DataDatabricksPrivateNetworkGateway extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_private_network_gateway";
    /**
    * Generates CDKTN code for importing a DataDatabricksPrivateNetworkGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPrivateNetworkGateway to import
    * @param importFromId The id of the existing DataDatabricksPrivateNetworkGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPrivateNetworkGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateway databricks_private_network_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPrivateNetworkGatewayConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPrivateNetworkGatewayConfig);
    private _awsCloudConnection;
    get awsCloudConnection(): DataDatabricksPrivateNetworkGatewayAwsCloudConnectionOutputReference;
    private _azureCloudConnection;
    get azureCloudConnection(): DataDatabricksPrivateNetworkGatewayAzureCloudConnectionOutputReference;
    get bandwidthTierGigabitsPerSecond(): number;
    get createTime(): string;
    private _destinations;
    get destinations(): DataDatabricksPrivateNetworkGatewayDestinationsList;
    get displayName(): string;
    get errorMessage(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privateDnsResolvers;
    get privateDnsResolvers(): DataDatabricksPrivateNetworkGatewayPrivateDnsResolversList;
    get state(): string;
    get trafficMode(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
