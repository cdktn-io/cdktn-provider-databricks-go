/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonManagedMemoryStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_store#name DataDatabricksMasonManagedMemoryStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_store#provider_config DataDatabricksMasonManagedMemoryStore#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonManagedMemoryStoreProviderConfig;
}
export interface DataDatabricksMasonManagedMemoryStoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_store#workspace_id DataDatabricksMasonManagedMemoryStore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonManagedMemoryStoreProviderConfigToTerraform(struct?: DataDatabricksMasonManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonManagedMemoryStoreProviderConfigToHclTerraform(struct?: DataDatabricksMasonManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonManagedMemoryStoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMasonManagedMemoryStoreStorageBackend {
}
export declare function dataDatabricksMasonManagedMemoryStoreStorageBackendToTerraform(struct?: DataDatabricksMasonManagedMemoryStoreStorageBackend): any;
export declare function dataDatabricksMasonManagedMemoryStoreStorageBackendToHclTerraform(struct?: DataDatabricksMasonManagedMemoryStoreStorageBackend): any;
export declare class DataDatabricksMasonManagedMemoryStoreStorageBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryStoreStorageBackend | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryStoreStorageBackend | undefined);
    get backendId(): string;
    get backendType(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_store databricks_mason_managed_memory_store}
*/
export declare class DataDatabricksMasonManagedMemoryStore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_managed_memory_store";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonManagedMemoryStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonManagedMemoryStore to import
    * @param importFromId The id of the existing DataDatabricksMasonManagedMemoryStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonManagedMemoryStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_store databricks_mason_managed_memory_store} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonManagedMemoryStoreConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMasonManagedMemoryStoreConfig);
    get createTime(): string;
    get creatorUserId(): string;
    get description(): string;
    get displayName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerUserId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonManagedMemoryStoreProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonManagedMemoryStoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonManagedMemoryStoreProviderConfig | undefined;
    private _storageBackend;
    get storageBackend(): DataDatabricksMasonManagedMemoryStoreStorageBackendOutputReference;
    get updateTime(): string;
    get workspaceId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
