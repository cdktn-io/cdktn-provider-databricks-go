/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PrivateNetworkGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#aws_cloud_connection PrivateNetworkGateway#aws_cloud_connection}
    */
    readonly awsCloudConnection?: PrivateNetworkGatewayAwsCloudConnection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#azure_cloud_connection PrivateNetworkGateway#azure_cloud_connection}
    */
    readonly azureCloudConnection?: PrivateNetworkGatewayAzureCloudConnection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#bandwidth_tier_gigabits_per_second PrivateNetworkGateway#bandwidth_tier_gigabits_per_second}
    */
    readonly bandwidthTierGigabitsPerSecond?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#destinations PrivateNetworkGateway#destinations}
    */
    readonly destinations?: PrivateNetworkGatewayDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#display_name PrivateNetworkGateway#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#parent PrivateNetworkGateway#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#private_dns_resolvers PrivateNetworkGateway#private_dns_resolvers}
    */
    readonly privateDnsResolvers?: PrivateNetworkGatewayPrivateDnsResolvers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#traffic_mode PrivateNetworkGateway#traffic_mode}
    */
    readonly trafficMode: string;
}
export interface PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#role_arn PrivateNetworkGateway#role_arn}
    */
    readonly roleArn: string;
}
export declare function privateNetworkGatewayAwsCloudConnectionCrossAccountRoleToTerraform(struct?: PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | cdktn.IResolvable): any;
export declare function privateNetworkGatewayAwsCloudConnectionCrossAccountRoleToHclTerraform(struct?: PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | cdktn.IResolvable): any;
export declare class PrivateNetworkGatewayAwsCloudConnectionCrossAccountRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | cdktn.IResolvable | undefined);
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#subnet_id PrivateNetworkGateway#subnet_id}
    */
    readonly subnetId: string;
}
export declare function privateNetworkGatewayAwsCloudConnectionGatewaySubnetsToTerraform(struct?: PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets | cdktn.IResolvable): any;
export declare function privateNetworkGatewayAwsCloudConnectionGatewaySubnetsToHclTerraform(struct?: PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets | cdktn.IResolvable): any;
export declare class PrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets | cdktn.IResolvable | undefined);
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
}
export declare class PrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsList extends cdktn.ComplexList {
    internalValue?: PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsOutputReference;
}
export interface PrivateNetworkGatewayAwsCloudConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#cross_account_role PrivateNetworkGateway#cross_account_role}
    */
    readonly crossAccountRole: PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#gateway_subnets PrivateNetworkGateway#gateway_subnets}
    */
    readonly gatewaySubnets: PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#security_group_ids PrivateNetworkGateway#security_group_ids}
    */
    readonly securityGroupIds: string[];
}
export declare function privateNetworkGatewayAwsCloudConnectionToTerraform(struct?: PrivateNetworkGatewayAwsCloudConnection | cdktn.IResolvable): any;
export declare function privateNetworkGatewayAwsCloudConnectionToHclTerraform(struct?: PrivateNetworkGatewayAwsCloudConnection | cdktn.IResolvable): any;
export declare class PrivateNetworkGatewayAwsCloudConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateNetworkGatewayAwsCloudConnection | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateNetworkGatewayAwsCloudConnection | cdktn.IResolvable | undefined);
    private _crossAccountRole;
    get crossAccountRole(): PrivateNetworkGatewayAwsCloudConnectionCrossAccountRoleOutputReference;
    putCrossAccountRole(value: PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole): void;
    get crossAccountRoleInput(): cdktn.IResolvable | PrivateNetworkGatewayAwsCloudConnectionCrossAccountRole | undefined;
    private _gatewaySubnets;
    get gatewaySubnets(): PrivateNetworkGatewayAwsCloudConnectionGatewaySubnetsList;
    putGatewaySubnets(value: PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable): void;
    get gatewaySubnetsInput(): cdktn.IResolvable | PrivateNetworkGatewayAwsCloudConnectionGatewaySubnets[] | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    get securityGroupIdsInput(): string[] | undefined;
}
export interface PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#resource_id PrivateNetworkGateway#resource_id}
    */
    readonly resourceId: string;
}
export declare function privateNetworkGatewayAzureCloudConnectionGatewaySubnetToTerraform(struct?: PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | cdktn.IResolvable): any;
export declare function privateNetworkGatewayAzureCloudConnectionGatewaySubnetToHclTerraform(struct?: PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | cdktn.IResolvable): any;
export declare class PrivateNetworkGatewayAzureCloudConnectionGatewaySubnetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | cdktn.IResolvable | undefined);
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
}
export interface PrivateNetworkGatewayAzureCloudConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#gateway_subnet PrivateNetworkGateway#gateway_subnet}
    */
    readonly gatewaySubnet: PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet;
}
export declare function privateNetworkGatewayAzureCloudConnectionToTerraform(struct?: PrivateNetworkGatewayAzureCloudConnection | cdktn.IResolvable): any;
export declare function privateNetworkGatewayAzureCloudConnectionToHclTerraform(struct?: PrivateNetworkGatewayAzureCloudConnection | cdktn.IResolvable): any;
export declare class PrivateNetworkGatewayAzureCloudConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivateNetworkGatewayAzureCloudConnection | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateNetworkGatewayAzureCloudConnection | cdktn.IResolvable | undefined);
    private _gatewaySubnet;
    get gatewaySubnet(): PrivateNetworkGatewayAzureCloudConnectionGatewaySubnetOutputReference;
    putGatewaySubnet(value: PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet): void;
    get gatewaySubnetInput(): cdktn.IResolvable | PrivateNetworkGatewayAzureCloudConnectionGatewaySubnet | undefined;
}
export interface PrivateNetworkGatewayDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#destination_type PrivateNetworkGateway#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#value PrivateNetworkGateway#value}
    */
    readonly value: string;
}
export declare function privateNetworkGatewayDestinationsToTerraform(struct?: PrivateNetworkGatewayDestinations | cdktn.IResolvable): any;
export declare function privateNetworkGatewayDestinationsToHclTerraform(struct?: PrivateNetworkGatewayDestinations | cdktn.IResolvable): any;
export declare class PrivateNetworkGatewayDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PrivateNetworkGatewayDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateNetworkGatewayDestinations | cdktn.IResolvable | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class PrivateNetworkGatewayDestinationsList extends cdktn.ComplexList {
    internalValue?: PrivateNetworkGatewayDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PrivateNetworkGatewayDestinationsOutputReference;
}
export interface PrivateNetworkGatewayPrivateDnsResolvers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#resolver_type PrivateNetworkGateway#resolver_type}
    */
    readonly resolverType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#value PrivateNetworkGateway#value}
    */
    readonly value: string;
}
export declare function privateNetworkGatewayPrivateDnsResolversToTerraform(struct?: PrivateNetworkGatewayPrivateDnsResolvers | cdktn.IResolvable): any;
export declare function privateNetworkGatewayPrivateDnsResolversToHclTerraform(struct?: PrivateNetworkGatewayPrivateDnsResolvers | cdktn.IResolvable): any;
export declare class PrivateNetworkGatewayPrivateDnsResolversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PrivateNetworkGatewayPrivateDnsResolvers | cdktn.IResolvable | undefined;
    set internalValue(value: PrivateNetworkGatewayPrivateDnsResolvers | cdktn.IResolvable | undefined);
    private _resolverType?;
    get resolverType(): string;
    set resolverType(value: string);
    get resolverTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class PrivateNetworkGatewayPrivateDnsResolversList extends cdktn.ComplexList {
    internalValue?: PrivateNetworkGatewayPrivateDnsResolvers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PrivateNetworkGatewayPrivateDnsResolversOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway databricks_private_network_gateway}
*/
export declare class PrivateNetworkGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_private_network_gateway";
    /**
    * Generates CDKTN code for importing a PrivateNetworkGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrivateNetworkGateway to import
    * @param importFromId The id of the existing PrivateNetworkGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrivateNetworkGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/resources/private_network_gateway databricks_private_network_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrivateNetworkGatewayConfig
    */
    constructor(scope: Construct, id: string, config: PrivateNetworkGatewayConfig);
    private _awsCloudConnection;
    get awsCloudConnection(): PrivateNetworkGatewayAwsCloudConnectionOutputReference;
    putAwsCloudConnection(value: PrivateNetworkGatewayAwsCloudConnection): void;
    resetAwsCloudConnection(): void;
    get awsCloudConnectionInput(): cdktn.IResolvable | PrivateNetworkGatewayAwsCloudConnection | undefined;
    private _azureCloudConnection;
    get azureCloudConnection(): PrivateNetworkGatewayAzureCloudConnectionOutputReference;
    putAzureCloudConnection(value: PrivateNetworkGatewayAzureCloudConnection): void;
    resetAzureCloudConnection(): void;
    get azureCloudConnectionInput(): cdktn.IResolvable | PrivateNetworkGatewayAzureCloudConnection | undefined;
    private _bandwidthTierGigabitsPerSecond?;
    get bandwidthTierGigabitsPerSecond(): number;
    set bandwidthTierGigabitsPerSecond(value: number);
    resetBandwidthTierGigabitsPerSecond(): void;
    get bandwidthTierGigabitsPerSecondInput(): number | undefined;
    get createTime(): string;
    private _destinations;
    get destinations(): PrivateNetworkGatewayDestinationsList;
    putDestinations(value: PrivateNetworkGatewayDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | PrivateNetworkGatewayDestinations[] | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get errorMessage(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _privateDnsResolvers;
    get privateDnsResolvers(): PrivateNetworkGatewayPrivateDnsResolversList;
    putPrivateDnsResolvers(value: PrivateNetworkGatewayPrivateDnsResolvers[] | cdktn.IResolvable): void;
    resetPrivateDnsResolvers(): void;
    get privateDnsResolversInput(): cdktn.IResolvable | PrivateNetworkGatewayPrivateDnsResolvers[] | undefined;
    get state(): string;
    private _trafficMode?;
    get trafficMode(): string;
    set trafficMode(value: string);
    get trafficModeInput(): string | undefined;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
