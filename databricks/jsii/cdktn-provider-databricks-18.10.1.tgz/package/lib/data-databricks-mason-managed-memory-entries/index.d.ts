/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonManagedMemoryEntriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#actor_id DataDatabricksMasonManagedMemoryEntries#actor_id}
    */
    readonly actorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#page_size DataDatabricksMasonManagedMemoryEntries#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#parent DataDatabricksMasonManagedMemoryEntries#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#path_prefix DataDatabricksMasonManagedMemoryEntries#path_prefix}
    */
    readonly pathPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#provider_config DataDatabricksMasonManagedMemoryEntries#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonManagedMemoryEntriesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#read_mask DataDatabricksMasonManagedMemoryEntries#read_mask}
    */
    readonly readMask?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#session_id DataDatabricksMasonManagedMemoryEntries#session_id}
    */
    readonly sessionId?: string;
}
export interface DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#workspace_id DataDatabricksMasonManagedMemoryEntries#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfigToTerraform(struct?: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfigToHclTerraform(struct?: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#name DataDatabricksMasonManagedMemoryEntries#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#provider_config DataDatabricksMasonManagedMemoryEntries#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig;
}
export declare function dataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesToTerraform(struct?: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntries): any;
export declare function dataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesToHclTerraform(struct?: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntries): any;
export declare class DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntries | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntries | undefined);
    get actorId(): string;
    get content(): string;
    get createTime(): string;
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get path(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesProviderConfig | undefined;
    get sessionId(): string;
    get sourceType(): string;
    get updateTime(): string;
}
export declare class DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesOutputReference;
}
export interface DataDatabricksMasonManagedMemoryEntriesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#workspace_id DataDatabricksMasonManagedMemoryEntries#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonManagedMemoryEntriesProviderConfigToTerraform(struct?: DataDatabricksMasonManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonManagedMemoryEntriesProviderConfigToHclTerraform(struct?: DataDatabricksMasonManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonManagedMemoryEntriesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries databricks_mason_managed_memory_entries}
*/
export declare class DataDatabricksMasonManagedMemoryEntries extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_managed_memory_entries";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonManagedMemoryEntries resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonManagedMemoryEntries to import
    * @param importFromId The id of the existing DataDatabricksMasonManagedMemoryEntries that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonManagedMemoryEntries to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_entries databricks_mason_managed_memory_entries} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonManagedMemoryEntriesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMasonManagedMemoryEntriesConfig);
    private _actorId?;
    get actorId(): string;
    set actorId(value: string);
    get actorIdInput(): string | undefined;
    private _managedMemoryEntries;
    get managedMemoryEntries(): DataDatabricksMasonManagedMemoryEntriesManagedMemoryEntriesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _pathPrefix?;
    get pathPrefix(): string;
    set pathPrefix(value: string);
    resetPathPrefix(): void;
    get pathPrefixInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonManagedMemoryEntriesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonManagedMemoryEntriesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonManagedMemoryEntriesProviderConfig | undefined;
    private _readMask?;
    get readMask(): string;
    set readMask(value: string);
    resetReadMask(): void;
    get readMaskInput(): string | undefined;
    private _sessionId?;
    get sessionId(): string;
    set sessionId(value: string);
    resetSessionId(): void;
    get sessionIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
