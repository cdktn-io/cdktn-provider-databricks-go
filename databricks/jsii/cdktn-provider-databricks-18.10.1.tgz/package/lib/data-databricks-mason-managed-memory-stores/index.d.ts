/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMasonManagedMemoryStoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores#page_size DataDatabricksMasonManagedMemoryStores#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores#provider_config DataDatabricksMasonManagedMemoryStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonManagedMemoryStoresProviderConfig;
}
export interface DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores#workspace_id DataDatabricksMasonManagedMemoryStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfigToTerraform(struct?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfigToHclTerraform(struct?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackend {
}
export declare function dataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackendToTerraform(struct?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackend): any;
export declare function dataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackendToHclTerraform(struct?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackend): any;
export declare class DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackend | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackend | undefined);
    get backendId(): string;
    get backendType(): string;
}
export interface DataDatabricksMasonManagedMemoryStoresManagedMemoryStores {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores#name DataDatabricksMasonManagedMemoryStores#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores#provider_config DataDatabricksMasonManagedMemoryStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig;
}
export declare function dataDatabricksMasonManagedMemoryStoresManagedMemoryStoresToTerraform(struct?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStores): any;
export declare function dataDatabricksMasonManagedMemoryStoresManagedMemoryStoresToHclTerraform(struct?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStores): any;
export declare class DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMasonManagedMemoryStoresManagedMemoryStores | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryStoresManagedMemoryStores | undefined);
    get createTime(): string;
    get creatorUserId(): string;
    get description(): string;
    get displayName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerUserId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresProviderConfig | undefined;
    private _storageBackend;
    get storageBackend(): DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresStorageBackendOutputReference;
    get updateTime(): string;
    get workspaceId(): number;
}
export declare class DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMasonManagedMemoryStoresManagedMemoryStores[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresOutputReference;
}
export interface DataDatabricksMasonManagedMemoryStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores#workspace_id DataDatabricksMasonManagedMemoryStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMasonManagedMemoryStoresProviderConfigToTerraform(struct?: DataDatabricksMasonManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMasonManagedMemoryStoresProviderConfigToHclTerraform(struct?: DataDatabricksMasonManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMasonManagedMemoryStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMasonManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMasonManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores databricks_mason_managed_memory_stores}
*/
export declare class DataDatabricksMasonManagedMemoryStores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mason_managed_memory_stores";
    /**
    * Generates CDKTN code for importing a DataDatabricksMasonManagedMemoryStores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMasonManagedMemoryStores to import
    * @param importFromId The id of the existing DataDatabricksMasonManagedMemoryStores that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMasonManagedMemoryStores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/mason_managed_memory_stores databricks_mason_managed_memory_stores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMasonManagedMemoryStoresConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksMasonManagedMemoryStoresConfig);
    private _managedMemoryStores;
    get managedMemoryStores(): DataDatabricksMasonManagedMemoryStoresManagedMemoryStoresList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMasonManagedMemoryStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMasonManagedMemoryStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMasonManagedMemoryStoresProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
