/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPrivateNetworkGatewaysConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#parent DataDatabricksPrivateNetworkGateways#parent}
    */
    readonly parent: string;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#role_arn DataDatabricksPrivateNetworkGateways#role_arn}
    */
    readonly roleArn: string;
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRoleToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRoleToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole | undefined);
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#subnet_id DataDatabricksPrivateNetworkGateways#subnet_id}
    */
    readonly subnetId: string;
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnetsToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnetsToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets | undefined);
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
}
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnetsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnetsOutputReference;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#cross_account_role DataDatabricksPrivateNetworkGateways#cross_account_role}
    */
    readonly crossAccountRole: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#gateway_subnets DataDatabricksPrivateNetworkGateways#gateway_subnets}
    */
    readonly gatewaySubnets: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#security_group_ids DataDatabricksPrivateNetworkGateways#security_group_ids}
    */
    readonly securityGroupIds: string[];
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnection): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnection): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnection | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnection | undefined);
    private _crossAccountRole;
    get crossAccountRole(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRoleOutputReference;
    putCrossAccountRole(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole): void;
    get crossAccountRoleInput(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionCrossAccountRole | undefined;
    private _gatewaySubnets;
    get gatewaySubnets(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnetsList;
    putGatewaySubnets(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets[] | cdktn.IResolvable): void;
    get gatewaySubnetsInput(): cdktn.IResolvable | DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionGatewaySubnets[] | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    get securityGroupIdsInput(): string[] | undefined;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#resource_id DataDatabricksPrivateNetworkGateways#resource_id}
    */
    readonly resourceId: string;
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnetToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnetToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet | undefined);
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#gateway_subnet DataDatabricksPrivateNetworkGateways#gateway_subnet}
    */
    readonly gatewaySubnet: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet;
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnection): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnection): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnection | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnection | undefined);
    private _gatewaySubnet;
    get gatewaySubnet(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnetOutputReference;
    putGatewaySubnet(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet): void;
    get gatewaySubnetInput(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionGatewaySubnet | undefined;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#destination_type DataDatabricksPrivateNetworkGateways#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#value DataDatabricksPrivateNetworkGateways#value}
    */
    readonly value: string;
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinationsToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinations): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinationsToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinations): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinations | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinations | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinationsOutputReference;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolvers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#resolver_type DataDatabricksPrivateNetworkGateways#resolver_type}
    */
    readonly resolverType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#value DataDatabricksPrivateNetworkGateways#value}
    */
    readonly value: string;
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolversToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolvers): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolversToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolvers): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolvers | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolvers | undefined);
    private _resolverType?;
    get resolverType(): string;
    set resolverType(value: string);
    get resolverTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolversList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolvers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolversOutputReference;
}
export interface DataDatabricksPrivateNetworkGatewaysPrivateNetworkGateways {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#name DataDatabricksPrivateNetworkGateways#name}
    */
    readonly name: string;
}
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysToTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGateways): any;
export declare function dataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysToHclTerraform(struct?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGateways): any;
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGateways | undefined;
    set internalValue(value: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGateways | undefined);
    private _awsCloudConnection;
    get awsCloudConnection(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAwsCloudConnectionOutputReference;
    private _azureCloudConnection;
    get azureCloudConnection(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysAzureCloudConnectionOutputReference;
    get bandwidthTierGigabitsPerSecond(): number;
    get createTime(): string;
    private _destinations;
    get destinations(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysDestinationsList;
    get displayName(): string;
    get errorMessage(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privateDnsResolvers;
    get privateDnsResolvers(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysPrivateDnsResolversList;
    get state(): string;
    get trafficMode(): string;
    get updateTime(): string;
}
export declare class DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPrivateNetworkGatewaysPrivateNetworkGateways[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways databricks_private_network_gateways}
*/
export declare class DataDatabricksPrivateNetworkGateways extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_private_network_gateways";
    /**
    * Generates CDKTN code for importing a DataDatabricksPrivateNetworkGateways resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPrivateNetworkGateways to import
    * @param importFromId The id of the existing DataDatabricksPrivateNetworkGateways that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPrivateNetworkGateways to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.137.0/docs/data-sources/private_network_gateways databricks_private_network_gateways} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPrivateNetworkGatewaysConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPrivateNetworkGatewaysConfig);
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _privateNetworkGateways;
    get privateNetworkGateways(): DataDatabricksPrivateNetworkGatewaysPrivateNetworkGatewaysList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
