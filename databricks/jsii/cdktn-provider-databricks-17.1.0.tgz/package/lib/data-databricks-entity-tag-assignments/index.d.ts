/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksEntityTagAssignmentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#entity_name DataDatabricksEntityTagAssignments#entity_name}
    */
    readonly entityName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#entity_type DataDatabricksEntityTagAssignments#entity_type}
    */
    readonly entityType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#max_results DataDatabricksEntityTagAssignments#max_results}
    */
    readonly maxResults?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#provider_config DataDatabricksEntityTagAssignments#provider_config}
    */
    readonly providerConfig?: DataDatabricksEntityTagAssignmentsProviderConfig;
}
export interface DataDatabricksEntityTagAssignmentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#workspace_id DataDatabricksEntityTagAssignments#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksEntityTagAssignmentsProviderConfigToTerraform(struct?: DataDatabricksEntityTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksEntityTagAssignmentsProviderConfigToHclTerraform(struct?: DataDatabricksEntityTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksEntityTagAssignmentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEntityTagAssignmentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksEntityTagAssignmentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#workspace_id DataDatabricksEntityTagAssignments#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfigToTerraform(struct?: DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfigToHclTerraform(struct?: DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksEntityTagAssignmentsTagAssignments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#entity_name DataDatabricksEntityTagAssignments#entity_name}
    */
    readonly entityName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#entity_type DataDatabricksEntityTagAssignments#entity_type}
    */
    readonly entityType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#provider_config DataDatabricksEntityTagAssignments#provider_config}
    */
    readonly providerConfig?: DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#tag_key DataDatabricksEntityTagAssignments#tag_key}
    */
    readonly tagKey: string;
}
export declare function dataDatabricksEntityTagAssignmentsTagAssignmentsToTerraform(struct?: DataDatabricksEntityTagAssignmentsTagAssignments): any;
export declare function dataDatabricksEntityTagAssignmentsTagAssignmentsToHclTerraform(struct?: DataDatabricksEntityTagAssignmentsTagAssignments): any;
export declare class DataDatabricksEntityTagAssignmentsTagAssignmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksEntityTagAssignmentsTagAssignments | undefined;
    set internalValue(value: DataDatabricksEntityTagAssignmentsTagAssignments | undefined);
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    get entityNameInput(): string | undefined;
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    get entityTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksEntityTagAssignmentsTagAssignmentsProviderConfig | undefined;
    get sourceType(): string;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    get tagValue(): string;
    get updateTime(): string;
    get updatedBy(): string;
}
export declare class DataDatabricksEntityTagAssignmentsTagAssignmentsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksEntityTagAssignmentsTagAssignments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksEntityTagAssignmentsTagAssignmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments databricks_entity_tag_assignments}
*/
export declare class DataDatabricksEntityTagAssignments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_entity_tag_assignments";
    /**
    * Generates CDKTN code for importing a DataDatabricksEntityTagAssignments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksEntityTagAssignments to import
    * @param importFromId The id of the existing DataDatabricksEntityTagAssignments that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksEntityTagAssignments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/entity_tag_assignments databricks_entity_tag_assignments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksEntityTagAssignmentsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksEntityTagAssignmentsConfig);
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    get entityNameInput(): string | undefined;
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    get entityTypeInput(): string | undefined;
    private _maxResults?;
    get maxResults(): number;
    set maxResults(value: number);
    resetMaxResults(): void;
    get maxResultsInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksEntityTagAssignmentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksEntityTagAssignmentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksEntityTagAssignmentsProviderConfig | undefined;
    private _tagAssignments;
    get tagAssignments(): DataDatabricksEntityTagAssignmentsTagAssignmentsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
