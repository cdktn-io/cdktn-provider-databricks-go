/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksViewsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views#catalog_name DataDatabricksViews#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views#id DataDatabricksViews#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views#ids DataDatabricksViews#ids}
    */
    readonly ids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views#schema_name DataDatabricksViews#schema_name}
    */
    readonly schemaName: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views#provider_config DataDatabricksViews#provider_config}
    */
    readonly providerConfig?: DataDatabricksViewsProviderConfig;
}
export interface DataDatabricksViewsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views#workspace_id DataDatabricksViews#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksViewsProviderConfigToTerraform(struct?: DataDatabricksViewsProviderConfigOutputReference | DataDatabricksViewsProviderConfig): any;
export declare function dataDatabricksViewsProviderConfigToHclTerraform(struct?: DataDatabricksViewsProviderConfigOutputReference | DataDatabricksViewsProviderConfig): any;
export declare class DataDatabricksViewsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksViewsProviderConfig | undefined;
    set internalValue(value: DataDatabricksViewsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views databricks_views}
*/
export declare class DataDatabricksViews extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_views";
    /**
    * Generates CDKTN code for importing a DataDatabricksViews resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksViews to import
    * @param importFromId The id of the existing DataDatabricksViews that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksViews to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/views databricks_views} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksViewsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksViewsConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksViewsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksViewsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksViewsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
