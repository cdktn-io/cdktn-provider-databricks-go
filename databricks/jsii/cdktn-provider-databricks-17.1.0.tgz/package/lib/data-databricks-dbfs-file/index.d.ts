/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDbfsFileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file#id DataDatabricksDbfsFile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file#limit_file_size DataDatabricksDbfsFile#limit_file_size}
    */
    readonly limitFileSize: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file#path DataDatabricksDbfsFile#path}
    */
    readonly path: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file#provider_config DataDatabricksDbfsFile#provider_config}
    */
    readonly providerConfig?: DataDatabricksDbfsFileProviderConfig;
}
export interface DataDatabricksDbfsFileProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file#workspace_id DataDatabricksDbfsFile#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDbfsFileProviderConfigToTerraform(struct?: DataDatabricksDbfsFileProviderConfigOutputReference | DataDatabricksDbfsFileProviderConfig): any;
export declare function dataDatabricksDbfsFileProviderConfigToHclTerraform(struct?: DataDatabricksDbfsFileProviderConfigOutputReference | DataDatabricksDbfsFileProviderConfig): any;
export declare class DataDatabricksDbfsFileProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDbfsFileProviderConfig | undefined;
    set internalValue(value: DataDatabricksDbfsFileProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file databricks_dbfs_file}
*/
export declare class DataDatabricksDbfsFile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_dbfs_file";
    /**
    * Generates CDKTN code for importing a DataDatabricksDbfsFile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDbfsFile to import
    * @param importFromId The id of the existing DataDatabricksDbfsFile that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDbfsFile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/dbfs_file databricks_dbfs_file} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDbfsFileConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDbfsFileConfig);
    get content(): string;
    get fileSize(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _limitFileSize?;
    get limitFileSize(): boolean | cdktn.IResolvable;
    set limitFileSize(value: boolean | cdktn.IResolvable);
    get limitFileSizeInput(): boolean | cdktn.IResolvable | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDbfsFileProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDbfsFileProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksDbfsFileProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
