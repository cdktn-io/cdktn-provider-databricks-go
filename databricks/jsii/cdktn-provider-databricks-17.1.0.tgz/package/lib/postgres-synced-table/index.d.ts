/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresSyncedTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#provider_config PostgresSyncedTable#provider_config}
    */
    readonly providerConfig?: PostgresSyncedTableProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#spec PostgresSyncedTable#spec}
    */
    readonly spec?: PostgresSyncedTableSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#synced_table_id PostgresSyncedTable#synced_table_id}
    */
    readonly syncedTableId: string;
}
export interface PostgresSyncedTableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#workspace_id PostgresSyncedTable#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresSyncedTableProviderConfigToTerraform(struct?: PostgresSyncedTableProviderConfig | cdktn.IResolvable): any;
export declare function postgresSyncedTableProviderConfigToHclTerraform(struct?: PostgresSyncedTableProviderConfig | cdktn.IResolvable): any;
export declare class PostgresSyncedTableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSyncedTableProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSyncedTableProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresSyncedTableSpecNewPipelineSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#budget_policy_id PostgresSyncedTable#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#storage_catalog PostgresSyncedTable#storage_catalog}
    */
    readonly storageCatalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#storage_schema PostgresSyncedTable#storage_schema}
    */
    readonly storageSchema?: string;
}
export declare function postgresSyncedTableSpecNewPipelineSpecToTerraform(struct?: PostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare function postgresSyncedTableSpecNewPipelineSpecToHclTerraform(struct?: PostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare class PostgresSyncedTableSpecNewPipelineSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable | undefined);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _storageCatalog?;
    get storageCatalog(): string;
    set storageCatalog(value: string);
    resetStorageCatalog(): void;
    get storageCatalogInput(): string | undefined;
    private _storageSchema?;
    get storageSchema(): string;
    set storageSchema(value: string);
    resetStorageSchema(): void;
    get storageSchemaInput(): string | undefined;
}
export interface PostgresSyncedTableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#branch PostgresSyncedTable#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#create_database_objects_if_missing PostgresSyncedTable#create_database_objects_if_missing}
    */
    readonly createDatabaseObjectsIfMissing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#existing_pipeline_id PostgresSyncedTable#existing_pipeline_id}
    */
    readonly existingPipelineId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#new_pipeline_spec PostgresSyncedTable#new_pipeline_spec}
    */
    readonly newPipelineSpec?: PostgresSyncedTableSpecNewPipelineSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#postgres_database PostgresSyncedTable#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#primary_key_columns PostgresSyncedTable#primary_key_columns}
    */
    readonly primaryKeyColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#scheduling_policy PostgresSyncedTable#scheduling_policy}
    */
    readonly schedulingPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#source_table_full_name PostgresSyncedTable#source_table_full_name}
    */
    readonly sourceTableFullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#timeseries_key PostgresSyncedTable#timeseries_key}
    */
    readonly timeseriesKey?: string;
}
export declare function postgresSyncedTableSpecToTerraform(struct?: PostgresSyncedTableSpec | cdktn.IResolvable): any;
export declare function postgresSyncedTableSpecToHclTerraform(struct?: PostgresSyncedTableSpec | cdktn.IResolvable): any;
export declare class PostgresSyncedTableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSyncedTableSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSyncedTableSpec | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _createDatabaseObjectsIfMissing?;
    get createDatabaseObjectsIfMissing(): boolean | cdktn.IResolvable;
    set createDatabaseObjectsIfMissing(value: boolean | cdktn.IResolvable);
    resetCreateDatabaseObjectsIfMissing(): void;
    get createDatabaseObjectsIfMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _existingPipelineId?;
    get existingPipelineId(): string;
    set existingPipelineId(value: string);
    resetExistingPipelineId(): void;
    get existingPipelineIdInput(): string | undefined;
    private _newPipelineSpec;
    get newPipelineSpec(): PostgresSyncedTableSpecNewPipelineSpecOutputReference;
    putNewPipelineSpec(value: PostgresSyncedTableSpecNewPipelineSpec): void;
    resetNewPipelineSpec(): void;
    get newPipelineSpecInput(): cdktn.IResolvable | PostgresSyncedTableSpecNewPipelineSpec | undefined;
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _primaryKeyColumns?;
    get primaryKeyColumns(): string[];
    set primaryKeyColumns(value: string[]);
    resetPrimaryKeyColumns(): void;
    get primaryKeyColumnsInput(): string[] | undefined;
    private _schedulingPolicy?;
    get schedulingPolicy(): string;
    set schedulingPolicy(value: string);
    resetSchedulingPolicy(): void;
    get schedulingPolicyInput(): string | undefined;
    private _sourceTableFullName?;
    get sourceTableFullName(): string;
    set sourceTableFullName(value: string);
    resetSourceTableFullName(): void;
    get sourceTableFullNameInput(): string | undefined;
    private _timeseriesKey?;
    get timeseriesKey(): string;
    set timeseriesKey(value: string);
    resetTimeseriesKey(): void;
    get timeseriesKeyInput(): string | undefined;
}
export interface PostgresSyncedTableStatusLastSyncDeltaTableSyncInfo {
}
export declare function postgresSyncedTableStatusLastSyncDeltaTableSyncInfoToTerraform(struct?: PostgresSyncedTableStatusLastSyncDeltaTableSyncInfo): any;
export declare function postgresSyncedTableStatusLastSyncDeltaTableSyncInfoToHclTerraform(struct?: PostgresSyncedTableStatusLastSyncDeltaTableSyncInfo): any;
export declare class PostgresSyncedTableStatusLastSyncDeltaTableSyncInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSyncedTableStatusLastSyncDeltaTableSyncInfo | undefined;
    set internalValue(value: PostgresSyncedTableStatusLastSyncDeltaTableSyncInfo | undefined);
    get deltaCommitTime(): string;
    get deltaCommitVersion(): number;
}
export interface PostgresSyncedTableStatusLastSync {
}
export declare function postgresSyncedTableStatusLastSyncToTerraform(struct?: PostgresSyncedTableStatusLastSync): any;
export declare function postgresSyncedTableStatusLastSyncToHclTerraform(struct?: PostgresSyncedTableStatusLastSync): any;
export declare class PostgresSyncedTableStatusLastSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSyncedTableStatusLastSync | undefined;
    set internalValue(value: PostgresSyncedTableStatusLastSync | undefined);
    private _deltaTableSyncInfo;
    get deltaTableSyncInfo(): PostgresSyncedTableStatusLastSyncDeltaTableSyncInfoOutputReference;
    get syncEndTime(): string;
    get syncStartTime(): string;
}
export interface PostgresSyncedTableStatusOngoingSyncProgress {
}
export declare function postgresSyncedTableStatusOngoingSyncProgressToTerraform(struct?: PostgresSyncedTableStatusOngoingSyncProgress): any;
export declare function postgresSyncedTableStatusOngoingSyncProgressToHclTerraform(struct?: PostgresSyncedTableStatusOngoingSyncProgress): any;
export declare class PostgresSyncedTableStatusOngoingSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSyncedTableStatusOngoingSyncProgress | undefined;
    set internalValue(value: PostgresSyncedTableStatusOngoingSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface PostgresSyncedTableStatus {
}
export declare function postgresSyncedTableStatusToTerraform(struct?: PostgresSyncedTableStatus): any;
export declare function postgresSyncedTableStatusToHclTerraform(struct?: PostgresSyncedTableStatus): any;
export declare class PostgresSyncedTableStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSyncedTableStatus | undefined;
    set internalValue(value: PostgresSyncedTableStatus | undefined);
    get detailedState(): string;
    get lastProcessedCommitVersion(): number;
    private _lastSync;
    get lastSync(): PostgresSyncedTableStatusLastSyncOutputReference;
    get lastSyncTime(): string;
    get message(): string;
    private _ongoingSyncProgress;
    get ongoingSyncProgress(): PostgresSyncedTableStatusOngoingSyncProgressOutputReference;
    get pipelineId(): string;
    get project(): string;
    get provisioningPhase(): string;
    get unityCatalogProvisioningState(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table databricks_postgres_synced_table}
*/
export declare class PostgresSyncedTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_synced_table";
    /**
    * Generates CDKTN code for importing a PostgresSyncedTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresSyncedTable to import
    * @param importFromId The id of the existing PostgresSyncedTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresSyncedTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/postgres_synced_table databricks_postgres_synced_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresSyncedTableConfig
    */
    constructor(scope: Construct, id: string, config: PostgresSyncedTableConfig);
    get createTime(): string;
    get name(): string;
    private _providerConfig;
    get providerConfig(): PostgresSyncedTableProviderConfigOutputReference;
    putProviderConfig(value: PostgresSyncedTableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresSyncedTableProviderConfig | undefined;
    private _spec;
    get spec(): PostgresSyncedTableSpecOutputReference;
    putSpec(value: PostgresSyncedTableSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresSyncedTableSpec | undefined;
    private _status;
    get status(): PostgresSyncedTableStatusOutputReference;
    private _syncedTableId?;
    get syncedTableId(): string;
    set syncedTableId(value: string);
    get syncedTableIdInput(): string | undefined;
    get uid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
