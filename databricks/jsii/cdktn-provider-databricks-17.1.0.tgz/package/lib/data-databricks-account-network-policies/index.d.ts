/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountNetworkPoliciesConfig extends cdktn.TerraformMetaArguments {
}
export interface DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#internet_destination_type DataDatabricksAccountNetworkPolicies#internet_destination_type}
    */
    readonly internetDestinationType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinationsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinationsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _internetDestinationType?;
    get internetDestinationType(): string;
    set internetDestinationType(value: string);
    resetInternetDestinationType(): void;
    get internetDestinationTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinationsOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#azure_storage_account DataDatabricksAccountNetworkPolicies#azure_storage_account}
    */
    readonly azureStorageAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#azure_storage_service DataDatabricksAccountNetworkPolicies#azure_storage_service}
    */
    readonly azureStorageService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#bucket_name DataDatabricksAccountNetworkPolicies#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#region DataDatabricksAccountNetworkPolicies#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#storage_destination_type DataDatabricksAccountNetworkPolicies#storage_destination_type}
    */
    readonly storageDestinationType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinationsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinationsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined);
    private _azureStorageAccount?;
    get azureStorageAccount(): string;
    set azureStorageAccount(value: string);
    resetAzureStorageAccount(): void;
    get azureStorageAccountInput(): string | undefined;
    private _azureStorageService?;
    get azureStorageService(): string;
    set azureStorageService(value: string);
    resetAzureStorageService(): void;
    get azureStorageServiceInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageDestinationType?;
    get storageDestinationType(): string;
    set storageDestinationType(value: string);
    resetStorageDestinationType(): void;
    get storageDestinationTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinationsOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#internet_destination_type DataDatabricksAccountNetworkPolicies#internet_destination_type}
    */
    readonly internetDestinationType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinationsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinationsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _internetDestinationType?;
    get internetDestinationType(): string;
    set internetDestinationType(value: string);
    resetInternetDestinationType(): void;
    get internetDestinationTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinationsOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#dry_run_mode_product_filter DataDatabricksAccountNetworkPolicies#dry_run_mode_product_filter}
    */
    readonly dryRunModeProductFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#enforcement_mode DataDatabricksAccountNetworkPolicies#enforcement_mode}
    */
    readonly enforcementMode?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcementToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcementToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined);
    private _dryRunModeProductFilter?;
    get dryRunModeProductFilter(): string[];
    set dryRunModeProductFilter(value: string[]);
    resetDryRunModeProductFilter(): void;
    get dryRunModeProductFilterInput(): string[] | undefined;
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    resetEnforcementMode(): void;
    get enforcementModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#allowed_internet_destinations DataDatabricksAccountNetworkPolicies#allowed_internet_destinations}
    */
    readonly allowedInternetDestinations?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#allowed_storage_destinations DataDatabricksAccountNetworkPolicies#allowed_storage_destinations}
    */
    readonly allowedStorageDestinations?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#blocked_internet_destinations DataDatabricksAccountNetworkPolicies#blocked_internet_destinations}
    */
    readonly blockedInternetDestinations?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#policy_enforcement DataDatabricksAccountNetworkPolicies#policy_enforcement}
    */
    readonly policyEnforcement?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#restriction_mode DataDatabricksAccountNetworkPolicies#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess | cdktn.IResolvable | undefined);
    private _allowedInternetDestinations;
    get allowedInternetDestinations(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinationsList;
    putAllowedInternetDestinations(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable): void;
    resetAllowedInternetDestinations(): void;
    get allowedInternetDestinationsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedInternetDestinations[] | undefined;
    private _allowedStorageDestinations;
    get allowedStorageDestinations(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinationsList;
    putAllowedStorageDestinations(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable): void;
    resetAllowedStorageDestinations(): void;
    get allowedStorageDestinationsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessAllowedStorageDestinations[] | undefined;
    private _blockedInternetDestinations;
    get blockedInternetDestinations(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinationsList;
    putBlockedInternetDestinations(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable): void;
    resetBlockedInternetDestinations(): void;
    get blockedInternetDestinationsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessBlockedInternetDestinations[] | undefined;
    private _policyEnforcement;
    get policyEnforcement(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcementOutputReference;
    putPolicyEnforcement(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement): void;
    resetPolicyEnforcement(): void;
    get policyEnforcementInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessPolicyEnforcement | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsEgress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#network_access DataDatabricksAccountNetworkPolicies#network_access}
    */
    readonly networkAccess?: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgress): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsEgressToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsEgress): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsEgress | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsEgress | undefined);
    private _networkAccess;
    get networkAccess(): DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccessOutputReference;
    putNetworkAccess(value: DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess): void;
    resetNetworkAccess(): void;
    get networkAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsEgressNetworkAccess | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoint_ids DataDatabricksAccountNetworkPolicies#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_private_access DataDatabricksAccountNetworkPolicies#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_registered_endpoints DataDatabricksAccountNetworkPolicies#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#azure_workspace_private_link DataDatabricksAccountNetworkPolicies#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoints DataDatabricksAccountNetworkPolicies#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoint_ids DataDatabricksAccountNetworkPolicies#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_private_access DataDatabricksAccountNetworkPolicies#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_registered_endpoints DataDatabricksAccountNetworkPolicies#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#azure_workspace_private_link DataDatabricksAccountNetworkPolicies#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoints DataDatabricksAccountNetworkPolicies#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#allow_rules DataDatabricksAccountNetworkPolicies#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#deny_rules DataDatabricksAccountNetworkPolicies#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#restriction_mode DataDatabricksAccountNetworkPolicies#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_ip_ranges DataDatabricksAccountNetworkPolicies#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#excluded_ip_ranges DataDatabricksAccountNetworkPolicies#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#included_ip_ranges DataDatabricksAccountNetworkPolicies#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_ip_ranges DataDatabricksAccountNetworkPolicies#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#excluded_ip_ranges DataDatabricksAccountNetworkPolicies#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#included_ip_ranges DataDatabricksAccountNetworkPolicies#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#allow_rules DataDatabricksAccountNetworkPolicies#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#deny_rules DataDatabricksAccountNetworkPolicies#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#restriction_mode DataDatabricksAccountNetworkPolicies#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#private_access DataDatabricksAccountNetworkPolicies#private_access}
    */
    readonly privateAccess?: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#public_access DataDatabricksAccountNetworkPolicies#public_access}
    */
    readonly publicAccess?: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngress): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngress): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngress | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngress | undefined);
    private _privateAccess;
    get privateAccess(): DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccessOutputReference;
    putPrivateAccess(value: DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccessOutputReference;
    putPublicAccess(value: DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressPublicAccess | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoint_ids DataDatabricksAccountNetworkPolicies#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_private_access DataDatabricksAccountNetworkPolicies#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_registered_endpoints DataDatabricksAccountNetworkPolicies#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#azure_workspace_private_link DataDatabricksAccountNetworkPolicies#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoints DataDatabricksAccountNetworkPolicies#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoint_ids DataDatabricksAccountNetworkPolicies#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_private_access DataDatabricksAccountNetworkPolicies#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_registered_endpoints DataDatabricksAccountNetworkPolicies#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#azure_workspace_private_link DataDatabricksAccountNetworkPolicies#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#endpoints DataDatabricksAccountNetworkPolicies#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#allow_rules DataDatabricksAccountNetworkPolicies#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#deny_rules DataDatabricksAccountNetworkPolicies#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#restriction_mode DataDatabricksAccountNetworkPolicies#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_ip_ranges DataDatabricksAccountNetworkPolicies#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#excluded_ip_ranges DataDatabricksAccountNetworkPolicies#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#included_ip_ranges DataDatabricksAccountNetworkPolicies#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_id DataDatabricksAccountNetworkPolicies#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#principal_type DataDatabricksAccountNetworkPolicies#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identities DataDatabricksAccountNetworkPolicies#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#identity_type DataDatabricksAccountNetworkPolicies#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scope_qualifier DataDatabricksAccountNetworkPolicies#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#scopes DataDatabricksAccountNetworkPolicies#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_api DataDatabricksAccountNetworkPolicies#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_databricks_one DataDatabricksAccountNetworkPolicies#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#account_ui DataDatabricksAccountNetworkPolicies#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_destinations DataDatabricksAccountNetworkPolicies#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#apps_runtime DataDatabricksAccountNetworkPolicies#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#lakebase_runtime DataDatabricksAccountNetworkPolicies#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_api DataDatabricksAccountNetworkPolicies#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#workspace_ui DataDatabricksAccountNetworkPolicies#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#ip_ranges DataDatabricksAccountNetworkPolicies#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#all_ip_ranges DataDatabricksAccountNetworkPolicies#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#excluded_ip_ranges DataDatabricksAccountNetworkPolicies#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#included_ip_ranges DataDatabricksAccountNetworkPolicies#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#authentication DataDatabricksAccountNetworkPolicies#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#destination DataDatabricksAccountNetworkPolicies#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#label DataDatabricksAccountNetworkPolicies#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#origin DataDatabricksAccountNetworkPolicies#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#allow_rules DataDatabricksAccountNetworkPolicies#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#deny_rules DataDatabricksAccountNetworkPolicies#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#restriction_mode DataDatabricksAccountNetworkPolicies#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRun {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#private_access DataDatabricksAccountNetworkPolicies#private_access}
    */
    readonly privateAccess?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#public_access DataDatabricksAccountNetworkPolicies#public_access}
    */
    readonly publicAccess?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRun): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRun): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRun | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRun | undefined);
    private _privateAccess;
    get privateAccess(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessOutputReference;
    putPrivateAccess(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessOutputReference;
    putPublicAccess(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#network_policy_id DataDatabricksAccountNetworkPolicies#network_policy_id}
    */
    readonly networkPolicyId: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItems): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItems): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItems | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItems | undefined);
    get accountId(): string;
    private _egress;
    get egress(): DataDatabricksAccountNetworkPoliciesItemsEgressOutputReference;
    private _ingress;
    get ingress(): DataDatabricksAccountNetworkPoliciesItemsIngressOutputReference;
    private _ingressDryRun;
    get ingressDryRun(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunOutputReference;
    private _networkPolicyId?;
    get networkPolicyId(): string;
    set networkPolicyId(value: string);
    get networkPolicyIdInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies databricks_account_network_policies}
*/
export declare class DataDatabricksAccountNetworkPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_network_policies";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountNetworkPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountNetworkPolicies to import
    * @param importFromId The id of the existing DataDatabricksAccountNetworkPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountNetworkPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/account_network_policies databricks_account_network_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountNetworkPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAccountNetworkPoliciesConfig);
    private _items;
    get items(): DataDatabricksAccountNetworkPoliciesItemsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
