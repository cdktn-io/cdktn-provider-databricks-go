/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksNodeTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#arm DataDatabricksNodeType#arm}
    */
    readonly arm?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#category DataDatabricksNodeType#category}
    */
    readonly category?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#fleet DataDatabricksNodeType#fleet}
    */
    readonly fleet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#gb_per_core DataDatabricksNodeType#gb_per_core}
    */
    readonly gbPerCore?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#graviton DataDatabricksNodeType#graviton}
    */
    readonly graviton?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#id DataDatabricksNodeType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#is_io_cache_enabled DataDatabricksNodeType#is_io_cache_enabled}
    */
    readonly isIoCacheEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#local_disk DataDatabricksNodeType#local_disk}
    */
    readonly localDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#local_disk_min_size DataDatabricksNodeType#local_disk_min_size}
    */
    readonly localDiskMinSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#min_cores DataDatabricksNodeType#min_cores}
    */
    readonly minCores?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#min_gpus DataDatabricksNodeType#min_gpus}
    */
    readonly minGpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#min_memory_gb DataDatabricksNodeType#min_memory_gb}
    */
    readonly minMemoryGb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#photon_driver_capable DataDatabricksNodeType#photon_driver_capable}
    */
    readonly photonDriverCapable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#photon_worker_capable DataDatabricksNodeType#photon_worker_capable}
    */
    readonly photonWorkerCapable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#support_port_forwarding DataDatabricksNodeType#support_port_forwarding}
    */
    readonly supportPortForwarding?: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#provider_config DataDatabricksNodeType#provider_config}
    */
    readonly providerConfig?: DataDatabricksNodeTypeProviderConfig;
}
export interface DataDatabricksNodeTypeProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#workspace_id DataDatabricksNodeType#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksNodeTypeProviderConfigToTerraform(struct?: DataDatabricksNodeTypeProviderConfigOutputReference | DataDatabricksNodeTypeProviderConfig): any;
export declare function dataDatabricksNodeTypeProviderConfigToHclTerraform(struct?: DataDatabricksNodeTypeProviderConfigOutputReference | DataDatabricksNodeTypeProviderConfig): any;
export declare class DataDatabricksNodeTypeProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksNodeTypeProviderConfig | undefined;
    set internalValue(value: DataDatabricksNodeTypeProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type databricks_node_type}
*/
export declare class DataDatabricksNodeType extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_node_type";
    /**
    * Generates CDKTN code for importing a DataDatabricksNodeType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksNodeType to import
    * @param importFromId The id of the existing DataDatabricksNodeType that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksNodeType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/node_type databricks_node_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksNodeTypeConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksNodeTypeConfig);
    private _arm?;
    get arm(): boolean | cdktn.IResolvable;
    set arm(value: boolean | cdktn.IResolvable);
    resetArm(): void;
    get armInput(): boolean | cdktn.IResolvable | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _fleet?;
    get fleet(): boolean | cdktn.IResolvable;
    set fleet(value: boolean | cdktn.IResolvable);
    resetFleet(): void;
    get fleetInput(): boolean | cdktn.IResolvable | undefined;
    private _gbPerCore?;
    get gbPerCore(): number;
    set gbPerCore(value: number);
    resetGbPerCore(): void;
    get gbPerCoreInput(): number | undefined;
    private _graviton?;
    get graviton(): boolean | cdktn.IResolvable;
    set graviton(value: boolean | cdktn.IResolvable);
    resetGraviton(): void;
    get gravitonInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isIoCacheEnabled?;
    get isIoCacheEnabled(): boolean | cdktn.IResolvable;
    set isIoCacheEnabled(value: boolean | cdktn.IResolvable);
    resetIsIoCacheEnabled(): void;
    get isIoCacheEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _localDisk?;
    get localDisk(): boolean | cdktn.IResolvable;
    set localDisk(value: boolean | cdktn.IResolvable);
    resetLocalDisk(): void;
    get localDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _localDiskMinSize?;
    get localDiskMinSize(): number;
    set localDiskMinSize(value: number);
    resetLocalDiskMinSize(): void;
    get localDiskMinSizeInput(): number | undefined;
    private _minCores?;
    get minCores(): number;
    set minCores(value: number);
    resetMinCores(): void;
    get minCoresInput(): number | undefined;
    private _minGpus?;
    get minGpus(): number;
    set minGpus(value: number);
    resetMinGpus(): void;
    get minGpusInput(): number | undefined;
    private _minMemoryGb?;
    get minMemoryGb(): number;
    set minMemoryGb(value: number);
    resetMinMemoryGb(): void;
    get minMemoryGbInput(): number | undefined;
    private _photonDriverCapable?;
    get photonDriverCapable(): boolean | cdktn.IResolvable;
    set photonDriverCapable(value: boolean | cdktn.IResolvable);
    resetPhotonDriverCapable(): void;
    get photonDriverCapableInput(): boolean | cdktn.IResolvable | undefined;
    private _photonWorkerCapable?;
    get photonWorkerCapable(): boolean | cdktn.IResolvable;
    set photonWorkerCapable(value: boolean | cdktn.IResolvable);
    resetPhotonWorkerCapable(): void;
    get photonWorkerCapableInput(): boolean | cdktn.IResolvable | undefined;
    private _supportPortForwarding?;
    get supportPortForwarding(): boolean | cdktn.IResolvable;
    set supportPortForwarding(value: boolean | cdktn.IResolvable);
    resetSupportPortForwarding(): void;
    get supportPortForwardingInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksNodeTypeProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksNodeTypeProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksNodeTypeProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
