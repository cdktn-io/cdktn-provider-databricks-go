/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPolicyInfosConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#include_inherited DataDatabricksPolicyInfos#include_inherited}
    */
    readonly includeInherited?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#max_results DataDatabricksPolicyInfos#max_results}
    */
    readonly maxResults?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#on_securable_fullname DataDatabricksPolicyInfos#on_securable_fullname}
    */
    readonly onSecurableFullname: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#on_securable_type DataDatabricksPolicyInfos#on_securable_type}
    */
    readonly onSecurableType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#provider_config DataDatabricksPolicyInfos#provider_config}
    */
    readonly providerConfig?: DataDatabricksPolicyInfosProviderConfig;
}
export interface DataDatabricksPolicyInfosPoliciesColumnMaskUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#alias DataDatabricksPolicyInfos#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#constant DataDatabricksPolicyInfos#constant}
    */
    readonly constant?: string;
}
export declare function dataDatabricksPolicyInfosPoliciesColumnMaskUsingToTerraform(struct?: DataDatabricksPolicyInfosPoliciesColumnMaskUsing | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfosPoliciesColumnMaskUsingToHclTerraform(struct?: DataDatabricksPolicyInfosPoliciesColumnMaskUsing | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfosPoliciesColumnMaskUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfosPoliciesColumnMaskUsing | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfosPoliciesColumnMaskUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
}
export declare class DataDatabricksPolicyInfosPoliciesColumnMaskUsingList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfosPoliciesColumnMaskUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfosPoliciesColumnMaskUsingOutputReference;
}
export interface DataDatabricksPolicyInfosPoliciesColumnMask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#function_name DataDatabricksPolicyInfos#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#on_column DataDatabricksPolicyInfos#on_column}
    */
    readonly onColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#using DataDatabricksPolicyInfos#using}
    */
    readonly using?: DataDatabricksPolicyInfosPoliciesColumnMaskUsing[] | cdktn.IResolvable;
}
export declare function dataDatabricksPolicyInfosPoliciesColumnMaskToTerraform(struct?: DataDatabricksPolicyInfosPoliciesColumnMask): any;
export declare function dataDatabricksPolicyInfosPoliciesColumnMaskToHclTerraform(struct?: DataDatabricksPolicyInfosPoliciesColumnMask): any;
export declare class DataDatabricksPolicyInfosPoliciesColumnMaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfosPoliciesColumnMask | undefined;
    set internalValue(value: DataDatabricksPolicyInfosPoliciesColumnMask | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _onColumn?;
    get onColumn(): string;
    set onColumn(value: string);
    get onColumnInput(): string | undefined;
    private _using;
    get using(): DataDatabricksPolicyInfosPoliciesColumnMaskUsingList;
    putUsing(value: DataDatabricksPolicyInfosPoliciesColumnMaskUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | DataDatabricksPolicyInfosPoliciesColumnMaskUsing[] | undefined;
}
export interface DataDatabricksPolicyInfosPoliciesMatchColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#alias DataDatabricksPolicyInfos#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#condition DataDatabricksPolicyInfos#condition}
    */
    readonly condition?: string;
}
export declare function dataDatabricksPolicyInfosPoliciesMatchColumnsToTerraform(struct?: DataDatabricksPolicyInfosPoliciesMatchColumns): any;
export declare function dataDatabricksPolicyInfosPoliciesMatchColumnsToHclTerraform(struct?: DataDatabricksPolicyInfosPoliciesMatchColumns): any;
export declare class DataDatabricksPolicyInfosPoliciesMatchColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfosPoliciesMatchColumns | undefined;
    set internalValue(value: DataDatabricksPolicyInfosPoliciesMatchColumns | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
}
export declare class DataDatabricksPolicyInfosPoliciesMatchColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfosPoliciesMatchColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfosPoliciesMatchColumnsOutputReference;
}
export interface DataDatabricksPolicyInfosPoliciesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#workspace_id DataDatabricksPolicyInfos#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPolicyInfosPoliciesProviderConfigToTerraform(struct?: DataDatabricksPolicyInfosPoliciesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfosPoliciesProviderConfigToHclTerraform(struct?: DataDatabricksPolicyInfosPoliciesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfosPoliciesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfosPoliciesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfosPoliciesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPolicyInfosPoliciesRowFilterUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#alias DataDatabricksPolicyInfos#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#constant DataDatabricksPolicyInfos#constant}
    */
    readonly constant?: string;
}
export declare function dataDatabricksPolicyInfosPoliciesRowFilterUsingToTerraform(struct?: DataDatabricksPolicyInfosPoliciesRowFilterUsing | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfosPoliciesRowFilterUsingToHclTerraform(struct?: DataDatabricksPolicyInfosPoliciesRowFilterUsing | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfosPoliciesRowFilterUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfosPoliciesRowFilterUsing | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfosPoliciesRowFilterUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
}
export declare class DataDatabricksPolicyInfosPoliciesRowFilterUsingList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfosPoliciesRowFilterUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfosPoliciesRowFilterUsingOutputReference;
}
export interface DataDatabricksPolicyInfosPoliciesRowFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#function_name DataDatabricksPolicyInfos#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#using DataDatabricksPolicyInfos#using}
    */
    readonly using?: DataDatabricksPolicyInfosPoliciesRowFilterUsing[] | cdktn.IResolvable;
}
export declare function dataDatabricksPolicyInfosPoliciesRowFilterToTerraform(struct?: DataDatabricksPolicyInfosPoliciesRowFilter): any;
export declare function dataDatabricksPolicyInfosPoliciesRowFilterToHclTerraform(struct?: DataDatabricksPolicyInfosPoliciesRowFilter): any;
export declare class DataDatabricksPolicyInfosPoliciesRowFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfosPoliciesRowFilter | undefined;
    set internalValue(value: DataDatabricksPolicyInfosPoliciesRowFilter | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _using;
    get using(): DataDatabricksPolicyInfosPoliciesRowFilterUsingList;
    putUsing(value: DataDatabricksPolicyInfosPoliciesRowFilterUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | DataDatabricksPolicyInfosPoliciesRowFilterUsing[] | undefined;
}
export interface DataDatabricksPolicyInfosPolicies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#name DataDatabricksPolicyInfos#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#on_securable_fullname DataDatabricksPolicyInfos#on_securable_fullname}
    */
    readonly onSecurableFullname: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#on_securable_type DataDatabricksPolicyInfos#on_securable_type}
    */
    readonly onSecurableType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#provider_config DataDatabricksPolicyInfos#provider_config}
    */
    readonly providerConfig?: DataDatabricksPolicyInfosPoliciesProviderConfig;
}
export declare function dataDatabricksPolicyInfosPoliciesToTerraform(struct?: DataDatabricksPolicyInfosPolicies): any;
export declare function dataDatabricksPolicyInfosPoliciesToHclTerraform(struct?: DataDatabricksPolicyInfosPolicies): any;
export declare class DataDatabricksPolicyInfosPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfosPolicies | undefined;
    set internalValue(value: DataDatabricksPolicyInfosPolicies | undefined);
    private _columnMask;
    get columnMask(): DataDatabricksPolicyInfosPoliciesColumnMaskOutputReference;
    get comment(): string;
    get createdAt(): number;
    get createdBy(): string;
    get exceptPrincipals(): string[];
    get forSecurableType(): string;
    get id(): string;
    private _matchColumns;
    get matchColumns(): DataDatabricksPolicyInfosPoliciesMatchColumnsList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onSecurableFullname?;
    get onSecurableFullname(): string;
    set onSecurableFullname(value: string);
    get onSecurableFullnameInput(): string | undefined;
    private _onSecurableType?;
    get onSecurableType(): string;
    set onSecurableType(value: string);
    get onSecurableTypeInput(): string | undefined;
    get policyType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPolicyInfosPoliciesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPolicyInfosPoliciesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPolicyInfosPoliciesProviderConfig | undefined;
    private _rowFilter;
    get rowFilter(): DataDatabricksPolicyInfosPoliciesRowFilterOutputReference;
    get toPrincipals(): string[];
    get updatedAt(): number;
    get updatedBy(): string;
    get whenCondition(): string;
}
export declare class DataDatabricksPolicyInfosPoliciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfosPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfosPoliciesOutputReference;
}
export interface DataDatabricksPolicyInfosProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#workspace_id DataDatabricksPolicyInfos#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPolicyInfosProviderConfigToTerraform(struct?: DataDatabricksPolicyInfosProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfosProviderConfigToHclTerraform(struct?: DataDatabricksPolicyInfosProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfosProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfosProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfosProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos databricks_policy_infos}
*/
export declare class DataDatabricksPolicyInfos extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_policy_infos";
    /**
    * Generates CDKTN code for importing a DataDatabricksPolicyInfos resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPolicyInfos to import
    * @param importFromId The id of the existing DataDatabricksPolicyInfos that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPolicyInfos to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/policy_infos databricks_policy_infos} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPolicyInfosConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPolicyInfosConfig);
    private _includeInherited?;
    get includeInherited(): boolean | cdktn.IResolvable;
    set includeInherited(value: boolean | cdktn.IResolvable);
    resetIncludeInherited(): void;
    get includeInheritedInput(): boolean | cdktn.IResolvable | undefined;
    private _maxResults?;
    get maxResults(): number;
    set maxResults(value: number);
    resetMaxResults(): void;
    get maxResultsInput(): number | undefined;
    private _onSecurableFullname?;
    get onSecurableFullname(): string;
    set onSecurableFullname(value: string);
    get onSecurableFullnameInput(): string | undefined;
    private _onSecurableType?;
    get onSecurableType(): string;
    set onSecurableType(value: string);
    get onSecurableTypeInput(): string | undefined;
    private _policies;
    get policies(): DataDatabricksPolicyInfosPoliciesList;
    private _providerConfig;
    get providerConfig(): DataDatabricksPolicyInfosProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPolicyInfosProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPolicyInfosProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
