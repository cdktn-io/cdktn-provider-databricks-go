/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RecipientConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#authentication_type Recipient#authentication_type}
    */
    readonly authenticationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#comment Recipient#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#data_recipient_global_metastore_id Recipient#data_recipient_global_metastore_id}
    */
    readonly dataRecipientGlobalMetastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#expiration_time Recipient#expiration_time}
    */
    readonly expirationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#id Recipient#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#name Recipient#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#owner Recipient#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#sharing_code Recipient#sharing_code}
    */
    readonly sharingCode?: string;
    /**
    * ip_access_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#ip_access_list Recipient#ip_access_list}
    */
    readonly ipAccessList?: RecipientIpAccessListStruct;
    /**
    * properties_kvpairs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#properties_kvpairs Recipient#properties_kvpairs}
    */
    readonly propertiesKvpairs?: RecipientPropertiesKvpairs;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#provider_config Recipient#provider_config}
    */
    readonly providerConfig?: RecipientProviderConfig;
    /**
    * tokens block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#tokens Recipient#tokens}
    */
    readonly tokens?: RecipientTokens[] | cdktn.IResolvable;
}
export interface RecipientIpAccessListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#allowed_ip_addresses Recipient#allowed_ip_addresses}
    */
    readonly allowedIpAddresses?: string[];
}
export declare function recipientIpAccessListStructToTerraform(struct?: RecipientIpAccessListStructOutputReference | RecipientIpAccessListStruct): any;
export declare function recipientIpAccessListStructToHclTerraform(struct?: RecipientIpAccessListStructOutputReference | RecipientIpAccessListStruct): any;
export declare class RecipientIpAccessListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RecipientIpAccessListStruct | undefined;
    set internalValue(value: RecipientIpAccessListStruct | undefined);
    private _allowedIpAddresses?;
    get allowedIpAddresses(): string[];
    set allowedIpAddresses(value: string[]);
    resetAllowedIpAddresses(): void;
    get allowedIpAddressesInput(): string[] | undefined;
}
export interface RecipientPropertiesKvpairs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#properties Recipient#properties}
    */
    readonly properties: {
        [key: string]: string;
    };
}
export declare function recipientPropertiesKvpairsToTerraform(struct?: RecipientPropertiesKvpairsOutputReference | RecipientPropertiesKvpairs): any;
export declare function recipientPropertiesKvpairsToHclTerraform(struct?: RecipientPropertiesKvpairsOutputReference | RecipientPropertiesKvpairs): any;
export declare class RecipientPropertiesKvpairsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RecipientPropertiesKvpairs | undefined;
    set internalValue(value: RecipientPropertiesKvpairs | undefined);
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface RecipientProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#workspace_id Recipient#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function recipientProviderConfigToTerraform(struct?: RecipientProviderConfigOutputReference | RecipientProviderConfig): any;
export declare function recipientProviderConfigToHclTerraform(struct?: RecipientProviderConfigOutputReference | RecipientProviderConfig): any;
export declare class RecipientProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RecipientProviderConfig | undefined;
    set internalValue(value: RecipientProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface RecipientTokens {
}
export declare function recipientTokensToTerraform(struct?: RecipientTokens | cdktn.IResolvable): any;
export declare function recipientTokensToHclTerraform(struct?: RecipientTokens | cdktn.IResolvable): any;
export declare class RecipientTokensOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RecipientTokens | cdktn.IResolvable | undefined;
    set internalValue(value: RecipientTokens | cdktn.IResolvable | undefined);
    get activationUrl(): string;
    get createdAt(): number;
    get createdBy(): string;
    get expirationTime(): number;
    get id(): string;
    get updatedAt(): number;
    get updatedBy(): string;
}
export declare class RecipientTokensList extends cdktn.ComplexList {
    internalValue?: RecipientTokens[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RecipientTokensOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient databricks_recipient}
*/
export declare class Recipient extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_recipient";
    /**
    * Generates CDKTN code for importing a Recipient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Recipient to import
    * @param importFromId The id of the existing Recipient that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Recipient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/resources/recipient databricks_recipient} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RecipientConfig
    */
    constructor(scope: Construct, id: string, config: RecipientConfig);
    get activated(): cdktn.IResolvable;
    get activationUrl(): string;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    get authenticationTypeInput(): string | undefined;
    get cloud(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdAt(): number;
    get createdBy(): string;
    private _dataRecipientGlobalMetastoreId?;
    get dataRecipientGlobalMetastoreId(): string;
    set dataRecipientGlobalMetastoreId(value: string);
    resetDataRecipientGlobalMetastoreId(): void;
    get dataRecipientGlobalMetastoreIdInput(): string | undefined;
    private _expirationTime?;
    get expirationTime(): number;
    set expirationTime(value: number);
    resetExpirationTime(): void;
    get expirationTimeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    get region(): string;
    private _sharingCode?;
    get sharingCode(): string;
    set sharingCode(value: string);
    resetSharingCode(): void;
    get sharingCodeInput(): string | undefined;
    get updatedAt(): number;
    get updatedBy(): string;
    private _ipAccessList;
    get ipAccessList(): RecipientIpAccessListStructOutputReference;
    putIpAccessList(value: RecipientIpAccessListStruct): void;
    resetIpAccessList(): void;
    get ipAccessListInput(): RecipientIpAccessListStruct | undefined;
    private _propertiesKvpairs;
    get propertiesKvpairs(): RecipientPropertiesKvpairsOutputReference;
    putPropertiesKvpairs(value: RecipientPropertiesKvpairs): void;
    resetPropertiesKvpairs(): void;
    get propertiesKvpairsInput(): RecipientPropertiesKvpairs | undefined;
    private _providerConfig;
    get providerConfig(): RecipientProviderConfigOutputReference;
    putProviderConfig(value: RecipientProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): RecipientProviderConfig | undefined;
    private _tokens;
    get tokens(): RecipientTokensList;
    putTokens(value: RecipientTokens[] | cdktn.IResolvable): void;
    resetTokens(): void;
    get tokensInput(): cdktn.IResolvable | RecipientTokens[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
