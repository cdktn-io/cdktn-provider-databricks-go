/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#provider_config DataDatabricksApps#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppsProviderConfig;
}
export interface DataDatabricksAppsAppActiveDeploymentDeploymentArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#source_code_path DataDatabricksApps#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppsAppActiveDeploymentDeploymentArtifactsToTerraform(struct?: DataDatabricksAppsAppActiveDeploymentDeploymentArtifacts): any;
export declare function dataDatabricksAppsAppActiveDeploymentDeploymentArtifactsToHclTerraform(struct?: DataDatabricksAppsAppActiveDeploymentDeploymentArtifacts): any;
export declare class DataDatabricksAppsAppActiveDeploymentDeploymentArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppActiveDeploymentDeploymentArtifacts | undefined;
    set internalValue(value: DataDatabricksAppsAppActiveDeploymentDeploymentArtifacts | undefined);
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
}
export interface DataDatabricksAppsAppActiveDeploymentEnvVars {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#name DataDatabricksApps#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#value DataDatabricksApps#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#value_from DataDatabricksApps#value_from}
    */
    readonly valueFrom?: string;
}
export declare function dataDatabricksAppsAppActiveDeploymentEnvVarsToTerraform(struct?: DataDatabricksAppsAppActiveDeploymentEnvVars | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppActiveDeploymentEnvVarsToHclTerraform(struct?: DataDatabricksAppsAppActiveDeploymentEnvVars | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppActiveDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsAppActiveDeploymentEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppActiveDeploymentEnvVars | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class DataDatabricksAppsAppActiveDeploymentEnvVarsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsAppActiveDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsAppActiveDeploymentEnvVarsOutputReference;
}
export interface DataDatabricksAppsAppActiveDeploymentGitSourceGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#provider DataDatabricksApps#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#url DataDatabricksApps#url}
    */
    readonly url: string;
}
export declare function dataDatabricksAppsAppActiveDeploymentGitSourceGitRepositoryToTerraform(struct?: DataDatabricksAppsAppActiveDeploymentGitSourceGitRepository): any;
export declare function dataDatabricksAppsAppActiveDeploymentGitSourceGitRepositoryToHclTerraform(struct?: DataDatabricksAppsAppActiveDeploymentGitSourceGitRepository): any;
export declare class DataDatabricksAppsAppActiveDeploymentGitSourceGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppActiveDeploymentGitSourceGitRepository | undefined;
    set internalValue(value: DataDatabricksAppsAppActiveDeploymentGitSourceGitRepository | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface DataDatabricksAppsAppActiveDeploymentGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#branch DataDatabricksApps#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#commit DataDatabricksApps#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#source_code_path DataDatabricksApps#source_code_path}
    */
    readonly sourceCodePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#tag DataDatabricksApps#tag}
    */
    readonly tag?: string;
}
export declare function dataDatabricksAppsAppActiveDeploymentGitSourceToTerraform(struct?: DataDatabricksAppsAppActiveDeploymentGitSource | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppActiveDeploymentGitSourceToHclTerraform(struct?: DataDatabricksAppsAppActiveDeploymentGitSource | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppActiveDeploymentGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppActiveDeploymentGitSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppActiveDeploymentGitSource | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _gitRepository;
    get gitRepository(): DataDatabricksAppsAppActiveDeploymentGitSourceGitRepositoryOutputReference;
    get resolvedCommit(): string;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface DataDatabricksAppsAppActiveDeploymentStatus {
}
export declare function dataDatabricksAppsAppActiveDeploymentStatusToTerraform(struct?: DataDatabricksAppsAppActiveDeploymentStatus): any;
export declare function dataDatabricksAppsAppActiveDeploymentStatusToHclTerraform(struct?: DataDatabricksAppsAppActiveDeploymentStatus): any;
export declare class DataDatabricksAppsAppActiveDeploymentStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppActiveDeploymentStatus | undefined;
    set internalValue(value: DataDatabricksAppsAppActiveDeploymentStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppsAppActiveDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#command DataDatabricksApps#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#deployment_id DataDatabricksApps#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#env_vars DataDatabricksApps#env_vars}
    */
    readonly envVars?: DataDatabricksAppsAppActiveDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#git_source DataDatabricksApps#git_source}
    */
    readonly gitSource?: DataDatabricksAppsAppActiveDeploymentGitSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#mode DataDatabricksApps#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#source_code_path DataDatabricksApps#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppsAppActiveDeploymentToTerraform(struct?: DataDatabricksAppsAppActiveDeployment): any;
export declare function dataDatabricksAppsAppActiveDeploymentToHclTerraform(struct?: DataDatabricksAppsAppActiveDeployment): any;
export declare class DataDatabricksAppsAppActiveDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppActiveDeployment | undefined;
    set internalValue(value: DataDatabricksAppsAppActiveDeployment | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    get createTime(): string;
    get creator(): string;
    private _deploymentArtifacts;
    get deploymentArtifacts(): DataDatabricksAppsAppActiveDeploymentDeploymentArtifactsOutputReference;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _envVars;
    get envVars(): DataDatabricksAppsAppActiveDeploymentEnvVarsList;
    putEnvVars(value: DataDatabricksAppsAppActiveDeploymentEnvVars[] | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | DataDatabricksAppsAppActiveDeploymentEnvVars[] | undefined;
    private _gitSource;
    get gitSource(): DataDatabricksAppsAppActiveDeploymentGitSourceOutputReference;
    putGitSource(value: DataDatabricksAppsAppActiveDeploymentGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): cdktn.IResolvable | DataDatabricksAppsAppActiveDeploymentGitSource | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _status;
    get status(): DataDatabricksAppsAppActiveDeploymentStatusOutputReference;
    get updateTime(): string;
}
export interface DataDatabricksAppsAppAppStatus {
}
export declare function dataDatabricksAppsAppAppStatusToTerraform(struct?: DataDatabricksAppsAppAppStatus): any;
export declare function dataDatabricksAppsAppAppStatusToHclTerraform(struct?: DataDatabricksAppsAppAppStatus): any;
export declare class DataDatabricksAppsAppAppStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppAppStatus | undefined;
    set internalValue(value: DataDatabricksAppsAppAppStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppsAppComputeStatus {
}
export declare function dataDatabricksAppsAppComputeStatusToTerraform(struct?: DataDatabricksAppsAppComputeStatus): any;
export declare function dataDatabricksAppsAppComputeStatusToHclTerraform(struct?: DataDatabricksAppsAppComputeStatus): any;
export declare class DataDatabricksAppsAppComputeStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppComputeStatus | undefined;
    set internalValue(value: DataDatabricksAppsAppComputeStatus | undefined);
    get activeInstances(): number;
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppsAppGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#provider DataDatabricksApps#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#url DataDatabricksApps#url}
    */
    readonly url: string;
}
export declare function dataDatabricksAppsAppGitRepositoryToTerraform(struct?: DataDatabricksAppsAppGitRepository | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppGitRepositoryToHclTerraform(struct?: DataDatabricksAppsAppGitRepository | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppGitRepository | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppGitRepository | cdktn.IResolvable | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface DataDatabricksAppsAppPendingDeploymentDeploymentArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#source_code_path DataDatabricksApps#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppsAppPendingDeploymentDeploymentArtifactsToTerraform(struct?: DataDatabricksAppsAppPendingDeploymentDeploymentArtifacts): any;
export declare function dataDatabricksAppsAppPendingDeploymentDeploymentArtifactsToHclTerraform(struct?: DataDatabricksAppsAppPendingDeploymentDeploymentArtifacts): any;
export declare class DataDatabricksAppsAppPendingDeploymentDeploymentArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppPendingDeploymentDeploymentArtifacts | undefined;
    set internalValue(value: DataDatabricksAppsAppPendingDeploymentDeploymentArtifacts | undefined);
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
}
export interface DataDatabricksAppsAppPendingDeploymentEnvVars {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#name DataDatabricksApps#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#value DataDatabricksApps#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#value_from DataDatabricksApps#value_from}
    */
    readonly valueFrom?: string;
}
export declare function dataDatabricksAppsAppPendingDeploymentEnvVarsToTerraform(struct?: DataDatabricksAppsAppPendingDeploymentEnvVars | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppPendingDeploymentEnvVarsToHclTerraform(struct?: DataDatabricksAppsAppPendingDeploymentEnvVars | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppPendingDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsAppPendingDeploymentEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppPendingDeploymentEnvVars | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class DataDatabricksAppsAppPendingDeploymentEnvVarsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsAppPendingDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsAppPendingDeploymentEnvVarsOutputReference;
}
export interface DataDatabricksAppsAppPendingDeploymentGitSourceGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#provider DataDatabricksApps#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#url DataDatabricksApps#url}
    */
    readonly url: string;
}
export declare function dataDatabricksAppsAppPendingDeploymentGitSourceGitRepositoryToTerraform(struct?: DataDatabricksAppsAppPendingDeploymentGitSourceGitRepository): any;
export declare function dataDatabricksAppsAppPendingDeploymentGitSourceGitRepositoryToHclTerraform(struct?: DataDatabricksAppsAppPendingDeploymentGitSourceGitRepository): any;
export declare class DataDatabricksAppsAppPendingDeploymentGitSourceGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppPendingDeploymentGitSourceGitRepository | undefined;
    set internalValue(value: DataDatabricksAppsAppPendingDeploymentGitSourceGitRepository | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface DataDatabricksAppsAppPendingDeploymentGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#branch DataDatabricksApps#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#commit DataDatabricksApps#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#source_code_path DataDatabricksApps#source_code_path}
    */
    readonly sourceCodePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#tag DataDatabricksApps#tag}
    */
    readonly tag?: string;
}
export declare function dataDatabricksAppsAppPendingDeploymentGitSourceToTerraform(struct?: DataDatabricksAppsAppPendingDeploymentGitSource | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppPendingDeploymentGitSourceToHclTerraform(struct?: DataDatabricksAppsAppPendingDeploymentGitSource | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppPendingDeploymentGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppPendingDeploymentGitSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppPendingDeploymentGitSource | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _gitRepository;
    get gitRepository(): DataDatabricksAppsAppPendingDeploymentGitSourceGitRepositoryOutputReference;
    get resolvedCommit(): string;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface DataDatabricksAppsAppPendingDeploymentStatus {
}
export declare function dataDatabricksAppsAppPendingDeploymentStatusToTerraform(struct?: DataDatabricksAppsAppPendingDeploymentStatus): any;
export declare function dataDatabricksAppsAppPendingDeploymentStatusToHclTerraform(struct?: DataDatabricksAppsAppPendingDeploymentStatus): any;
export declare class DataDatabricksAppsAppPendingDeploymentStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppPendingDeploymentStatus | undefined;
    set internalValue(value: DataDatabricksAppsAppPendingDeploymentStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppsAppPendingDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#command DataDatabricksApps#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#deployment_id DataDatabricksApps#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#env_vars DataDatabricksApps#env_vars}
    */
    readonly envVars?: DataDatabricksAppsAppPendingDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#git_source DataDatabricksApps#git_source}
    */
    readonly gitSource?: DataDatabricksAppsAppPendingDeploymentGitSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#mode DataDatabricksApps#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#source_code_path DataDatabricksApps#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppsAppPendingDeploymentToTerraform(struct?: DataDatabricksAppsAppPendingDeployment): any;
export declare function dataDatabricksAppsAppPendingDeploymentToHclTerraform(struct?: DataDatabricksAppsAppPendingDeployment): any;
export declare class DataDatabricksAppsAppPendingDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppPendingDeployment | undefined;
    set internalValue(value: DataDatabricksAppsAppPendingDeployment | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    get createTime(): string;
    get creator(): string;
    private _deploymentArtifacts;
    get deploymentArtifacts(): DataDatabricksAppsAppPendingDeploymentDeploymentArtifactsOutputReference;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _envVars;
    get envVars(): DataDatabricksAppsAppPendingDeploymentEnvVarsList;
    putEnvVars(value: DataDatabricksAppsAppPendingDeploymentEnvVars[] | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | DataDatabricksAppsAppPendingDeploymentEnvVars[] | undefined;
    private _gitSource;
    get gitSource(): DataDatabricksAppsAppPendingDeploymentGitSourceOutputReference;
    putGitSource(value: DataDatabricksAppsAppPendingDeploymentGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): cdktn.IResolvable | DataDatabricksAppsAppPendingDeploymentGitSource | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _status;
    get status(): DataDatabricksAppsAppPendingDeploymentStatusOutputReference;
    get updateTime(): string;
}
export interface DataDatabricksAppsAppResourcesApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#name DataDatabricksApps#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission?: string;
}
export declare function dataDatabricksAppsAppResourcesAppToTerraform(struct?: DataDatabricksAppsAppResourcesApp | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesAppToHclTerraform(struct?: DataDatabricksAppsAppResourcesApp | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesApp | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#database_name DataDatabricksApps#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#instance_name DataDatabricksApps#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsAppResourcesDatabaseToTerraform(struct?: DataDatabricksAppsAppResourcesDatabase | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesDatabaseToHclTerraform(struct?: DataDatabricksAppsAppResourcesDatabase | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#experiment_id DataDatabricksApps#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsAppResourcesExperimentToTerraform(struct?: DataDatabricksAppsAppResourcesExperiment | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesExperimentToHclTerraform(struct?: DataDatabricksAppsAppResourcesExperiment | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#name DataDatabricksApps#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#space_id DataDatabricksApps#space_id}
    */
    readonly spaceId: string;
}
export declare function dataDatabricksAppsAppResourcesGenieSpaceToTerraform(struct?: DataDatabricksAppsAppResourcesGenieSpace | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesGenieSpaceToHclTerraform(struct?: DataDatabricksAppsAppResourcesGenieSpace | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#id DataDatabricksApps#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsAppResourcesJobToTerraform(struct?: DataDatabricksAppsAppResourcesJob | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesJobToHclTerraform(struct?: DataDatabricksAppsAppResourcesJob | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesPostgres {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#branch DataDatabricksApps#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#database DataDatabricksApps#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission?: string;
}
export declare function dataDatabricksAppsAppResourcesPostgresToTerraform(struct?: DataDatabricksAppsAppResourcesPostgres | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesPostgresToHclTerraform(struct?: DataDatabricksAppsAppResourcesPostgres | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesPostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesPostgres | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesPostgres | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#key DataDatabricksApps#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#scope DataDatabricksApps#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksAppsAppResourcesSecretToTerraform(struct?: DataDatabricksAppsAppResourcesSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesSecretToHclTerraform(struct?: DataDatabricksAppsAppResourcesSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#name DataDatabricksApps#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsAppResourcesServingEndpointToTerraform(struct?: DataDatabricksAppsAppResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesServingEndpointToHclTerraform(struct?: DataDatabricksAppsAppResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#id DataDatabricksApps#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsAppResourcesSqlWarehouseToTerraform(struct?: DataDatabricksAppsAppResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesSqlWarehouseToHclTerraform(struct?: DataDatabricksAppsAppResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsAppResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#permission DataDatabricksApps#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#securable_full_name DataDatabricksApps#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#securable_type DataDatabricksApps#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppsAppResourcesUcSecurableToTerraform(struct?: DataDatabricksAppsAppResourcesUcSecurable | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesUcSecurableToHclTerraform(struct?: DataDatabricksAppsAppResourcesUcSecurable | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppsAppResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#app DataDatabricksApps#app}
    */
    readonly app?: DataDatabricksAppsAppResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#database DataDatabricksApps#database}
    */
    readonly database?: DataDatabricksAppsAppResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#description DataDatabricksApps#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#experiment DataDatabricksApps#experiment}
    */
    readonly experiment?: DataDatabricksAppsAppResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#genie_space DataDatabricksApps#genie_space}
    */
    readonly genieSpace?: DataDatabricksAppsAppResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#job DataDatabricksApps#job}
    */
    readonly job?: DataDatabricksAppsAppResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#name DataDatabricksApps#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#postgres DataDatabricksApps#postgres}
    */
    readonly postgres?: DataDatabricksAppsAppResourcesPostgres;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#secret DataDatabricksApps#secret}
    */
    readonly secret?: DataDatabricksAppsAppResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#serving_endpoint DataDatabricksApps#serving_endpoint}
    */
    readonly servingEndpoint?: DataDatabricksAppsAppResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#sql_warehouse DataDatabricksApps#sql_warehouse}
    */
    readonly sqlWarehouse?: DataDatabricksAppsAppResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#uc_securable DataDatabricksApps#uc_securable}
    */
    readonly ucSecurable?: DataDatabricksAppsAppResourcesUcSecurable;
}
export declare function dataDatabricksAppsAppResourcesToTerraform(struct?: DataDatabricksAppsAppResources | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppResourcesToHclTerraform(struct?: DataDatabricksAppsAppResources | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsAppResources | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppResources | cdktn.IResolvable | undefined);
    private _app;
    get app(): DataDatabricksAppsAppResourcesAppOutputReference;
    putApp(value: DataDatabricksAppsAppResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesApp | undefined;
    private _database;
    get database(): DataDatabricksAppsAppResourcesDatabaseOutputReference;
    putDatabase(value: DataDatabricksAppsAppResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): DataDatabricksAppsAppResourcesExperimentOutputReference;
    putExperiment(value: DataDatabricksAppsAppResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): DataDatabricksAppsAppResourcesGenieSpaceOutputReference;
    putGenieSpace(value: DataDatabricksAppsAppResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesGenieSpace | undefined;
    private _job;
    get job(): DataDatabricksAppsAppResourcesJobOutputReference;
    putJob(value: DataDatabricksAppsAppResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _postgres;
    get postgres(): DataDatabricksAppsAppResourcesPostgresOutputReference;
    putPostgres(value: DataDatabricksAppsAppResourcesPostgres): void;
    resetPostgres(): void;
    get postgresInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesPostgres | undefined;
    private _secret;
    get secret(): DataDatabricksAppsAppResourcesSecretOutputReference;
    putSecret(value: DataDatabricksAppsAppResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): DataDatabricksAppsAppResourcesServingEndpointOutputReference;
    putServingEndpoint(value: DataDatabricksAppsAppResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): DataDatabricksAppsAppResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: DataDatabricksAppsAppResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): DataDatabricksAppsAppResourcesUcSecurableOutputReference;
    putUcSecurable(value: DataDatabricksAppsAppResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | DataDatabricksAppsAppResourcesUcSecurable | undefined;
}
export declare class DataDatabricksAppsAppResourcesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsAppResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsAppResourcesOutputReference;
}
export interface DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#logs_table DataDatabricksApps#logs_table}
    */
    readonly logsTable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#metrics_table DataDatabricksApps#metrics_table}
    */
    readonly metricsTable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#traces_table DataDatabricksApps#traces_table}
    */
    readonly tracesTable: string;
}
export declare function dataDatabricksAppsAppTelemetryExportDestinationsUnityCatalogToTerraform(struct?: DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppTelemetryExportDestinationsUnityCatalogToHclTerraform(struct?: DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable | undefined);
    private _logsTable?;
    get logsTable(): string;
    set logsTable(value: string);
    get logsTableInput(): string | undefined;
    private _metricsTable?;
    get metricsTable(): string;
    set metricsTable(value: string);
    get metricsTableInput(): string | undefined;
    private _tracesTable?;
    get tracesTable(): string;
    set tracesTable(value: string);
    get tracesTableInput(): string | undefined;
}
export interface DataDatabricksAppsAppTelemetryExportDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#unity_catalog DataDatabricksApps#unity_catalog}
    */
    readonly unityCatalog?: DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog;
}
export declare function dataDatabricksAppsAppTelemetryExportDestinationsToTerraform(struct?: DataDatabricksAppsAppTelemetryExportDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAppsAppTelemetryExportDestinationsToHclTerraform(struct?: DataDatabricksAppsAppTelemetryExportDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAppsAppTelemetryExportDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsAppTelemetryExportDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsAppTelemetryExportDestinations | cdktn.IResolvable | undefined);
    private _unityCatalog;
    get unityCatalog(): DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalogOutputReference;
    putUnityCatalog(value: DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog): void;
    resetUnityCatalog(): void;
    get unityCatalogInput(): cdktn.IResolvable | DataDatabricksAppsAppTelemetryExportDestinationsUnityCatalog | undefined;
}
export declare class DataDatabricksAppsAppTelemetryExportDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsAppTelemetryExportDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsAppTelemetryExportDestinationsOutputReference;
}
export interface DataDatabricksAppsApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#budget_policy_id DataDatabricksApps#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#compute_size DataDatabricksApps#compute_size}
    */
    readonly computeSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#description DataDatabricksApps#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#git_repository DataDatabricksApps#git_repository}
    */
    readonly gitRepository?: DataDatabricksAppsAppGitRepository;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#name DataDatabricksApps#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#resources DataDatabricksApps#resources}
    */
    readonly resources?: DataDatabricksAppsAppResources[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#space DataDatabricksApps#space}
    */
    readonly space?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#telemetry_export_destinations DataDatabricksApps#telemetry_export_destinations}
    */
    readonly telemetryExportDestinations?: DataDatabricksAppsAppTelemetryExportDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#usage_policy_id DataDatabricksApps#usage_policy_id}
    */
    readonly usagePolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#user_api_scopes DataDatabricksApps#user_api_scopes}
    */
    readonly userApiScopes?: string[];
}
export declare function dataDatabricksAppsAppToTerraform(struct?: DataDatabricksAppsApp): any;
export declare function dataDatabricksAppsAppToHclTerraform(struct?: DataDatabricksAppsApp): any;
export declare class DataDatabricksAppsAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsApp | undefined;
    set internalValue(value: DataDatabricksAppsApp | undefined);
    private _activeDeployment;
    get activeDeployment(): DataDatabricksAppsAppActiveDeploymentOutputReference;
    private _appStatus;
    get appStatus(): DataDatabricksAppsAppAppStatusOutputReference;
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _computeSize?;
    get computeSize(): string;
    set computeSize(value: string);
    resetComputeSize(): void;
    get computeSizeInput(): string | undefined;
    private _computeStatus;
    get computeStatus(): DataDatabricksAppsAppComputeStatusOutputReference;
    get createTime(): string;
    get creator(): string;
    get defaultSourceCodePath(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveBudgetPolicyId(): string;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    private _gitRepository;
    get gitRepository(): DataDatabricksAppsAppGitRepositoryOutputReference;
    putGitRepository(value: DataDatabricksAppsAppGitRepository): void;
    resetGitRepository(): void;
    get gitRepositoryInput(): cdktn.IResolvable | DataDatabricksAppsAppGitRepository | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oauth2AppClientId(): string;
    get oauth2AppIntegrationId(): string;
    private _pendingDeployment;
    get pendingDeployment(): DataDatabricksAppsAppPendingDeploymentOutputReference;
    private _resources;
    get resources(): DataDatabricksAppsAppResourcesList;
    putResources(value: DataDatabricksAppsAppResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | DataDatabricksAppsAppResources[] | undefined;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _space?;
    get space(): string;
    set space(value: string);
    resetSpace(): void;
    get spaceInput(): string | undefined;
    private _telemetryExportDestinations;
    get telemetryExportDestinations(): DataDatabricksAppsAppTelemetryExportDestinationsList;
    putTelemetryExportDestinations(value: DataDatabricksAppsAppTelemetryExportDestinations[] | cdktn.IResolvable): void;
    resetTelemetryExportDestinations(): void;
    get telemetryExportDestinationsInput(): cdktn.IResolvable | DataDatabricksAppsAppTelemetryExportDestinations[] | undefined;
    get thumbnailUrl(): string;
    get updateTime(): string;
    get updater(): string;
    get url(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    private _userApiScopes?;
    get userApiScopes(): string[];
    set userApiScopes(value: string[]);
    resetUserApiScopes(): void;
    get userApiScopesInput(): string[] | undefined;
}
export declare class DataDatabricksAppsAppList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsApp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsAppOutputReference;
}
export interface DataDatabricksAppsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#workspace_id DataDatabricksApps#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAppsProviderConfigToTerraform(struct?: DataDatabricksAppsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppsProviderConfigToHclTerraform(struct?: DataDatabricksAppsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps databricks_apps}
*/
export declare class DataDatabricksApps extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_apps";
    /**
    * Generates CDKTN code for importing a DataDatabricksApps resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksApps to import
    * @param importFromId The id of the existing DataDatabricksApps that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksApps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.115.0/docs/data-sources/apps databricks_apps} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAppsConfig);
    private _app;
    get app(): DataDatabricksAppsAppList;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
