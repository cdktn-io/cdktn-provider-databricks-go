/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchDatasourceConfigAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#name DataDatabricksLakewatchDatasourceConfigA#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#provider_config DataDatabricksLakewatchDatasourceConfigA#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchDatasourceConfigProviderConfig;
}
export interface DataDatabricksLakewatchDatasourceConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#workspace_id DataDatabricksLakewatchDatasourceConfigA#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchDatasourceConfigProviderConfigToTerraform(struct?: DataDatabricksLakewatchDatasourceConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourceConfigProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchDatasourceConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourceConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceConfigUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#display_name DataDatabricksLakewatchDatasourceConfigA#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#email DataDatabricksLakewatchDatasourceConfigA#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#id DataDatabricksLakewatchDatasourceConfigA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#principal_type DataDatabricksLakewatchDatasourceConfigA#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchDatasourceConfigUpdatedByToTerraform(struct?: DataDatabricksLakewatchDatasourceConfigUpdatedBy): any;
export declare function dataDatabricksLakewatchDatasourceConfigUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchDatasourceConfigUpdatedBy): any;
export declare class DataDatabricksLakewatchDatasourceConfigUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceConfigUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceConfigUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config databricks_lakewatch_datasource_config}
*/
export declare class DataDatabricksLakewatchDatasourceConfigA extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_datasource_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchDatasourceConfigA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchDatasourceConfigA to import
    * @param importFromId The id of the existing DataDatabricksLakewatchDatasourceConfigA that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchDatasourceConfigA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_datasource_config databricks_lakewatch_datasource_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchDatasourceConfigAConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchDatasourceConfigAConfig);
    get defaultComputeMode(): string;
    get defaultFolder(): string;
    get effectiveDefaultFolder(): string;
    get etag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchDatasourceConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchDatasourceConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourceConfigProviderConfig | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchDatasourceConfigUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
