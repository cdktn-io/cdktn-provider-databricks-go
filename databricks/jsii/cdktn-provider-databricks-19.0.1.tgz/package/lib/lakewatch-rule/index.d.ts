/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LakewatchRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#annotations LakewatchRule#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#batch LakewatchRule#batch}
    */
    readonly batch?: LakewatchRuleBatch;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#catalog_name LakewatchRule#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#category LakewatchRule#category}
    */
    readonly category?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#content_resource_id LakewatchRule#content_resource_id}
    */
    readonly contentResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#deduplication LakewatchRule#deduplication}
    */
    readonly deduplication?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#deduplication_time_window LakewatchRule#deduplication_time_window}
    */
    readonly deduplicationTimeWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#description LakewatchRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#fidelity LakewatchRule#fidelity}
    */
    readonly fidelity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#mitre LakewatchRule#mitre}
    */
    readonly mitre?: LakewatchRuleMitre[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#objective LakewatchRule#objective}
    */
    readonly objective?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#output LakewatchRule#output}
    */
    readonly output: LakewatchRuleOutput;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#provider_config LakewatchRule#provider_config}
    */
    readonly providerConfig?: LakewatchRuleProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#references LakewatchRule#references}
    */
    readonly references?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#rule_name LakewatchRule#rule_name}
    */
    readonly ruleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#run_as_principal LakewatchRule#run_as_principal}
    */
    readonly runAsPrincipal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#runbook LakewatchRule#runbook}
    */
    readonly runbook?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#schedule LakewatchRule#schedule}
    */
    readonly schedule: LakewatchRuleSchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#schema_name LakewatchRule#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#severity LakewatchRule#severity}
    */
    readonly severity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#suppress_until_time LakewatchRule#suppress_until_time}
    */
    readonly suppressUntilTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#timerange LakewatchRule#timerange}
    */
    readonly timerange?: LakewatchRuleTimerange;
}
export interface LakewatchRuleBatchCustom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#notebook LakewatchRule#notebook}
    */
    readonly notebook: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#options LakewatchRule#options}
    */
    readonly options?: {
        [key: string]: string;
    };
}
export declare function lakewatchRuleBatchCustomToTerraform(struct?: LakewatchRuleBatchCustom | cdktn.IResolvable): any;
export declare function lakewatchRuleBatchCustomToHclTerraform(struct?: LakewatchRuleBatchCustom | cdktn.IResolvable): any;
export declare class LakewatchRuleBatchCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleBatchCustom | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleBatchCustom | cdktn.IResolvable | undefined);
    private _notebook?;
    get notebook(): string;
    set notebook(value: string);
    get notebookInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface LakewatchRuleBatchSql {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#default_catalog_name LakewatchRule#default_catalog_name}
    */
    readonly defaultCatalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#default_schema_name LakewatchRule#default_schema_name}
    */
    readonly defaultSchemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#query LakewatchRule#query}
    */
    readonly query: string;
}
export declare function lakewatchRuleBatchSqlToTerraform(struct?: LakewatchRuleBatchSql | cdktn.IResolvable): any;
export declare function lakewatchRuleBatchSqlToHclTerraform(struct?: LakewatchRuleBatchSql | cdktn.IResolvable): any;
export declare class LakewatchRuleBatchSqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleBatchSql | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleBatchSql | cdktn.IResolvable | undefined);
    private _defaultCatalogName?;
    get defaultCatalogName(): string;
    set defaultCatalogName(value: string);
    resetDefaultCatalogName(): void;
    get defaultCatalogNameInput(): string | undefined;
    private _defaultSchemaName?;
    get defaultSchemaName(): string;
    set defaultSchemaName(value: string);
    resetDefaultSchemaName(): void;
    get defaultSchemaNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface LakewatchRuleBatch {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#custom LakewatchRule#custom}
    */
    readonly custom?: LakewatchRuleBatchCustom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#sql LakewatchRule#sql}
    */
    readonly sql?: LakewatchRuleBatchSql;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#warehouse_id LakewatchRule#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function lakewatchRuleBatchToTerraform(struct?: LakewatchRuleBatch | cdktn.IResolvable): any;
export declare function lakewatchRuleBatchToHclTerraform(struct?: LakewatchRuleBatch | cdktn.IResolvable): any;
export declare class LakewatchRuleBatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleBatch | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleBatch | cdktn.IResolvable | undefined);
    private _custom;
    get custom(): LakewatchRuleBatchCustomOutputReference;
    putCustom(value: LakewatchRuleBatchCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | LakewatchRuleBatchCustom | undefined;
    private _sql;
    get sql(): LakewatchRuleBatchSqlOutputReference;
    putSql(value: LakewatchRuleBatchSql): void;
    resetSql(): void;
    get sqlInput(): cdktn.IResolvable | LakewatchRuleBatchSql | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface LakewatchRuleCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#display_name LakewatchRule#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#email LakewatchRule#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#id LakewatchRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#principal_type LakewatchRule#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchRuleCreatedByToTerraform(struct?: LakewatchRuleCreatedBy): any;
export declare function lakewatchRuleCreatedByToHclTerraform(struct?: LakewatchRuleCreatedBy): any;
export declare class LakewatchRuleCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleCreatedBy | undefined;
    set internalValue(value: LakewatchRuleCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface LakewatchRuleMitre {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#sub_technique LakewatchRule#sub_technique}
    */
    readonly subTechnique?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#sub_technique_id LakewatchRule#sub_technique_id}
    */
    readonly subTechniqueId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#tactic LakewatchRule#tactic}
    */
    readonly tactic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#taxonomy LakewatchRule#taxonomy}
    */
    readonly taxonomy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#technique LakewatchRule#technique}
    */
    readonly technique?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#technique_id LakewatchRule#technique_id}
    */
    readonly techniqueId?: string;
}
export declare function lakewatchRuleMitreToTerraform(struct?: LakewatchRuleMitre | cdktn.IResolvable): any;
export declare function lakewatchRuleMitreToHclTerraform(struct?: LakewatchRuleMitre | cdktn.IResolvable): any;
export declare class LakewatchRuleMitreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LakewatchRuleMitre | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleMitre | cdktn.IResolvable | undefined);
    private _subTechnique?;
    get subTechnique(): string;
    set subTechnique(value: string);
    resetSubTechnique(): void;
    get subTechniqueInput(): string | undefined;
    private _subTechniqueId?;
    get subTechniqueId(): string;
    set subTechniqueId(value: string);
    resetSubTechniqueId(): void;
    get subTechniqueIdInput(): string | undefined;
    private _tactic?;
    get tactic(): string;
    set tactic(value: string);
    resetTactic(): void;
    get tacticInput(): string | undefined;
    private _taxonomy?;
    get taxonomy(): string;
    set taxonomy(value: string);
    resetTaxonomy(): void;
    get taxonomyInput(): string | undefined;
    private _technique?;
    get technique(): string;
    set technique(value: string);
    resetTechnique(): void;
    get techniqueInput(): string | undefined;
    private _techniqueId?;
    get techniqueId(): string;
    set techniqueId(value: string);
    resetTechniqueId(): void;
    get techniqueIdInput(): string | undefined;
}
export declare class LakewatchRuleMitreList extends cdktn.ComplexList {
    internalValue?: LakewatchRuleMitre[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LakewatchRuleMitreOutputReference;
}
export interface LakewatchRuleOriginalContentPack {
}
export declare function lakewatchRuleOriginalContentPackToTerraform(struct?: LakewatchRuleOriginalContentPack): any;
export declare function lakewatchRuleOriginalContentPackToHclTerraform(struct?: LakewatchRuleOriginalContentPack): any;
export declare class LakewatchRuleOriginalContentPackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleOriginalContentPack | undefined;
    set internalValue(value: LakewatchRuleOriginalContentPack | undefined);
    get uuid(): string;
    get version(): string;
}
export interface LakewatchRuleOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#context LakewatchRule#context}
    */
    readonly context?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#default_context LakewatchRule#default_context}
    */
    readonly defaultContext?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#event_time_column LakewatchRule#event_time_column}
    */
    readonly eventTimeColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#summary LakewatchRule#summary}
    */
    readonly summary?: string;
}
export declare function lakewatchRuleOutputToTerraform(struct?: LakewatchRuleOutput | cdktn.IResolvable): any;
export declare function lakewatchRuleOutputToHclTerraform(struct?: LakewatchRuleOutput | cdktn.IResolvable): any;
export declare class LakewatchRuleOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleOutput | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleOutput | cdktn.IResolvable | undefined);
    private _context?;
    get context(): {
        [key: string]: string;
    };
    set context(value: {
        [key: string]: string;
    });
    resetContext(): void;
    get contextInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultContext?;
    get defaultContext(): boolean | cdktn.IResolvable;
    set defaultContext(value: boolean | cdktn.IResolvable);
    resetDefaultContext(): void;
    get defaultContextInput(): boolean | cdktn.IResolvable | undefined;
    private _eventTimeColumn?;
    get eventTimeColumn(): string;
    set eventTimeColumn(value: string);
    resetEventTimeColumn(): void;
    get eventTimeColumnInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    resetSummary(): void;
    get summaryInput(): string | undefined;
}
export interface LakewatchRuleOwner {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#display_name LakewatchRule#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#email LakewatchRule#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#id LakewatchRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#principal_type LakewatchRule#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchRuleOwnerToTerraform(struct?: LakewatchRuleOwner): any;
export declare function lakewatchRuleOwnerToHclTerraform(struct?: LakewatchRuleOwner): any;
export declare class LakewatchRuleOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleOwner | undefined;
    set internalValue(value: LakewatchRuleOwner | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface LakewatchRuleProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#workspace_id LakewatchRule#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakewatchRuleProviderConfigToTerraform(struct?: LakewatchRuleProviderConfig | cdktn.IResolvable): any;
export declare function lakewatchRuleProviderConfigToHclTerraform(struct?: LakewatchRuleProviderConfig | cdktn.IResolvable): any;
export declare class LakewatchRuleProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakewatchRuleSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#at_least_every LakewatchRule#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#continuous LakewatchRule#continuous}
    */
    readonly continuous?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#cron_expression LakewatchRule#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#enabled LakewatchRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function lakewatchRuleScheduleToTerraform(struct?: LakewatchRuleSchedule | cdktn.IResolvable): any;
export declare function lakewatchRuleScheduleToHclTerraform(struct?: LakewatchRuleSchedule | cdktn.IResolvable): any;
export declare class LakewatchRuleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleSchedule | cdktn.IResolvable | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _continuous?;
    get continuous(): boolean | cdktn.IResolvable;
    set continuous(value: boolean | cdktn.IResolvable);
    resetContinuous(): void;
    get continuousInput(): boolean | cdktn.IResolvable | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface LakewatchRuleStatus {
}
export declare function lakewatchRuleStatusToTerraform(struct?: LakewatchRuleStatus): any;
export declare function lakewatchRuleStatusToHclTerraform(struct?: LakewatchRuleStatus): any;
export declare class LakewatchRuleStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleStatus | undefined;
    set internalValue(value: LakewatchRuleStatus | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface LakewatchRuleTimerange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#extend_lookback LakewatchRule#extend_lookback}
    */
    readonly extendLookback?: string;
}
export declare function lakewatchRuleTimerangeToTerraform(struct?: LakewatchRuleTimerange | cdktn.IResolvable): any;
export declare function lakewatchRuleTimerangeToHclTerraform(struct?: LakewatchRuleTimerange | cdktn.IResolvable): any;
export declare class LakewatchRuleTimerangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleTimerange | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleTimerange | cdktn.IResolvable | undefined);
    private _extendLookback?;
    get extendLookback(): string;
    set extendLookback(value: string);
    resetExtendLookback(): void;
    get extendLookbackInput(): string | undefined;
}
export interface LakewatchRuleUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#display_name LakewatchRule#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#email LakewatchRule#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#id LakewatchRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#principal_type LakewatchRule#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchRuleUpdatedByToTerraform(struct?: LakewatchRuleUpdatedBy): any;
export declare function lakewatchRuleUpdatedByToHclTerraform(struct?: LakewatchRuleUpdatedBy): any;
export declare class LakewatchRuleUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleUpdatedBy | undefined;
    set internalValue(value: LakewatchRuleUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule databricks_lakewatch_rule}
*/
export declare class LakewatchRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_lakewatch_rule";
    /**
    * Generates CDKTN code for importing a LakewatchRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LakewatchRule to import
    * @param importFromId The id of the existing LakewatchRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LakewatchRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_rule databricks_lakewatch_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LakewatchRuleConfig
    */
    constructor(scope: Construct, id: string, config: LakewatchRuleConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _batch;
    get batch(): LakewatchRuleBatchOutputReference;
    putBatch(value: LakewatchRuleBatch): void;
    resetBatch(): void;
    get batchInput(): cdktn.IResolvable | LakewatchRuleBatch | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    get computeWorkspaceId(): string;
    private _contentResourceId?;
    get contentResourceId(): string;
    set contentResourceId(value: string);
    resetContentResourceId(): void;
    get contentResourceIdInput(): string | undefined;
    get createTime(): string;
    private _createdBy;
    get createdBy(): LakewatchRuleCreatedByOutputReference;
    private _deduplication?;
    get deduplication(): string;
    set deduplication(value: string);
    resetDeduplication(): void;
    get deduplicationInput(): string | undefined;
    private _deduplicationTimeWindow?;
    get deduplicationTimeWindow(): string;
    set deduplicationTimeWindow(value: string);
    resetDeduplicationTimeWindow(): void;
    get deduplicationTimeWindowInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveCatalogName(): string;
    get effectiveRuleName(): string;
    get effectiveRunAsPrincipal(): string;
    get effectiveSchemaName(): string;
    get etag(): string;
    private _fidelity?;
    get fidelity(): string;
    set fidelity(value: string);
    get fidelityInput(): string | undefined;
    private _mitre;
    get mitre(): LakewatchRuleMitreList;
    putMitre(value: LakewatchRuleMitre[] | cdktn.IResolvable): void;
    resetMitre(): void;
    get mitreInput(): cdktn.IResolvable | LakewatchRuleMitre[] | undefined;
    get name(): string;
    private _objective?;
    get objective(): string;
    set objective(value: string);
    resetObjective(): void;
    get objectiveInput(): string | undefined;
    private _originalContentPack;
    get originalContentPack(): LakewatchRuleOriginalContentPackOutputReference;
    private _output;
    get output(): LakewatchRuleOutputOutputReference;
    putOutput(value: LakewatchRuleOutput): void;
    get outputInput(): cdktn.IResolvable | LakewatchRuleOutput | undefined;
    private _owner;
    get owner(): LakewatchRuleOwnerOutputReference;
    private _providerConfig;
    get providerConfig(): LakewatchRuleProviderConfigOutputReference;
    putProviderConfig(value: LakewatchRuleProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | LakewatchRuleProviderConfig | undefined;
    private _references?;
    get references(): string[];
    set references(value: string[]);
    resetReferences(): void;
    get referencesInput(): string[] | undefined;
    get ruleId(): string;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _runAsPrincipal?;
    get runAsPrincipal(): string;
    set runAsPrincipal(value: string);
    resetRunAsPrincipal(): void;
    get runAsPrincipalInput(): string | undefined;
    private _runbook?;
    get runbook(): string;
    set runbook(value: string);
    resetRunbook(): void;
    get runbookInput(): string | undefined;
    private _schedule;
    get schedule(): LakewatchRuleScheduleOutputReference;
    putSchedule(value: LakewatchRuleSchedule): void;
    get scheduleInput(): cdktn.IResolvable | LakewatchRuleSchedule | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    get severityInput(): string | undefined;
    private _status;
    get status(): LakewatchRuleStatusOutputReference;
    private _suppressUntilTime?;
    get suppressUntilTime(): string;
    set suppressUntilTime(value: string);
    resetSuppressUntilTime(): void;
    get suppressUntilTimeInput(): string | undefined;
    private _timerange;
    get timerange(): LakewatchRuleTimerangeOutputReference;
    putTimerange(value: LakewatchRuleTimerange): void;
    resetTimerange(): void;
    get timerangeInput(): cdktn.IResolvable | LakewatchRuleTimerange | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): LakewatchRuleUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
