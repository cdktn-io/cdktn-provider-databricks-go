/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksGenieAgentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#page_size DataDatabricksGenieAgents#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#provider_config DataDatabricksGenieAgents#provider_config}
    */
    readonly providerConfig?: DataDatabricksGenieAgentsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#view DataDatabricksGenieAgents#view}
    */
    readonly view?: string;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#content DataDatabricksGenieAgents#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#format DataDatabricksGenieAgents#format}
    */
    readonly format: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswerToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswerToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswerList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswerOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#answer DataDatabricksGenieAgents#answer}
    */
    readonly answer?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#evaluation_note DataDatabricksGenieAgents#evaluation_note}
    */
    readonly evaluationNote?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#question DataDatabricksGenieAgents#question}
    */
    readonly question: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions | cdktn.IResolvable | undefined);
    private _answer;
    get answer(): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswerList;
    putAnswer(value: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable): void;
    resetAnswer(): void;
    get answerInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsAnswer[] | undefined;
    private _evaluationNote?;
    get evaluationNote(): string;
    set evaluationNote(value: string);
    resetEvaluationNote(): void;
    get evaluationNoteInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#questions DataDatabricksGenieAgents#questions}
    */
    readonly questions?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks | cdktn.IResolvable | undefined);
    private _questions;
    get questions(): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestionsList;
    putQuestions(value: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions[] | cdktn.IResolvable): void;
    resetQuestions(): void;
    get questionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksQuestions[] | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#question DataDatabricksGenieAgents#question}
    */
    readonly question: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestionsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestionsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestionsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sample_questions DataDatabricksGenieAgents#sample_questions}
    */
    readonly sampleQuestions?: DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionConfigToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionConfig | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionConfigToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionConfig | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionConfig | cdktn.IResolvable | undefined);
    private _sampleQuestions;
    get sampleQuestions(): DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestionsList;
    putSampleQuestions(value: DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions[] | cdktn.IResolvable): void;
    resetSampleQuestions(): void;
    get sampleQuestionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionConfigSampleQuestions[] | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#mcp_connection DataDatabricksGenieAgents#mcp_connection}
    */
    readonly mcpConnection: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnectionsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnectionsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections | cdktn.IResolvable | undefined);
    private _mcpConnection?;
    get mcpConnection(): string;
    set mcpConnection(value: string);
    get mcpConnectionInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnectionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnectionsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#column DataDatabricksGenieAgents#column}
    */
    readonly column: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#description DataDatabricksGenieAgents#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#display_name DataDatabricksGenieAgents#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#enable_entity_matching DataDatabricksGenieAgents#enable_entity_matching}
    */
    readonly enableEntityMatching?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#enable_format_assistance DataDatabricksGenieAgents#enable_format_assistance}
    */
    readonly enableFormatAssistance?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#exclude DataDatabricksGenieAgents#exclude}
    */
    readonly exclude?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#synonyms DataDatabricksGenieAgents#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enableEntityMatching?;
    get enableEntityMatching(): boolean | cdktn.IResolvable;
    set enableEntityMatching(value: boolean | cdktn.IResolvable);
    resetEnableEntityMatching(): void;
    get enableEntityMatchingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableFormatAssistance?;
    get enableFormatAssistance(): boolean | cdktn.IResolvable;
    set enableFormatAssistance(value: boolean | cdktn.IResolvable);
    resetEnableFormatAssistance(): void;
    get enableFormatAssistanceInput(): boolean | cdktn.IResolvable | undefined;
    private _exclude?;
    get exclude(): boolean | cdktn.IResolvable;
    set exclude(value: boolean | cdktn.IResolvable);
    resetExclude(): void;
    get excludeInput(): boolean | cdktn.IResolvable | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#column_configs DataDatabricksGenieAgents#column_configs}
    */
    readonly columnConfigs?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#description DataDatabricksGenieAgents#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#identifier DataDatabricksGenieAgents#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables | cdktn.IResolvable | undefined);
    private _columnConfigs;
    get columnConfigs(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigsList;
    putColumnConfigs(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable): void;
    resetColumnConfigs(): void;
    get columnConfigsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesColumnConfigs[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#description DataDatabricksGenieAgents#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#path DataDatabricksGenieAgents#path}
    */
    readonly path: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumesToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumesToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumesOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#mcp_connections DataDatabricksGenieAgents#mcp_connections}
    */
    readonly mcpConnections?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#tables DataDatabricksGenieAgents#tables}
    */
    readonly tables?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#volumes DataDatabricksGenieAgents#volumes}
    */
    readonly volumes?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources | cdktn.IResolvable | undefined);
    private _mcpConnections;
    get mcpConnections(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnectionsList;
    putMcpConnections(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable): void;
    resetMcpConnections(): void;
    get mcpConnectionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesMcpConnections[] | undefined;
    private _tables;
    get tables(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTablesList;
    putTables(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesTables[] | undefined;
    private _volumes;
    get volumes(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumesList;
    putVolumes(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesVolumes[] | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#max DataDatabricksGenieAgents#max}
    */
    readonly max?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#min DataDatabricksGenieAgents#min}
    */
    readonly min?: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable | undefined);
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#value_range DataDatabricksGenieAgents#value_range}
    */
    readonly valueRange?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#values DataDatabricksGenieAgents#values}
    */
    readonly values?: string[];
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable | undefined);
    private _valueRange;
    get valueRange(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeOutputReference;
    putValueRange(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange): void;
    resetValueRange(): void;
    get valueRangeInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#default_value DataDatabricksGenieAgents#default_value}
    */
    readonly defaultValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#description DataDatabricksGenieAgents#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#name DataDatabricksGenieAgents#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#type_hint DataDatabricksGenieAgents#type_hint}
    */
    readonly typeHint?: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable | undefined);
    private _defaultValue;
    get defaultValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueOutputReference;
    putDefaultValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue): void;
    resetDefaultValue(): void;
    get defaultValueInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _typeHint?;
    get typeHint(): string;
    set typeHint(value: string);
    resetTypeHint(): void;
    get typeHintInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#parameters DataDatabricksGenieAgents#parameters}
    */
    readonly parameters?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#question DataDatabricksGenieAgents#question}
    */
    readonly question: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sql DataDatabricksGenieAgents#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#usage_guidance DataDatabricksGenieAgents#usage_guidance}
    */
    readonly usageGuidance?: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _parameters;
    get parameters(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParametersList;
    putParameters(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsParameters[] | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _usageGuidance?;
    get usageGuidance(): string;
    set usageGuidance(value: string);
    resetUsageGuidance(): void;
    get usageGuidanceInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#alias DataDatabricksGenieAgents#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#identifier DataDatabricksGenieAgents#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeftToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeftToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#alias DataDatabricksGenieAgents#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#identifier DataDatabricksGenieAgents#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRightToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRightToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRightOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#comment DataDatabricksGenieAgents#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#instruction DataDatabricksGenieAgents#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#left DataDatabricksGenieAgents#left}
    */
    readonly left: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#relationship_type DataDatabricksGenieAgents#relationship_type}
    */
    readonly relationshipType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#right DataDatabricksGenieAgents#right}
    */
    readonly right: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sql DataDatabricksGenieAgents#sql}
    */
    readonly sql: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _left;
    get left(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeftOutputReference;
    putLeft(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft): void;
    get leftInput(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsLeft | undefined;
    private _relationshipType?;
    get relationshipType(): string;
    set relationshipType(value: string);
    resetRelationshipType(): void;
    get relationshipTypeInput(): string | undefined;
    private _right;
    get right(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRightOutputReference;
    putRight(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight): void;
    get rightInput(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsRight | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#identifier DataDatabricksGenieAgents#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctionsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctionsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctionsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#alias DataDatabricksGenieAgents#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#display_name DataDatabricksGenieAgents#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#instruction DataDatabricksGenieAgents#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sql DataDatabricksGenieAgents#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#synonyms DataDatabricksGenieAgents#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressionsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressionsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressionsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#display_name DataDatabricksGenieAgents#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#instruction DataDatabricksGenieAgents#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sql DataDatabricksGenieAgents#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#synonyms DataDatabricksGenieAgents#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFiltersToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFiltersToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFiltersOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#alias DataDatabricksGenieAgents#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#display_name DataDatabricksGenieAgents#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#instruction DataDatabricksGenieAgents#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sql DataDatabricksGenieAgents#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#synonyms DataDatabricksGenieAgents#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasuresToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasuresToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasuresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasuresList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasuresOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#expressions DataDatabricksGenieAgents#expressions}
    */
    readonly expressions?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#filters DataDatabricksGenieAgents#filters}
    */
    readonly filters?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#measures DataDatabricksGenieAgents#measures}
    */
    readonly measures?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets | cdktn.IResolvable | undefined);
    private _expressions;
    get expressions(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressionsList;
    putExpressions(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable): void;
    resetExpressions(): void;
    get expressionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsExpressions[] | undefined;
    private _filters;
    get filters(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFiltersList;
    putFilters(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsFilters[] | undefined;
    private _measures;
    get measures(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasuresList;
    putMeasures(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable): void;
    resetMeasures(): void;
    get measuresInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsMeasures[] | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#content DataDatabricksGenieAgents#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#id DataDatabricksGenieAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructionsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructionsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructionsOutputReference;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#example_question_sqls DataDatabricksGenieAgents#example_question_sqls}
    */
    readonly exampleQuestionSqls?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#join_specs DataDatabricksGenieAgents#join_specs}
    */
    readonly joinSpecs?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sql_functions DataDatabricksGenieAgents#sql_functions}
    */
    readonly sqlFunctions?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#sql_snippets DataDatabricksGenieAgents#sql_snippets}
    */
    readonly sqlSnippets?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#text_instructions DataDatabricksGenieAgents#text_instructions}
    */
    readonly textInstructions?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions | cdktn.IResolvable | undefined);
    private _exampleQuestionSqls;
    get exampleQuestionSqls(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqlsList;
    putExampleQuestionSqls(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable): void;
    resetExampleQuestionSqls(): void;
    get exampleQuestionSqlsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsExampleQuestionSqls[] | undefined;
    private _joinSpecs;
    get joinSpecs(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecsList;
    putJoinSpecs(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable): void;
    resetJoinSpecs(): void;
    get joinSpecsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsJoinSpecs[] | undefined;
    private _sqlFunctions;
    get sqlFunctions(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctionsList;
    putSqlFunctions(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable): void;
    resetSqlFunctions(): void;
    get sqlFunctionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlFunctions[] | undefined;
    private _sqlSnippets;
    get sqlSnippets(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippetsOutputReference;
    putSqlSnippets(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets): void;
    resetSqlSnippets(): void;
    get sqlSnippetsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsSqlSnippets | undefined;
    private _textInstructions;
    get textInstructions(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructionsList;
    putTextInstructions(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions[] | cdktn.IResolvable): void;
    resetTextInstructions(): void;
    get textInstructionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsTextInstructions[] | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#benchmarks DataDatabricksGenieAgents#benchmarks}
    */
    readonly benchmarks?: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#config DataDatabricksGenieAgents#config}
    */
    readonly config?: DataDatabricksGenieAgentsGenieAgentsDefinitionConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#data_sources DataDatabricksGenieAgents#data_sources}
    */
    readonly dataSources?: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#instructions DataDatabricksGenieAgents#instructions}
    */
    readonly instructions?: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions;
}
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinition): any;
export declare function dataDatabricksGenieAgentsGenieAgentsDefinitionToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsDefinition): any;
export declare class DataDatabricksGenieAgentsGenieAgentsDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsDefinition | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsDefinition | undefined);
    private _benchmarks;
    get benchmarks(): DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarksOutputReference;
    putBenchmarks(value: DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks): void;
    resetBenchmarks(): void;
    get benchmarksInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionBenchmarks | undefined;
    private _config;
    get config(): DataDatabricksGenieAgentsGenieAgentsDefinitionConfigOutputReference;
    putConfig(value: DataDatabricksGenieAgentsGenieAgentsDefinitionConfig): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionConfig | undefined;
    private _dataSources;
    get dataSources(): DataDatabricksGenieAgentsGenieAgentsDefinitionDataSourcesOutputReference;
    putDataSources(value: DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources): void;
    resetDataSources(): void;
    get dataSourcesInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionDataSources | undefined;
    private _instructions;
    get instructions(): DataDatabricksGenieAgentsGenieAgentsDefinitionInstructionsOutputReference;
    putInstructions(value: DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions): void;
    resetInstructions(): void;
    get instructionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsDefinitionInstructions | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#workspace_id DataDatabricksGenieAgents#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksGenieAgentsGenieAgentsProviderConfigToTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsGenieAgentsProviderConfigToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsGenieAgentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsGenieAgentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksGenieAgentsGenieAgents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#name DataDatabricksGenieAgents#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#provider_config DataDatabricksGenieAgents#provider_config}
    */
    readonly providerConfig?: DataDatabricksGenieAgentsGenieAgentsProviderConfig;
}
export declare function dataDatabricksGenieAgentsGenieAgentsToTerraform(struct?: DataDatabricksGenieAgentsGenieAgents): any;
export declare function dataDatabricksGenieAgentsGenieAgentsToHclTerraform(struct?: DataDatabricksGenieAgentsGenieAgents): any;
export declare class DataDatabricksGenieAgentsGenieAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentsGenieAgents | undefined;
    set internalValue(value: DataDatabricksGenieAgentsGenieAgents | undefined);
    get createTime(): string;
    private _definition;
    get definition(): DataDatabricksGenieAgentsGenieAgentsDefinitionOutputReference;
    get description(): string;
    get displayName(): string;
    get effectiveParentPath(): string;
    get etag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentPath(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksGenieAgentsGenieAgentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksGenieAgentsGenieAgentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksGenieAgentsGenieAgentsProviderConfig | undefined;
    get updateTime(): string;
    get warehouseId(): string;
}
export declare class DataDatabricksGenieAgentsGenieAgentsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentsGenieAgents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentsGenieAgentsOutputReference;
}
export interface DataDatabricksGenieAgentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#workspace_id DataDatabricksGenieAgents#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksGenieAgentsProviderConfigToTerraform(struct?: DataDatabricksGenieAgentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentsProviderConfigToHclTerraform(struct?: DataDatabricksGenieAgentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents databricks_genie_agents}
*/
export declare class DataDatabricksGenieAgents extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_genie_agents";
    /**
    * Generates CDKTN code for importing a DataDatabricksGenieAgents resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksGenieAgents to import
    * @param importFromId The id of the existing DataDatabricksGenieAgents that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksGenieAgents to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/genie_agents databricks_genie_agents} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksGenieAgentsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksGenieAgentsConfig);
    private _genieAgents;
    get genieAgents(): DataDatabricksGenieAgentsGenieAgentsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksGenieAgentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksGenieAgentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksGenieAgentsProviderConfig | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
