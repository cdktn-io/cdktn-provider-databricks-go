/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#name DataDatabricksLakewatchRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#provider_config DataDatabricksLakewatchRule#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchRuleProviderConfig;
}
export interface DataDatabricksLakewatchRuleBatchCustom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#notebook DataDatabricksLakewatchRule#notebook}
    */
    readonly notebook: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#options DataDatabricksLakewatchRule#options}
    */
    readonly options?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksLakewatchRuleBatchCustomToTerraform(struct?: DataDatabricksLakewatchRuleBatchCustom | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRuleBatchCustomToHclTerraform(struct?: DataDatabricksLakewatchRuleBatchCustom | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRuleBatchCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleBatchCustom | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleBatchCustom | cdktn.IResolvable | undefined);
    private _notebook?;
    get notebook(): string;
    set notebook(value: string);
    get notebookInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksLakewatchRuleBatchSql {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#default_catalog_name DataDatabricksLakewatchRule#default_catalog_name}
    */
    readonly defaultCatalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#default_schema_name DataDatabricksLakewatchRule#default_schema_name}
    */
    readonly defaultSchemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#query DataDatabricksLakewatchRule#query}
    */
    readonly query: string;
}
export declare function dataDatabricksLakewatchRuleBatchSqlToTerraform(struct?: DataDatabricksLakewatchRuleBatchSql | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRuleBatchSqlToHclTerraform(struct?: DataDatabricksLakewatchRuleBatchSql | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRuleBatchSqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleBatchSql | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleBatchSql | cdktn.IResolvable | undefined);
    private _defaultCatalogName?;
    get defaultCatalogName(): string;
    set defaultCatalogName(value: string);
    resetDefaultCatalogName(): void;
    get defaultCatalogNameInput(): string | undefined;
    private _defaultSchemaName?;
    get defaultSchemaName(): string;
    set defaultSchemaName(value: string);
    resetDefaultSchemaName(): void;
    get defaultSchemaNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleBatch {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#custom DataDatabricksLakewatchRule#custom}
    */
    readonly custom?: DataDatabricksLakewatchRuleBatchCustom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#sql DataDatabricksLakewatchRule#sql}
    */
    readonly sql?: DataDatabricksLakewatchRuleBatchSql;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#warehouse_id DataDatabricksLakewatchRule#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksLakewatchRuleBatchToTerraform(struct?: DataDatabricksLakewatchRuleBatch): any;
export declare function dataDatabricksLakewatchRuleBatchToHclTerraform(struct?: DataDatabricksLakewatchRuleBatch): any;
export declare class DataDatabricksLakewatchRuleBatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleBatch | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleBatch | undefined);
    private _custom;
    get custom(): DataDatabricksLakewatchRuleBatchCustomOutputReference;
    putCustom(value: DataDatabricksLakewatchRuleBatchCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | DataDatabricksLakewatchRuleBatchCustom | undefined;
    private _sql;
    get sql(): DataDatabricksLakewatchRuleBatchSqlOutputReference;
    putSql(value: DataDatabricksLakewatchRuleBatchSql): void;
    resetSql(): void;
    get sqlInput(): cdktn.IResolvable | DataDatabricksLakewatchRuleBatchSql | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#display_name DataDatabricksLakewatchRule#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#email DataDatabricksLakewatchRule#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#id DataDatabricksLakewatchRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#principal_type DataDatabricksLakewatchRule#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchRuleCreatedByToTerraform(struct?: DataDatabricksLakewatchRuleCreatedBy): any;
export declare function dataDatabricksLakewatchRuleCreatedByToHclTerraform(struct?: DataDatabricksLakewatchRuleCreatedBy): any;
export declare class DataDatabricksLakewatchRuleCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleCreatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleMitre {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#sub_technique DataDatabricksLakewatchRule#sub_technique}
    */
    readonly subTechnique?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#sub_technique_id DataDatabricksLakewatchRule#sub_technique_id}
    */
    readonly subTechniqueId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#tactic DataDatabricksLakewatchRule#tactic}
    */
    readonly tactic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#taxonomy DataDatabricksLakewatchRule#taxonomy}
    */
    readonly taxonomy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#technique DataDatabricksLakewatchRule#technique}
    */
    readonly technique?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#technique_id DataDatabricksLakewatchRule#technique_id}
    */
    readonly techniqueId?: string;
}
export declare function dataDatabricksLakewatchRuleMitreToTerraform(struct?: DataDatabricksLakewatchRuleMitre): any;
export declare function dataDatabricksLakewatchRuleMitreToHclTerraform(struct?: DataDatabricksLakewatchRuleMitre): any;
export declare class DataDatabricksLakewatchRuleMitreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchRuleMitre | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleMitre | undefined);
    private _subTechnique?;
    get subTechnique(): string;
    set subTechnique(value: string);
    resetSubTechnique(): void;
    get subTechniqueInput(): string | undefined;
    private _subTechniqueId?;
    get subTechniqueId(): string;
    set subTechniqueId(value: string);
    resetSubTechniqueId(): void;
    get subTechniqueIdInput(): string | undefined;
    private _tactic?;
    get tactic(): string;
    set tactic(value: string);
    resetTactic(): void;
    get tacticInput(): string | undefined;
    private _taxonomy?;
    get taxonomy(): string;
    set taxonomy(value: string);
    resetTaxonomy(): void;
    get taxonomyInput(): string | undefined;
    private _technique?;
    get technique(): string;
    set technique(value: string);
    resetTechnique(): void;
    get techniqueInput(): string | undefined;
    private _techniqueId?;
    get techniqueId(): string;
    set techniqueId(value: string);
    resetTechniqueId(): void;
    get techniqueIdInput(): string | undefined;
}
export declare class DataDatabricksLakewatchRuleMitreList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchRuleMitre[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchRuleMitreOutputReference;
}
export interface DataDatabricksLakewatchRuleOriginalContentPack {
}
export declare function dataDatabricksLakewatchRuleOriginalContentPackToTerraform(struct?: DataDatabricksLakewatchRuleOriginalContentPack): any;
export declare function dataDatabricksLakewatchRuleOriginalContentPackToHclTerraform(struct?: DataDatabricksLakewatchRuleOriginalContentPack): any;
export declare class DataDatabricksLakewatchRuleOriginalContentPackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleOriginalContentPack | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleOriginalContentPack | undefined);
    get uuid(): string;
    get version(): string;
}
export interface DataDatabricksLakewatchRuleOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#context DataDatabricksLakewatchRule#context}
    */
    readonly context?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#default_context DataDatabricksLakewatchRule#default_context}
    */
    readonly defaultContext?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#event_time_column DataDatabricksLakewatchRule#event_time_column}
    */
    readonly eventTimeColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#summary DataDatabricksLakewatchRule#summary}
    */
    readonly summary?: string;
}
export declare function dataDatabricksLakewatchRuleOutputToTerraform(struct?: DataDatabricksLakewatchRuleOutput): any;
export declare function dataDatabricksLakewatchRuleOutputToHclTerraform(struct?: DataDatabricksLakewatchRuleOutput): any;
export declare class DataDatabricksLakewatchRuleOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleOutput | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleOutput | undefined);
    private _context?;
    get context(): {
        [key: string]: string;
    };
    set context(value: {
        [key: string]: string;
    });
    resetContext(): void;
    get contextInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultContext?;
    get defaultContext(): boolean | cdktn.IResolvable;
    set defaultContext(value: boolean | cdktn.IResolvable);
    resetDefaultContext(): void;
    get defaultContextInput(): boolean | cdktn.IResolvable | undefined;
    private _eventTimeColumn?;
    get eventTimeColumn(): string;
    set eventTimeColumn(value: string);
    resetEventTimeColumn(): void;
    get eventTimeColumnInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    resetSummary(): void;
    get summaryInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleOwner {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#display_name DataDatabricksLakewatchRule#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#email DataDatabricksLakewatchRule#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#id DataDatabricksLakewatchRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#principal_type DataDatabricksLakewatchRule#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchRuleOwnerToTerraform(struct?: DataDatabricksLakewatchRuleOwner): any;
export declare function dataDatabricksLakewatchRuleOwnerToHclTerraform(struct?: DataDatabricksLakewatchRuleOwner): any;
export declare class DataDatabricksLakewatchRuleOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleOwner | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleOwner | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#workspace_id DataDatabricksLakewatchRule#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchRuleProviderConfigToTerraform(struct?: DataDatabricksLakewatchRuleProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRuleProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchRuleProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRuleProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#at_least_every DataDatabricksLakewatchRule#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#continuous DataDatabricksLakewatchRule#continuous}
    */
    readonly continuous?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#cron_expression DataDatabricksLakewatchRule#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#enabled DataDatabricksLakewatchRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksLakewatchRuleScheduleToTerraform(struct?: DataDatabricksLakewatchRuleSchedule): any;
export declare function dataDatabricksLakewatchRuleScheduleToHclTerraform(struct?: DataDatabricksLakewatchRuleSchedule): any;
export declare class DataDatabricksLakewatchRuleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleSchedule | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleSchedule | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _continuous?;
    get continuous(): boolean | cdktn.IResolvable;
    set continuous(value: boolean | cdktn.IResolvable);
    resetContinuous(): void;
    get continuousInput(): boolean | cdktn.IResolvable | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksLakewatchRuleStatus {
}
export declare function dataDatabricksLakewatchRuleStatusToTerraform(struct?: DataDatabricksLakewatchRuleStatus): any;
export declare function dataDatabricksLakewatchRuleStatusToHclTerraform(struct?: DataDatabricksLakewatchRuleStatus): any;
export declare class DataDatabricksLakewatchRuleStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleStatus | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleStatus | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface DataDatabricksLakewatchRuleTimerange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#extend_lookback DataDatabricksLakewatchRule#extend_lookback}
    */
    readonly extendLookback?: string;
}
export declare function dataDatabricksLakewatchRuleTimerangeToTerraform(struct?: DataDatabricksLakewatchRuleTimerange): any;
export declare function dataDatabricksLakewatchRuleTimerangeToHclTerraform(struct?: DataDatabricksLakewatchRuleTimerange): any;
export declare class DataDatabricksLakewatchRuleTimerangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleTimerange | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleTimerange | undefined);
    private _extendLookback?;
    get extendLookback(): string;
    set extendLookback(value: string);
    resetExtendLookback(): void;
    get extendLookbackInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#display_name DataDatabricksLakewatchRule#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#email DataDatabricksLakewatchRule#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#id DataDatabricksLakewatchRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#principal_type DataDatabricksLakewatchRule#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchRuleUpdatedByToTerraform(struct?: DataDatabricksLakewatchRuleUpdatedBy): any;
export declare function dataDatabricksLakewatchRuleUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchRuleUpdatedBy): any;
export declare class DataDatabricksLakewatchRuleUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule databricks_lakewatch_rule}
*/
export declare class DataDatabricksLakewatchRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_rule";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchRule to import
    * @param importFromId The id of the existing DataDatabricksLakewatchRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/data-sources/lakewatch_rule databricks_lakewatch_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchRuleConfig);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _batch;
    get batch(): DataDatabricksLakewatchRuleBatchOutputReference;
    get catalogName(): string;
    get category(): string;
    get computeWorkspaceId(): string;
    get contentResourceId(): string;
    get createTime(): string;
    private _createdBy;
    get createdBy(): DataDatabricksLakewatchRuleCreatedByOutputReference;
    get deduplication(): string;
    get deduplicationTimeWindow(): string;
    get description(): string;
    get effectiveCatalogName(): string;
    get effectiveRuleName(): string;
    get effectiveRunAsPrincipal(): string;
    get effectiveSchemaName(): string;
    get etag(): string;
    get fidelity(): string;
    private _mitre;
    get mitre(): DataDatabricksLakewatchRuleMitreList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get objective(): string;
    private _originalContentPack;
    get originalContentPack(): DataDatabricksLakewatchRuleOriginalContentPackOutputReference;
    private _output;
    get output(): DataDatabricksLakewatchRuleOutputOutputReference;
    private _owner;
    get owner(): DataDatabricksLakewatchRuleOwnerOutputReference;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchRuleProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchRuleProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchRuleProviderConfig | undefined;
    get references(): string[];
    get ruleId(): string;
    get ruleName(): string;
    get runAsPrincipal(): string;
    get runbook(): string;
    private _schedule;
    get schedule(): DataDatabricksLakewatchRuleScheduleOutputReference;
    get schemaName(): string;
    get severity(): string;
    private _status;
    get status(): DataDatabricksLakewatchRuleStatusOutputReference;
    get suppressUntilTime(): string;
    private _timerange;
    get timerange(): DataDatabricksLakewatchRuleTimerangeOutputReference;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchRuleUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
