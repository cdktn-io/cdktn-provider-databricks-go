/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LakewatchCommonConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#custom_content_pack_path LakewatchCommonConfig#custom_content_pack_path}
    */
    readonly customContentPackPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#custom_presets_path LakewatchCommonConfig#custom_presets_path}
    */
    readonly customPresetsPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#parent LakewatchCommonConfig#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#per_resource_permissions_enabled LakewatchCommonConfig#per_resource_permissions_enabled}
    */
    readonly perResourcePermissionsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#provider_config LakewatchCommonConfig#provider_config}
    */
    readonly providerConfig?: LakewatchCommonConfigProviderConfig;
}
export interface LakewatchCommonConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#workspace_id LakewatchCommonConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakewatchCommonConfigProviderConfigToTerraform(struct?: LakewatchCommonConfigProviderConfig | cdktn.IResolvable): any;
export declare function lakewatchCommonConfigProviderConfigToHclTerraform(struct?: LakewatchCommonConfigProviderConfig | cdktn.IResolvable): any;
export declare class LakewatchCommonConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchCommonConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchCommonConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakewatchCommonConfigUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#display_name LakewatchCommonConfig#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#email LakewatchCommonConfig#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#id LakewatchCommonConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#principal_type LakewatchCommonConfig#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchCommonConfigUpdatedByToTerraform(struct?: LakewatchCommonConfigUpdatedBy): any;
export declare function lakewatchCommonConfigUpdatedByToHclTerraform(struct?: LakewatchCommonConfigUpdatedBy): any;
export declare class LakewatchCommonConfigUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchCommonConfigUpdatedBy | undefined;
    set internalValue(value: LakewatchCommonConfigUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config databricks_lakewatch_common_config}
*/
export declare class LakewatchCommonConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_lakewatch_common_config";
    /**
    * Generates CDKTN code for importing a LakewatchCommonConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LakewatchCommonConfig to import
    * @param importFromId The id of the existing LakewatchCommonConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LakewatchCommonConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.142.0/docs/resources/lakewatch_common_config databricks_lakewatch_common_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LakewatchCommonConfigConfig
    */
    constructor(scope: Construct, id: string, config: LakewatchCommonConfigConfig);
    private _customContentPackPath?;
    get customContentPackPath(): string;
    set customContentPackPath(value: string);
    resetCustomContentPackPath(): void;
    get customContentPackPathInput(): string | undefined;
    private _customPresetsPath?;
    get customPresetsPath(): string;
    set customPresetsPath(value: string);
    resetCustomPresetsPath(): void;
    get customPresetsPathInput(): string | undefined;
    get etag(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _perResourcePermissionsEnabled?;
    get perResourcePermissionsEnabled(): boolean | cdktn.IResolvable;
    set perResourcePermissionsEnabled(value: boolean | cdktn.IResolvable);
    resetPerResourcePermissionsEnabled(): void;
    get perResourcePermissionsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): LakewatchCommonConfigProviderConfigOutputReference;
    putProviderConfig(value: LakewatchCommonConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | LakewatchCommonConfigProviderConfig | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): LakewatchCommonConfigUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
