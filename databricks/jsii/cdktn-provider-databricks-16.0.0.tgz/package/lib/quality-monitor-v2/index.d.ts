/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface QualityMonitorV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#object_id QualityMonitorV2#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#object_type QualityMonitorV2#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#provider_config QualityMonitorV2#provider_config}
    */
    readonly providerConfig?: QualityMonitorV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#validity_check_configurations QualityMonitorV2#validity_check_configurations}
    */
    readonly validityCheckConfigurations?: QualityMonitorV2ValidityCheckConfigurations[] | cdktn.IResolvable;
}
export interface QualityMonitorV2AnomalyDetectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#excluded_table_full_names QualityMonitorV2#excluded_table_full_names}
    */
    readonly excludedTableFullNames?: string[];
}
export declare function qualityMonitorV2AnomalyDetectionConfigToTerraform(struct?: QualityMonitorV2AnomalyDetectionConfig): any;
export declare function qualityMonitorV2AnomalyDetectionConfigToHclTerraform(struct?: QualityMonitorV2AnomalyDetectionConfig): any;
export declare class QualityMonitorV2AnomalyDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QualityMonitorV2AnomalyDetectionConfig | undefined;
    set internalValue(value: QualityMonitorV2AnomalyDetectionConfig | undefined);
    private _excludedTableFullNames?;
    get excludedTableFullNames(): string[];
    set excludedTableFullNames(value: string[]);
    resetExcludedTableFullNames(): void;
    get excludedTableFullNamesInput(): string[] | undefined;
    get lastRunId(): string;
    get latestRunStatus(): string;
}
export interface QualityMonitorV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#workspace_id QualityMonitorV2#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function qualityMonitorV2ProviderConfigToTerraform(struct?: QualityMonitorV2ProviderConfig | cdktn.IResolvable): any;
export declare function qualityMonitorV2ProviderConfigToHclTerraform(struct?: QualityMonitorV2ProviderConfig | cdktn.IResolvable): any;
export declare class QualityMonitorV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QualityMonitorV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#column_names QualityMonitorV2#column_names}
    */
    readonly columnNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#upper_bound QualityMonitorV2#upper_bound}
    */
    readonly upperBound?: number;
}
export declare function qualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckToTerraform(struct?: QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable): any;
export declare function qualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckToHclTerraform(struct?: QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable): any;
export declare class QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
    private _upperBound?;
    get upperBound(): number;
    set upperBound(value: number);
    resetUpperBound(): void;
    get upperBoundInput(): number | undefined;
}
export interface QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#column_names QualityMonitorV2#column_names}
    */
    readonly columnNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#lower_bound QualityMonitorV2#lower_bound}
    */
    readonly lowerBound?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#upper_bound QualityMonitorV2#upper_bound}
    */
    readonly upperBound?: number;
}
export declare function qualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckToTerraform(struct?: QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable): any;
export declare function qualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckToHclTerraform(struct?: QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable): any;
export declare class QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
    private _lowerBound?;
    get lowerBound(): number;
    set lowerBound(value: number);
    resetLowerBound(): void;
    get lowerBoundInput(): number | undefined;
    private _upperBound?;
    get upperBound(): number;
    set upperBound(value: number);
    resetUpperBound(): void;
    get upperBoundInput(): number | undefined;
}
export interface QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#column_names QualityMonitorV2#column_names}
    */
    readonly columnNames?: string[];
}
export declare function qualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckToTerraform(struct?: QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable): any;
export declare function qualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckToHclTerraform(struct?: QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable): any;
export declare class QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
}
export interface QualityMonitorV2ValidityCheckConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#name QualityMonitorV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#percent_null_validity_check QualityMonitorV2#percent_null_validity_check}
    */
    readonly percentNullValidityCheck?: QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#range_validity_check QualityMonitorV2#range_validity_check}
    */
    readonly rangeValidityCheck?: QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#uniqueness_validity_check QualityMonitorV2#uniqueness_validity_check}
    */
    readonly uniquenessValidityCheck?: QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck;
}
export declare function qualityMonitorV2ValidityCheckConfigurationsToTerraform(struct?: QualityMonitorV2ValidityCheckConfigurations | cdktn.IResolvable): any;
export declare function qualityMonitorV2ValidityCheckConfigurationsToHclTerraform(struct?: QualityMonitorV2ValidityCheckConfigurations | cdktn.IResolvable): any;
export declare class QualityMonitorV2ValidityCheckConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorV2ValidityCheckConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorV2ValidityCheckConfigurations | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _percentNullValidityCheck;
    get percentNullValidityCheck(): QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckOutputReference;
    putPercentNullValidityCheck(value: QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck): void;
    resetPercentNullValidityCheck(): void;
    get percentNullValidityCheckInput(): cdktn.IResolvable | QualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | undefined;
    private _rangeValidityCheck;
    get rangeValidityCheck(): QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckOutputReference;
    putRangeValidityCheck(value: QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck): void;
    resetRangeValidityCheck(): void;
    get rangeValidityCheckInput(): cdktn.IResolvable | QualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | undefined;
    private _uniquenessValidityCheck;
    get uniquenessValidityCheck(): QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckOutputReference;
    putUniquenessValidityCheck(value: QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck): void;
    resetUniquenessValidityCheck(): void;
    get uniquenessValidityCheckInput(): cdktn.IResolvable | QualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | undefined;
}
export declare class QualityMonitorV2ValidityCheckConfigurationsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: QualityMonitorV2ValidityCheckConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorV2ValidityCheckConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2 databricks_quality_monitor_v2}
*/
export declare class QualityMonitorV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_quality_monitor_v2";
    /**
    * Generates CDKTN code for importing a QualityMonitorV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the QualityMonitorV2 to import
    * @param importFromId The id of the existing QualityMonitorV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the QualityMonitorV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/quality_monitor_v2 databricks_quality_monitor_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options QualityMonitorV2Config
    */
    constructor(scope: Construct, id: string, config: QualityMonitorV2Config);
    private _anomalyDetectionConfig;
    get anomalyDetectionConfig(): QualityMonitorV2AnomalyDetectionConfigOutputReference;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): QualityMonitorV2ProviderConfigOutputReference;
    putProviderConfig(value: QualityMonitorV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | QualityMonitorV2ProviderConfig | undefined;
    private _validityCheckConfigurations;
    get validityCheckConfigurations(): QualityMonitorV2ValidityCheckConfigurationsList;
    putValidityCheckConfigurations(value: QualityMonitorV2ValidityCheckConfigurations[] | cdktn.IResolvable): void;
    resetValidityCheckConfigurations(): void;
    get validityCheckConfigurationsInput(): cdktn.IResolvable | QualityMonitorV2ValidityCheckConfigurations[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
