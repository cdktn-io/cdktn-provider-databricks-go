/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FeatureEngineeringKafkaConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#auth_config FeatureEngineeringKafkaConfig#auth_config}
    */
    readonly authConfig: FeatureEngineeringKafkaConfigAuthConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#backfill_source FeatureEngineeringKafkaConfig#backfill_source}
    */
    readonly backfillSource?: FeatureEngineeringKafkaConfigBackfillSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#bootstrap_servers FeatureEngineeringKafkaConfig#bootstrap_servers}
    */
    readonly bootstrapServers: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#extra_options FeatureEngineeringKafkaConfig#extra_options}
    */
    readonly extraOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#key_schema FeatureEngineeringKafkaConfig#key_schema}
    */
    readonly keySchema?: FeatureEngineeringKafkaConfigKeySchema;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#provider_config FeatureEngineeringKafkaConfig#provider_config}
    */
    readonly providerConfig?: FeatureEngineeringKafkaConfigProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#subscription_mode FeatureEngineeringKafkaConfig#subscription_mode}
    */
    readonly subscriptionMode: FeatureEngineeringKafkaConfigSubscriptionMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#value_schema FeatureEngineeringKafkaConfig#value_schema}
    */
    readonly valueSchema?: FeatureEngineeringKafkaConfigValueSchema;
}
export interface FeatureEngineeringKafkaConfigAuthConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#uc_service_credential_name FeatureEngineeringKafkaConfig#uc_service_credential_name}
    */
    readonly ucServiceCredentialName?: string;
}
export declare function featureEngineeringKafkaConfigAuthConfigToTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigAuthConfigToHclTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable | undefined);
    private _ucServiceCredentialName?;
    get ucServiceCredentialName(): string;
    set ucServiceCredentialName(value: string);
    resetUcServiceCredentialName(): void;
    get ucServiceCredentialNameInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#entity_columns FeatureEngineeringKafkaConfig#entity_columns}
    */
    readonly entityColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#full_name FeatureEngineeringKafkaConfig#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#timeseries_column FeatureEngineeringKafkaConfig#timeseries_column}
    */
    readonly timeseriesColumn: string;
}
export declare function featureEngineeringKafkaConfigBackfillSourceDeltaTableSourceToTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigBackfillSourceDeltaTableSourceToHclTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    get entityColumnsInput(): string[] | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    get timeseriesColumnInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigBackfillSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#delta_table_source FeatureEngineeringKafkaConfig#delta_table_source}
    */
    readonly deltaTableSource?: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource;
}
export declare function featureEngineeringKafkaConfigBackfillSourceToTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigBackfillSourceToHclTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigBackfillSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable | undefined);
    private _deltaTableSource;
    get deltaTableSource(): FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | undefined;
}
export interface FeatureEngineeringKafkaConfigKeySchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}
    */
    readonly jsonSchema?: string;
}
export declare function featureEngineeringKafkaConfigKeySchemaToTerraform(struct?: FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigKeySchemaToHclTerraform(struct?: FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigKeySchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable | undefined);
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#workspace_id FeatureEngineeringKafkaConfig#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function featureEngineeringKafkaConfigProviderConfigToTerraform(struct?: FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigProviderConfigToHclTerraform(struct?: FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigSubscriptionMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#assign FeatureEngineeringKafkaConfig#assign}
    */
    readonly assign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#subscribe FeatureEngineeringKafkaConfig#subscribe}
    */
    readonly subscribe?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#subscribe_pattern FeatureEngineeringKafkaConfig#subscribe_pattern}
    */
    readonly subscribePattern?: string;
}
export declare function featureEngineeringKafkaConfigSubscriptionModeToTerraform(struct?: FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigSubscriptionModeToHclTerraform(struct?: FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigSubscriptionModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable | undefined);
    private _assign?;
    get assign(): string;
    set assign(value: string);
    resetAssign(): void;
    get assignInput(): string | undefined;
    private _subscribe?;
    get subscribe(): string;
    set subscribe(value: string);
    resetSubscribe(): void;
    get subscribeInput(): string | undefined;
    private _subscribePattern?;
    get subscribePattern(): string;
    set subscribePattern(value: string);
    resetSubscribePattern(): void;
    get subscribePatternInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigValueSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}
    */
    readonly jsonSchema?: string;
}
export declare function featureEngineeringKafkaConfigValueSchemaToTerraform(struct?: FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigValueSchemaToHclTerraform(struct?: FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigValueSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable | undefined);
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config}
*/
export declare class FeatureEngineeringKafkaConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_feature_engineering_kafka_config";
    /**
    * Generates CDKTN code for importing a FeatureEngineeringKafkaConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FeatureEngineeringKafkaConfig to import
    * @param importFromId The id of the existing FeatureEngineeringKafkaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FeatureEngineeringKafkaConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FeatureEngineeringKafkaConfigConfig
    */
    constructor(scope: Construct, id: string, config: FeatureEngineeringKafkaConfigConfig);
    private _authConfig;
    get authConfig(): FeatureEngineeringKafkaConfigAuthConfigOutputReference;
    putAuthConfig(value: FeatureEngineeringKafkaConfigAuthConfig): void;
    get authConfigInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigAuthConfig | undefined;
    private _backfillSource;
    get backfillSource(): FeatureEngineeringKafkaConfigBackfillSourceOutputReference;
    putBackfillSource(value: FeatureEngineeringKafkaConfigBackfillSource): void;
    resetBackfillSource(): void;
    get backfillSourceInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigBackfillSource | undefined;
    private _bootstrapServers?;
    get bootstrapServers(): string;
    set bootstrapServers(value: string);
    get bootstrapServersInput(): string | undefined;
    private _extraOptions?;
    get extraOptions(): {
        [key: string]: string;
    };
    set extraOptions(value: {
        [key: string]: string;
    });
    resetExtraOptions(): void;
    get extraOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _keySchema;
    get keySchema(): FeatureEngineeringKafkaConfigKeySchemaOutputReference;
    putKeySchema(value: FeatureEngineeringKafkaConfigKeySchema): void;
    resetKeySchema(): void;
    get keySchemaInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigKeySchema | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): FeatureEngineeringKafkaConfigProviderConfigOutputReference;
    putProviderConfig(value: FeatureEngineeringKafkaConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigProviderConfig | undefined;
    private _subscriptionMode;
    get subscriptionMode(): FeatureEngineeringKafkaConfigSubscriptionModeOutputReference;
    putSubscriptionMode(value: FeatureEngineeringKafkaConfigSubscriptionMode): void;
    get subscriptionModeInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigSubscriptionMode | undefined;
    private _valueSchema;
    get valueSchema(): FeatureEngineeringKafkaConfigValueSchemaOutputReference;
    putValueSchema(value: FeatureEngineeringKafkaConfigValueSchema): void;
    resetValueSchema(): void;
    get valueSchemaInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigValueSchema | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
