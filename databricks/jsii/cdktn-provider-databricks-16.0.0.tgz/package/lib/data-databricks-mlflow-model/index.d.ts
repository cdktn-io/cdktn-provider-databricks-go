/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMlflowModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#description DataDatabricksMlflowModel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#name DataDatabricksMlflowModel#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#permission_level DataDatabricksMlflowModel#permission_level}
    */
    readonly permissionLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#user_id DataDatabricksMlflowModel#user_id}
    */
    readonly userId?: string;
    /**
    * latest_versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#latest_versions DataDatabricksMlflowModel#latest_versions}
    */
    readonly latestVersions?: DataDatabricksMlflowModelLatestVersions[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#provider_config DataDatabricksMlflowModel#provider_config}
    */
    readonly providerConfig?: DataDatabricksMlflowModelProviderConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#tags DataDatabricksMlflowModel#tags}
    */
    readonly tags?: DataDatabricksMlflowModelTags[] | cdktn.IResolvable;
}
export interface DataDatabricksMlflowModelLatestVersionsTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#key DataDatabricksMlflowModel#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#value DataDatabricksMlflowModel#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksMlflowModelLatestVersionsTagsToTerraform(struct?: DataDatabricksMlflowModelLatestVersionsTags | cdktn.IResolvable): any;
export declare function dataDatabricksMlflowModelLatestVersionsTagsToHclTerraform(struct?: DataDatabricksMlflowModelLatestVersionsTags | cdktn.IResolvable): any;
export declare class DataDatabricksMlflowModelLatestVersionsTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMlflowModelLatestVersionsTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMlflowModelLatestVersionsTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksMlflowModelLatestVersionsTagsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksMlflowModelLatestVersionsTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMlflowModelLatestVersionsTagsOutputReference;
}
export interface DataDatabricksMlflowModelLatestVersions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#creation_timestamp DataDatabricksMlflowModel#creation_timestamp}
    */
    readonly creationTimestamp?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#current_stage DataDatabricksMlflowModel#current_stage}
    */
    readonly currentStage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#description DataDatabricksMlflowModel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#last_updated_timestamp DataDatabricksMlflowModel#last_updated_timestamp}
    */
    readonly lastUpdatedTimestamp?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#name DataDatabricksMlflowModel#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#run_id DataDatabricksMlflowModel#run_id}
    */
    readonly runId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#run_link DataDatabricksMlflowModel#run_link}
    */
    readonly runLink?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#source DataDatabricksMlflowModel#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#status DataDatabricksMlflowModel#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#status_message DataDatabricksMlflowModel#status_message}
    */
    readonly statusMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#user_id DataDatabricksMlflowModel#user_id}
    */
    readonly userId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#version DataDatabricksMlflowModel#version}
    */
    readonly version?: string;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#tags DataDatabricksMlflowModel#tags}
    */
    readonly tags?: DataDatabricksMlflowModelLatestVersionsTags[] | cdktn.IResolvable;
}
export declare function dataDatabricksMlflowModelLatestVersionsToTerraform(struct?: DataDatabricksMlflowModelLatestVersions | cdktn.IResolvable): any;
export declare function dataDatabricksMlflowModelLatestVersionsToHclTerraform(struct?: DataDatabricksMlflowModelLatestVersions | cdktn.IResolvable): any;
export declare class DataDatabricksMlflowModelLatestVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMlflowModelLatestVersions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMlflowModelLatestVersions | cdktn.IResolvable | undefined);
    private _creationTimestamp?;
    get creationTimestamp(): number;
    set creationTimestamp(value: number);
    resetCreationTimestamp(): void;
    get creationTimestampInput(): number | undefined;
    private _currentStage?;
    get currentStage(): string;
    set currentStage(value: string);
    resetCurrentStage(): void;
    get currentStageInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _lastUpdatedTimestamp?;
    get lastUpdatedTimestamp(): number;
    set lastUpdatedTimestamp(value: number);
    resetLastUpdatedTimestamp(): void;
    get lastUpdatedTimestampInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _runId?;
    get runId(): string;
    set runId(value: string);
    resetRunId(): void;
    get runIdInput(): string | undefined;
    private _runLink?;
    get runLink(): string;
    set runLink(value: string);
    resetRunLink(): void;
    get runLinkInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _statusMessage?;
    get statusMessage(): string;
    set statusMessage(value: string);
    resetStatusMessage(): void;
    get statusMessageInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _tags;
    get tags(): DataDatabricksMlflowModelLatestVersionsTagsList;
    putTags(value: DataDatabricksMlflowModelLatestVersionsTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | DataDatabricksMlflowModelLatestVersionsTags[] | undefined;
}
export declare class DataDatabricksMlflowModelLatestVersionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksMlflowModelLatestVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMlflowModelLatestVersionsOutputReference;
}
export interface DataDatabricksMlflowModelProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#workspace_id DataDatabricksMlflowModel#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksMlflowModelProviderConfigToTerraform(struct?: DataDatabricksMlflowModelProviderConfigOutputReference | DataDatabricksMlflowModelProviderConfig): any;
export declare function dataDatabricksMlflowModelProviderConfigToHclTerraform(struct?: DataDatabricksMlflowModelProviderConfigOutputReference | DataDatabricksMlflowModelProviderConfig): any;
export declare class DataDatabricksMlflowModelProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMlflowModelProviderConfig | undefined;
    set internalValue(value: DataDatabricksMlflowModelProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMlflowModelTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#key DataDatabricksMlflowModel#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#value DataDatabricksMlflowModel#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksMlflowModelTagsToTerraform(struct?: DataDatabricksMlflowModelTags | cdktn.IResolvable): any;
export declare function dataDatabricksMlflowModelTagsToHclTerraform(struct?: DataDatabricksMlflowModelTags | cdktn.IResolvable): any;
export declare class DataDatabricksMlflowModelTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMlflowModelTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMlflowModelTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksMlflowModelTagsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksMlflowModelTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMlflowModelTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model databricks_mlflow_model}
*/
export declare class DataDatabricksMlflowModel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mlflow_model";
    /**
    * Generates CDKTN code for importing a DataDatabricksMlflowModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMlflowModel to import
    * @param importFromId The id of the existing DataDatabricksMlflowModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMlflowModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/mlflow_model databricks_mlflow_model} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMlflowModelConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMlflowModelConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permissionLevel?;
    get permissionLevel(): string;
    set permissionLevel(value: string);
    resetPermissionLevel(): void;
    get permissionLevelInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _latestVersions;
    get latestVersions(): DataDatabricksMlflowModelLatestVersionsList;
    putLatestVersions(value: DataDatabricksMlflowModelLatestVersions[] | cdktn.IResolvable): void;
    resetLatestVersions(): void;
    get latestVersionsInput(): cdktn.IResolvable | DataDatabricksMlflowModelLatestVersions[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMlflowModelProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMlflowModelProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksMlflowModelProviderConfig | undefined;
    private _tags;
    get tags(): DataDatabricksMlflowModelTagsList;
    putTags(value: DataDatabricksMlflowModelTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | DataDatabricksMlflowModelTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
