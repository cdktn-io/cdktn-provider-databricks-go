/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppsSpaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#name DataDatabricksAppsSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#provider_config DataDatabricksAppsSpace#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppsSpaceProviderConfig;
}
export interface DataDatabricksAppsSpaceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#workspace_id DataDatabricksAppsSpace#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksAppsSpaceProviderConfigToTerraform(struct?: DataDatabricksAppsSpaceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceProviderConfigToHclTerraform(struct?: DataDatabricksAppsSpaceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesApp {
}
export declare function dataDatabricksAppsSpaceResourcesAppToTerraform(struct?: DataDatabricksAppsSpaceResourcesApp | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesAppToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesApp | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesApp | cdktn.IResolvable | undefined);
}
export interface DataDatabricksAppsSpaceResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#database_name DataDatabricksAppsSpace#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#instance_name DataDatabricksAppsSpace#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpaceResourcesDatabaseToTerraform(struct?: DataDatabricksAppsSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesDatabaseToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#experiment_id DataDatabricksAppsSpace#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpaceResourcesExperimentToTerraform(struct?: DataDatabricksAppsSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesExperimentToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#name DataDatabricksAppsSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#space_id DataDatabricksAppsSpace#space_id}
    */
    readonly spaceId: string;
}
export declare function dataDatabricksAppsSpaceResourcesGenieSpaceToTerraform(struct?: DataDatabricksAppsSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesGenieSpaceToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#id DataDatabricksAppsSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpaceResourcesJobToTerraform(struct?: DataDatabricksAppsSpaceResourcesJob | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesJobToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesJob | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#key DataDatabricksAppsSpace#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#scope DataDatabricksAppsSpace#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksAppsSpaceResourcesSecretToTerraform(struct?: DataDatabricksAppsSpaceResourcesSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesSecretToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#name DataDatabricksAppsSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpaceResourcesServingEndpointToTerraform(struct?: DataDatabricksAppsSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesServingEndpointToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#id DataDatabricksAppsSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpaceResourcesSqlWarehouseToTerraform(struct?: DataDatabricksAppsSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesSqlWarehouseToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#permission DataDatabricksAppsSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#securable_full_name DataDatabricksAppsSpace#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#securable_type DataDatabricksAppsSpace#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppsSpaceResourcesUcSecurableToTerraform(struct?: DataDatabricksAppsSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpaceResourcesUcSecurableToHclTerraform(struct?: DataDatabricksAppsSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpaceResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppsSpaceResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#app DataDatabricksAppsSpace#app}
    */
    readonly app?: DataDatabricksAppsSpaceResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#database DataDatabricksAppsSpace#database}
    */
    readonly database?: DataDatabricksAppsSpaceResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#description DataDatabricksAppsSpace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#experiment DataDatabricksAppsSpace#experiment}
    */
    readonly experiment?: DataDatabricksAppsSpaceResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#genie_space DataDatabricksAppsSpace#genie_space}
    */
    readonly genieSpace?: DataDatabricksAppsSpaceResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#job DataDatabricksAppsSpace#job}
    */
    readonly job?: DataDatabricksAppsSpaceResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#name DataDatabricksAppsSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#secret DataDatabricksAppsSpace#secret}
    */
    readonly secret?: DataDatabricksAppsSpaceResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#serving_endpoint DataDatabricksAppsSpace#serving_endpoint}
    */
    readonly servingEndpoint?: DataDatabricksAppsSpaceResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#sql_warehouse DataDatabricksAppsSpace#sql_warehouse}
    */
    readonly sqlWarehouse?: DataDatabricksAppsSpaceResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#uc_securable DataDatabricksAppsSpace#uc_securable}
    */
    readonly ucSecurable?: DataDatabricksAppsSpaceResourcesUcSecurable;
}
export declare function dataDatabricksAppsSpaceResourcesToTerraform(struct?: DataDatabricksAppsSpaceResources): any;
export declare function dataDatabricksAppsSpaceResourcesToHclTerraform(struct?: DataDatabricksAppsSpaceResources): any;
export declare class DataDatabricksAppsSpaceResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsSpaceResources | undefined;
    set internalValue(value: DataDatabricksAppsSpaceResources | undefined);
    private _app;
    get app(): DataDatabricksAppsSpaceResourcesAppOutputReference;
    putApp(value: DataDatabricksAppsSpaceResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesApp | undefined;
    private _database;
    get database(): DataDatabricksAppsSpaceResourcesDatabaseOutputReference;
    putDatabase(value: DataDatabricksAppsSpaceResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): DataDatabricksAppsSpaceResourcesExperimentOutputReference;
    putExperiment(value: DataDatabricksAppsSpaceResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): DataDatabricksAppsSpaceResourcesGenieSpaceOutputReference;
    putGenieSpace(value: DataDatabricksAppsSpaceResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesGenieSpace | undefined;
    private _job;
    get job(): DataDatabricksAppsSpaceResourcesJobOutputReference;
    putJob(value: DataDatabricksAppsSpaceResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secret;
    get secret(): DataDatabricksAppsSpaceResourcesSecretOutputReference;
    putSecret(value: DataDatabricksAppsSpaceResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): DataDatabricksAppsSpaceResourcesServingEndpointOutputReference;
    putServingEndpoint(value: DataDatabricksAppsSpaceResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): DataDatabricksAppsSpaceResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: DataDatabricksAppsSpaceResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): DataDatabricksAppsSpaceResourcesUcSecurableOutputReference;
    putUcSecurable(value: DataDatabricksAppsSpaceResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | DataDatabricksAppsSpaceResourcesUcSecurable | undefined;
}
export declare class DataDatabricksAppsSpaceResourcesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksAppsSpaceResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsSpaceResourcesOutputReference;
}
export interface DataDatabricksAppsSpaceStatus {
}
export declare function dataDatabricksAppsSpaceStatusToTerraform(struct?: DataDatabricksAppsSpaceStatus): any;
export declare function dataDatabricksAppsSpaceStatusToHclTerraform(struct?: DataDatabricksAppsSpaceStatus): any;
export declare class DataDatabricksAppsSpaceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpaceStatus | undefined;
    set internalValue(value: DataDatabricksAppsSpaceStatus | undefined);
    get message(): string;
    get state(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space databricks_apps_space}
*/
export declare class DataDatabricksAppsSpace extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_apps_space";
    /**
    * Generates CDKTN code for importing a DataDatabricksAppsSpace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAppsSpace to import
    * @param importFromId The id of the existing DataDatabricksAppsSpace that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAppsSpace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_space databricks_apps_space} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppsSpaceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAppsSpaceConfig);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oauth2AppClientId(): string;
    get oauth2AppIntegrationId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppsSpaceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppsSpaceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppsSpaceProviderConfig | undefined;
    private _resources;
    get resources(): DataDatabricksAppsSpaceResourcesList;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _status;
    get status(): DataDatabricksAppsSpaceStatusOutputReference;
    get updateTime(): string;
    get updater(): string;
    get usagePolicyId(): string;
    get userApiScopes(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
