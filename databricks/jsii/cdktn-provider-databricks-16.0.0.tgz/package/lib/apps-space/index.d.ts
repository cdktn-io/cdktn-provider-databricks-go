/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsSpaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#description AppsSpace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#provider_config AppsSpace#provider_config}
    */
    readonly providerConfig?: AppsSpaceProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#resources AppsSpace#resources}
    */
    readonly resources?: AppsSpaceResources[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#usage_policy_id AppsSpace#usage_policy_id}
    */
    readonly usagePolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#user_api_scopes AppsSpace#user_api_scopes}
    */
    readonly userApiScopes?: string[];
}
export interface AppsSpaceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#workspace_id AppsSpace#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function appsSpaceProviderConfigToTerraform(struct?: AppsSpaceProviderConfig | cdktn.IResolvable): any;
export declare function appsSpaceProviderConfigToHclTerraform(struct?: AppsSpaceProviderConfig | cdktn.IResolvable): any;
export declare class AppsSpaceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface AppsSpaceResourcesApp {
}
export declare function appsSpaceResourcesAppToTerraform(struct?: AppsSpaceResourcesApp | cdktn.IResolvable): any;
export declare function appsSpaceResourcesAppToHclTerraform(struct?: AppsSpaceResourcesApp | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesApp | cdktn.IResolvable | undefined);
}
export interface AppsSpaceResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#database_name AppsSpace#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#instance_name AppsSpace#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
}
export declare function appsSpaceResourcesDatabaseToTerraform(struct?: AppsSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare function appsSpaceResourcesDatabaseToHclTerraform(struct?: AppsSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSpaceResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#experiment_id AppsSpace#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
}
export declare function appsSpaceResourcesExperimentToTerraform(struct?: AppsSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare function appsSpaceResourcesExperimentToHclTerraform(struct?: AppsSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSpaceResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#name AppsSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#space_id AppsSpace#space_id}
    */
    readonly spaceId: string;
}
export declare function appsSpaceResourcesGenieSpaceToTerraform(struct?: AppsSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare function appsSpaceResourcesGenieSpaceToHclTerraform(struct?: AppsSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface AppsSpaceResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#id AppsSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
}
export declare function appsSpaceResourcesJobToTerraform(struct?: AppsSpaceResourcesJob | cdktn.IResolvable): any;
export declare function appsSpaceResourcesJobToHclTerraform(struct?: AppsSpaceResourcesJob | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSpaceResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#key AppsSpace#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#scope AppsSpace#scope}
    */
    readonly scope: string;
}
export declare function appsSpaceResourcesSecretToTerraform(struct?: AppsSpaceResourcesSecret | cdktn.IResolvable): any;
export declare function appsSpaceResourcesSecretToHclTerraform(struct?: AppsSpaceResourcesSecret | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface AppsSpaceResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#name AppsSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
}
export declare function appsSpaceResourcesServingEndpointToTerraform(struct?: AppsSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function appsSpaceResourcesServingEndpointToHclTerraform(struct?: AppsSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSpaceResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#id AppsSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
}
export declare function appsSpaceResourcesSqlWarehouseToTerraform(struct?: AppsSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function appsSpaceResourcesSqlWarehouseToHclTerraform(struct?: AppsSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSpaceResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#permission AppsSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#securable_full_name AppsSpace#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#securable_type AppsSpace#securable_type}
    */
    readonly securableType: string;
}
export declare function appsSpaceResourcesUcSecurableToTerraform(struct?: AppsSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare function appsSpaceResourcesUcSecurableToHclTerraform(struct?: AppsSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface AppsSpaceResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#app AppsSpace#app}
    */
    readonly app?: AppsSpaceResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#database AppsSpace#database}
    */
    readonly database?: AppsSpaceResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#description AppsSpace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#experiment AppsSpace#experiment}
    */
    readonly experiment?: AppsSpaceResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#genie_space AppsSpace#genie_space}
    */
    readonly genieSpace?: AppsSpaceResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#job AppsSpace#job}
    */
    readonly job?: AppsSpaceResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#name AppsSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#secret AppsSpace#secret}
    */
    readonly secret?: AppsSpaceResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#serving_endpoint AppsSpace#serving_endpoint}
    */
    readonly servingEndpoint?: AppsSpaceResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#sql_warehouse AppsSpace#sql_warehouse}
    */
    readonly sqlWarehouse?: AppsSpaceResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#uc_securable AppsSpace#uc_securable}
    */
    readonly ucSecurable?: AppsSpaceResourcesUcSecurable;
}
export declare function appsSpaceResourcesToTerraform(struct?: AppsSpaceResources | cdktn.IResolvable): any;
export declare function appsSpaceResourcesToHclTerraform(struct?: AppsSpaceResources | cdktn.IResolvable): any;
export declare class AppsSpaceResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsSpaceResources | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSpaceResources | cdktn.IResolvable | undefined);
    private _app;
    get app(): AppsSpaceResourcesAppOutputReference;
    putApp(value: AppsSpaceResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | AppsSpaceResourcesApp | undefined;
    private _database;
    get database(): AppsSpaceResourcesDatabaseOutputReference;
    putDatabase(value: AppsSpaceResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | AppsSpaceResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): AppsSpaceResourcesExperimentOutputReference;
    putExperiment(value: AppsSpaceResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | AppsSpaceResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): AppsSpaceResourcesGenieSpaceOutputReference;
    putGenieSpace(value: AppsSpaceResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | AppsSpaceResourcesGenieSpace | undefined;
    private _job;
    get job(): AppsSpaceResourcesJobOutputReference;
    putJob(value: AppsSpaceResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | AppsSpaceResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secret;
    get secret(): AppsSpaceResourcesSecretOutputReference;
    putSecret(value: AppsSpaceResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | AppsSpaceResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): AppsSpaceResourcesServingEndpointOutputReference;
    putServingEndpoint(value: AppsSpaceResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | AppsSpaceResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): AppsSpaceResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: AppsSpaceResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | AppsSpaceResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): AppsSpaceResourcesUcSecurableOutputReference;
    putUcSecurable(value: AppsSpaceResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | AppsSpaceResourcesUcSecurable | undefined;
}
export declare class AppsSpaceResourcesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AppsSpaceResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsSpaceResourcesOutputReference;
}
export interface AppsSpaceStatus {
}
export declare function appsSpaceStatusToTerraform(struct?: AppsSpaceStatus): any;
export declare function appsSpaceStatusToHclTerraform(struct?: AppsSpaceStatus): any;
export declare class AppsSpaceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSpaceStatus | undefined;
    set internalValue(value: AppsSpaceStatus | undefined);
    get message(): string;
    get state(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space databricks_apps_space}
*/
export declare class AppsSpace extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_apps_space";
    /**
    * Generates CDKTN code for importing a AppsSpace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsSpace to import
    * @param importFromId The id of the existing AppsSpace that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsSpace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/apps_space databricks_apps_space} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsSpaceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AppsSpaceConfig);
    get createTime(): string;
    get creator(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    get id(): string;
    get name(): string;
    get oauth2AppClientId(): string;
    get oauth2AppIntegrationId(): string;
    private _providerConfig;
    get providerConfig(): AppsSpaceProviderConfigOutputReference;
    putProviderConfig(value: AppsSpaceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AppsSpaceProviderConfig | undefined;
    private _resources;
    get resources(): AppsSpaceResourcesList;
    putResources(value: AppsSpaceResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | AppsSpaceResources[] | undefined;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _status;
    get status(): AppsSpaceStatusOutputReference;
    get updateTime(): string;
    get updater(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    private _userApiScopes?;
    get userApiScopes(): string[];
    set userApiScopes(value: string[]);
    resetUserApiScopes(): void;
    get userApiScopesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
