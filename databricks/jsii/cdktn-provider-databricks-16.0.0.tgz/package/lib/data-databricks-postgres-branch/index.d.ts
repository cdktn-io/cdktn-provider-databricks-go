/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresBranchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#name DataDatabricksPostgresBranch#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#provider_config DataDatabricksPostgresBranch#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresBranchProviderConfig;
}
export interface DataDatabricksPostgresBranchProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#workspace_id DataDatabricksPostgresBranch#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksPostgresBranchProviderConfigToTerraform(struct?: DataDatabricksPostgresBranchProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresBranchProviderConfigToHclTerraform(struct?: DataDatabricksPostgresBranchProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresBranchProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresBranchProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresBranchProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresBranchSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#expire_time DataDatabricksPostgresBranch#expire_time}
    */
    readonly expireTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#is_protected DataDatabricksPostgresBranch#is_protected}
    */
    readonly isProtected?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#no_expiry DataDatabricksPostgresBranch#no_expiry}
    */
    readonly noExpiry?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#source_branch DataDatabricksPostgresBranch#source_branch}
    */
    readonly sourceBranch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#source_branch_lsn DataDatabricksPostgresBranch#source_branch_lsn}
    */
    readonly sourceBranchLsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#source_branch_time DataDatabricksPostgresBranch#source_branch_time}
    */
    readonly sourceBranchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#ttl DataDatabricksPostgresBranch#ttl}
    */
    readonly ttl?: string;
}
export declare function dataDatabricksPostgresBranchSpecToTerraform(struct?: DataDatabricksPostgresBranchSpec): any;
export declare function dataDatabricksPostgresBranchSpecToHclTerraform(struct?: DataDatabricksPostgresBranchSpec): any;
export declare class DataDatabricksPostgresBranchSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresBranchSpec | undefined;
    set internalValue(value: DataDatabricksPostgresBranchSpec | undefined);
    private _expireTime?;
    get expireTime(): string;
    set expireTime(value: string);
    resetExpireTime(): void;
    get expireTimeInput(): string | undefined;
    private _isProtected?;
    get isProtected(): boolean | cdktn.IResolvable;
    set isProtected(value: boolean | cdktn.IResolvable);
    resetIsProtected(): void;
    get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
    private _noExpiry?;
    get noExpiry(): boolean | cdktn.IResolvable;
    set noExpiry(value: boolean | cdktn.IResolvable);
    resetNoExpiry(): void;
    get noExpiryInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceBranch?;
    get sourceBranch(): string;
    set sourceBranch(value: string);
    resetSourceBranch(): void;
    get sourceBranchInput(): string | undefined;
    private _sourceBranchLsn?;
    get sourceBranchLsn(): string;
    set sourceBranchLsn(value: string);
    resetSourceBranchLsn(): void;
    get sourceBranchLsnInput(): string | undefined;
    private _sourceBranchTime?;
    get sourceBranchTime(): string;
    set sourceBranchTime(value: string);
    resetSourceBranchTime(): void;
    get sourceBranchTimeInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
}
export interface DataDatabricksPostgresBranchStatus {
}
export declare function dataDatabricksPostgresBranchStatusToTerraform(struct?: DataDatabricksPostgresBranchStatus): any;
export declare function dataDatabricksPostgresBranchStatusToHclTerraform(struct?: DataDatabricksPostgresBranchStatus): any;
export declare class DataDatabricksPostgresBranchStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresBranchStatus | undefined;
    set internalValue(value: DataDatabricksPostgresBranchStatus | undefined);
    get currentState(): string;
    get default(): cdktn.IResolvable;
    get expireTime(): string;
    get isProtected(): cdktn.IResolvable;
    get logicalSizeBytes(): number;
    get pendingState(): string;
    get sourceBranch(): string;
    get sourceBranchLsn(): string;
    get sourceBranchTime(): string;
    get stateChangeTime(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch databricks_postgres_branch}
*/
export declare class DataDatabricksPostgresBranch extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_branch";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresBranch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresBranch to import
    * @param importFromId The id of the existing DataDatabricksPostgresBranch that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresBranch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/postgres_branch databricks_postgres_branch} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresBranchConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresBranchConfig);
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresBranchProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresBranchProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresBranchProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresBranchSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresBranchStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
