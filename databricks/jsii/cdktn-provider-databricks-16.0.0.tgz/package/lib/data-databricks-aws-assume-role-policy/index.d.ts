/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAwsAssumeRolePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy#aws_partition DataDatabricksAwsAssumeRolePolicy#aws_partition}
    */
    readonly awsPartition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy#databricks_account_id DataDatabricksAwsAssumeRolePolicy#databricks_account_id}
    */
    readonly databricksAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy#external_id DataDatabricksAwsAssumeRolePolicy#external_id}
    */
    readonly externalId: string;
    /**
    * Grant AssumeRole to Databricks SaasUsageDeliveryRole instead of root account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy#for_log_delivery DataDatabricksAwsAssumeRolePolicy#for_log_delivery}
    */
    readonly forLogDelivery?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy#id DataDatabricksAwsAssumeRolePolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy databricks_aws_assume_role_policy}
*/
export declare class DataDatabricksAwsAssumeRolePolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_aws_assume_role_policy";
    /**
    * Generates CDKTN code for importing a DataDatabricksAwsAssumeRolePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAwsAssumeRolePolicy to import
    * @param importFromId The id of the existing DataDatabricksAwsAssumeRolePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAwsAssumeRolePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/aws_assume_role_policy databricks_aws_assume_role_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAwsAssumeRolePolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAwsAssumeRolePolicyConfig);
    private _awsPartition?;
    get awsPartition(): string;
    set awsPartition(value: string);
    resetAwsPartition(): void;
    get awsPartitionInput(): string | undefined;
    private _databricksAccountId?;
    get databricksAccountId(): string;
    set databricksAccountId(value: string);
    resetDatabricksAccountId(): void;
    get databricksAccountIdInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    get externalIdInput(): string | undefined;
    private _forLogDelivery?;
    get forLogDelivery(): boolean | cdktn.IResolvable;
    set forLogDelivery(value: boolean | cdktn.IResolvable);
    resetForLogDelivery(): void;
    get forLogDeliveryInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
