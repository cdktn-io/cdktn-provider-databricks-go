/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksNotebookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#format DataDatabricksNotebook#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#id DataDatabricksNotebook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#language DataDatabricksNotebook#language}
    */
    readonly language?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#object_id DataDatabricksNotebook#object_id}
    */
    readonly objectId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#object_type DataDatabricksNotebook#object_type}
    */
    readonly objectType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#path DataDatabricksNotebook#path}
    */
    readonly path: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#provider_config DataDatabricksNotebook#provider_config}
    */
    readonly providerConfig?: DataDatabricksNotebookProviderConfig;
}
export interface DataDatabricksNotebookProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#workspace_id DataDatabricksNotebook#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksNotebookProviderConfigToTerraform(struct?: DataDatabricksNotebookProviderConfigOutputReference | DataDatabricksNotebookProviderConfig): any;
export declare function dataDatabricksNotebookProviderConfigToHclTerraform(struct?: DataDatabricksNotebookProviderConfigOutputReference | DataDatabricksNotebookProviderConfig): any;
export declare class DataDatabricksNotebookProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksNotebookProviderConfig | undefined;
    set internalValue(value: DataDatabricksNotebookProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook databricks_notebook}
*/
export declare class DataDatabricksNotebook extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_notebook";
    /**
    * Generates CDKTN code for importing a DataDatabricksNotebook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksNotebook to import
    * @param importFromId The id of the existing DataDatabricksNotebook that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksNotebook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/notebook databricks_notebook} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksNotebookConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksNotebookConfig);
    get content(): string;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    resetLanguage(): void;
    get languageInput(): string | undefined;
    private _objectId?;
    get objectId(): number;
    set objectId(value: number);
    resetObjectId(): void;
    get objectIdInput(): number | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    resetObjectType(): void;
    get objectTypeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    get workspacePath(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksNotebookProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksNotebookProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksNotebookProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
