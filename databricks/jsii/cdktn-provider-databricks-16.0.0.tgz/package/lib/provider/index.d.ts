/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabricksProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#account_id DatabricksProvider#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#actions_id_token_request_token DatabricksProvider#actions_id_token_request_token}
    */
    readonly actionsIdTokenRequestToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#actions_id_token_request_url DatabricksProvider#actions_id_token_request_url}
    */
    readonly actionsIdTokenRequestUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#audience DatabricksProvider#audience}
    */
    readonly audience?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#auth_type DatabricksProvider#auth_type}
    */
    readonly authType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#azure_client_id DatabricksProvider#azure_client_id}
    */
    readonly azureClientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#azure_client_secret DatabricksProvider#azure_client_secret}
    */
    readonly azureClientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#azure_environment DatabricksProvider#azure_environment}
    */
    readonly azureEnvironment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#azure_login_app_id DatabricksProvider#azure_login_app_id}
    */
    readonly azureLoginAppId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#azure_tenant_id DatabricksProvider#azure_tenant_id}
    */
    readonly azureTenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#azure_use_msi DatabricksProvider#azure_use_msi}
    */
    readonly azureUseMsi?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#azure_workspace_resource_id DatabricksProvider#azure_workspace_resource_id}
    */
    readonly azureWorkspaceResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#client_id DatabricksProvider#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#client_secret DatabricksProvider#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#cluster_id DatabricksProvider#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#config_file DatabricksProvider#config_file}
    */
    readonly configFile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#databricks_cli_path DatabricksProvider#databricks_cli_path}
    */
    readonly databricksCliPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#databricks_id_token_filepath DatabricksProvider#databricks_id_token_filepath}
    */
    readonly databricksIdTokenFilepath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#debug_headers DatabricksProvider#debug_headers}
    */
    readonly debugHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#debug_truncate_bytes DatabricksProvider#debug_truncate_bytes}
    */
    readonly debugTruncateBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#disable_oauth_refresh_token DatabricksProvider#disable_oauth_refresh_token}
    */
    readonly disableOauthRefreshToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#experimental_is_unified_host DatabricksProvider#experimental_is_unified_host}
    */
    readonly experimentalIsUnifiedHost?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#google_credentials DatabricksProvider#google_credentials}
    */
    readonly googleCredentials?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#google_service_account DatabricksProvider#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#host DatabricksProvider#host}
    */
    readonly host?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#http_timeout_seconds DatabricksProvider#http_timeout_seconds}
    */
    readonly httpTimeoutSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#metadata_service_url DatabricksProvider#metadata_service_url}
    */
    readonly metadataServiceUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#oauth_callback_port DatabricksProvider#oauth_callback_port}
    */
    readonly oauthCallbackPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#oidc_token_env DatabricksProvider#oidc_token_env}
    */
    readonly oidcTokenEnv?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#password DatabricksProvider#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#profile DatabricksProvider#profile}
    */
    readonly profile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#rate_limit DatabricksProvider#rate_limit}
    */
    readonly rateLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#retry_timeout_seconds DatabricksProvider#retry_timeout_seconds}
    */
    readonly retryTimeoutSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#scopes DatabricksProvider#scopes}
    */
    readonly scopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#serverless_compute_id DatabricksProvider#serverless_compute_id}
    */
    readonly serverlessComputeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#skip_verify DatabricksProvider#skip_verify}
    */
    readonly skipVerify?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#token DatabricksProvider#token}
    */
    readonly token?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#username DatabricksProvider#username}
    */
    readonly username?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#warehouse_id DatabricksProvider#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#workspace_id DatabricksProvider#workspace_id}
    */
    readonly workspaceId?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#alias DatabricksProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs databricks}
*/
export declare class DatabricksProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "databricks";
    /**
    * Generates CDKTN code for importing a DatabricksProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabricksProvider to import
    * @param importFromId The id of the existing DatabricksProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabricksProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs databricks} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabricksProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DatabricksProviderConfig);
    private _accountId?;
    get accountId(): string | undefined;
    set accountId(value: string | undefined);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _actionsIdTokenRequestToken?;
    get actionsIdTokenRequestToken(): string | undefined;
    set actionsIdTokenRequestToken(value: string | undefined);
    resetActionsIdTokenRequestToken(): void;
    get actionsIdTokenRequestTokenInput(): string | undefined;
    private _actionsIdTokenRequestUrl?;
    get actionsIdTokenRequestUrl(): string | undefined;
    set actionsIdTokenRequestUrl(value: string | undefined);
    resetActionsIdTokenRequestUrl(): void;
    get actionsIdTokenRequestUrlInput(): string | undefined;
    private _audience?;
    get audience(): string | undefined;
    set audience(value: string | undefined);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _authType?;
    get authType(): string | undefined;
    set authType(value: string | undefined);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _azureClientId?;
    get azureClientId(): string | undefined;
    set azureClientId(value: string | undefined);
    resetAzureClientId(): void;
    get azureClientIdInput(): string | undefined;
    private _azureClientSecret?;
    get azureClientSecret(): string | undefined;
    set azureClientSecret(value: string | undefined);
    resetAzureClientSecret(): void;
    get azureClientSecretInput(): string | undefined;
    private _azureEnvironment?;
    get azureEnvironment(): string | undefined;
    set azureEnvironment(value: string | undefined);
    resetAzureEnvironment(): void;
    get azureEnvironmentInput(): string | undefined;
    private _azureLoginAppId?;
    get azureLoginAppId(): string | undefined;
    set azureLoginAppId(value: string | undefined);
    resetAzureLoginAppId(): void;
    get azureLoginAppIdInput(): string | undefined;
    private _azureTenantId?;
    get azureTenantId(): string | undefined;
    set azureTenantId(value: string | undefined);
    resetAzureTenantId(): void;
    get azureTenantIdInput(): string | undefined;
    private _azureUseMsi?;
    get azureUseMsi(): boolean | cdktn.IResolvable | undefined;
    set azureUseMsi(value: boolean | cdktn.IResolvable | undefined);
    resetAzureUseMsi(): void;
    get azureUseMsiInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspaceResourceId?;
    get azureWorkspaceResourceId(): string | undefined;
    set azureWorkspaceResourceId(value: string | undefined);
    resetAzureWorkspaceResourceId(): void;
    get azureWorkspaceResourceIdInput(): string | undefined;
    private _clientId?;
    get clientId(): string | undefined;
    set clientId(value: string | undefined);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string | undefined;
    set clientSecret(value: string | undefined);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string | undefined;
    set clusterId(value: string | undefined);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _configFile?;
    get configFile(): string | undefined;
    set configFile(value: string | undefined);
    resetConfigFile(): void;
    get configFileInput(): string | undefined;
    private _databricksCliPath?;
    get databricksCliPath(): string | undefined;
    set databricksCliPath(value: string | undefined);
    resetDatabricksCliPath(): void;
    get databricksCliPathInput(): string | undefined;
    private _databricksIdTokenFilepath?;
    get databricksIdTokenFilepath(): string | undefined;
    set databricksIdTokenFilepath(value: string | undefined);
    resetDatabricksIdTokenFilepath(): void;
    get databricksIdTokenFilepathInput(): string | undefined;
    private _debugHeaders?;
    get debugHeaders(): boolean | cdktn.IResolvable | undefined;
    set debugHeaders(value: boolean | cdktn.IResolvable | undefined);
    resetDebugHeaders(): void;
    get debugHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _debugTruncateBytes?;
    get debugTruncateBytes(): number | undefined;
    set debugTruncateBytes(value: number | undefined);
    resetDebugTruncateBytes(): void;
    get debugTruncateBytesInput(): number | undefined;
    private _disableOauthRefreshToken?;
    get disableOauthRefreshToken(): boolean | cdktn.IResolvable | undefined;
    set disableOauthRefreshToken(value: boolean | cdktn.IResolvable | undefined);
    resetDisableOauthRefreshToken(): void;
    get disableOauthRefreshTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _experimentalIsUnifiedHost?;
    get experimentalIsUnifiedHost(): boolean | cdktn.IResolvable | undefined;
    set experimentalIsUnifiedHost(value: boolean | cdktn.IResolvable | undefined);
    resetExperimentalIsUnifiedHost(): void;
    get experimentalIsUnifiedHostInput(): boolean | cdktn.IResolvable | undefined;
    private _googleCredentials?;
    get googleCredentials(): string | undefined;
    set googleCredentials(value: string | undefined);
    resetGoogleCredentials(): void;
    get googleCredentialsInput(): string | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string | undefined;
    set googleServiceAccount(value: string | undefined);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _host?;
    get host(): string | undefined;
    set host(value: string | undefined);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _httpTimeoutSeconds?;
    get httpTimeoutSeconds(): number | undefined;
    set httpTimeoutSeconds(value: number | undefined);
    resetHttpTimeoutSeconds(): void;
    get httpTimeoutSecondsInput(): number | undefined;
    private _metadataServiceUrl?;
    get metadataServiceUrl(): string | undefined;
    set metadataServiceUrl(value: string | undefined);
    resetMetadataServiceUrl(): void;
    get metadataServiceUrlInput(): string | undefined;
    private _oauthCallbackPort?;
    get oauthCallbackPort(): number | undefined;
    set oauthCallbackPort(value: number | undefined);
    resetOauthCallbackPort(): void;
    get oauthCallbackPortInput(): number | undefined;
    private _oidcTokenEnv?;
    get oidcTokenEnv(): string | undefined;
    set oidcTokenEnv(value: string | undefined);
    resetOidcTokenEnv(): void;
    get oidcTokenEnvInput(): string | undefined;
    private _password?;
    get password(): string | undefined;
    set password(value: string | undefined);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _profile?;
    get profile(): string | undefined;
    set profile(value: string | undefined);
    resetProfile(): void;
    get profileInput(): string | undefined;
    private _rateLimit?;
    get rateLimit(): number | undefined;
    set rateLimit(value: number | undefined);
    resetRateLimit(): void;
    get rateLimitInput(): number | undefined;
    private _retryTimeoutSeconds?;
    get retryTimeoutSeconds(): number | undefined;
    set retryTimeoutSeconds(value: number | undefined);
    resetRetryTimeoutSeconds(): void;
    get retryTimeoutSecondsInput(): number | undefined;
    private _scopes?;
    get scopes(): string[] | undefined;
    set scopes(value: string[] | undefined);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _serverlessComputeId?;
    get serverlessComputeId(): string | undefined;
    set serverlessComputeId(value: string | undefined);
    resetServerlessComputeId(): void;
    get serverlessComputeIdInput(): string | undefined;
    private _skipVerify?;
    get skipVerify(): boolean | cdktn.IResolvable | undefined;
    set skipVerify(value: boolean | cdktn.IResolvable | undefined);
    resetSkipVerify(): void;
    get skipVerifyInput(): boolean | cdktn.IResolvable | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _username?;
    get username(): string | undefined;
    set username(value: string | undefined);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string | undefined;
    set warehouseId(value: string | undefined);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string | undefined;
    set workspaceId(value: string | undefined);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
