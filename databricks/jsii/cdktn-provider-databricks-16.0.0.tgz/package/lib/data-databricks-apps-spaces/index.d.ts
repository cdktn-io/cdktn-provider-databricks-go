/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppsSpacesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#page_size DataDatabricksAppsSpaces#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#provider_config DataDatabricksAppsSpaces#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppsSpacesProviderConfig;
}
export interface DataDatabricksAppsSpacesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#workspace_id DataDatabricksAppsSpaces#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksAppsSpacesProviderConfigToTerraform(struct?: DataDatabricksAppsSpacesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesProviderConfigToHclTerraform(struct?: DataDatabricksAppsSpacesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#workspace_id DataDatabricksAppsSpaces#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksAppsSpacesSpacesProviderConfigToTerraform(struct?: DataDatabricksAppsSpacesSpacesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesProviderConfigToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesApp {
}
export declare function dataDatabricksAppsSpacesSpacesResourcesAppToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesApp | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesAppToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesApp | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesApp | cdktn.IResolvable | undefined);
}
export interface DataDatabricksAppsSpacesSpacesResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#database_name DataDatabricksAppsSpaces#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#instance_name DataDatabricksAppsSpaces#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesDatabaseToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesDatabase | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesDatabaseToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesDatabase | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#experiment_id DataDatabricksAppsSpaces#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesExperimentToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesExperiment | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesExperimentToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesExperiment | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#name DataDatabricksAppsSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#space_id DataDatabricksAppsSpaces#space_id}
    */
    readonly spaceId: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesGenieSpaceToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesGenieSpace | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesGenieSpaceToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesGenieSpace | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#id DataDatabricksAppsSpaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesJobToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesJob | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesJobToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesJob | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#key DataDatabricksAppsSpaces#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#scope DataDatabricksAppsSpaces#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesSecretToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesSecretToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#name DataDatabricksAppsSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesServingEndpointToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesServingEndpointToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#id DataDatabricksAppsSpaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesSqlWarehouseToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesSqlWarehouseToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#permission DataDatabricksAppsSpaces#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#securable_full_name DataDatabricksAppsSpaces#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#securable_type DataDatabricksAppsSpaces#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesUcSecurableToTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesUcSecurable | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesUcSecurableToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResourcesUcSecurable | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppsSpacesSpacesResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#app DataDatabricksAppsSpaces#app}
    */
    readonly app?: DataDatabricksAppsSpacesSpacesResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#database DataDatabricksAppsSpaces#database}
    */
    readonly database?: DataDatabricksAppsSpacesSpacesResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#description DataDatabricksAppsSpaces#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#experiment DataDatabricksAppsSpaces#experiment}
    */
    readonly experiment?: DataDatabricksAppsSpacesSpacesResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#genie_space DataDatabricksAppsSpaces#genie_space}
    */
    readonly genieSpace?: DataDatabricksAppsSpacesSpacesResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#job DataDatabricksAppsSpaces#job}
    */
    readonly job?: DataDatabricksAppsSpacesSpacesResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#name DataDatabricksAppsSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#secret DataDatabricksAppsSpaces#secret}
    */
    readonly secret?: DataDatabricksAppsSpacesSpacesResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#serving_endpoint DataDatabricksAppsSpaces#serving_endpoint}
    */
    readonly servingEndpoint?: DataDatabricksAppsSpacesSpacesResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#sql_warehouse DataDatabricksAppsSpaces#sql_warehouse}
    */
    readonly sqlWarehouse?: DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#uc_securable DataDatabricksAppsSpaces#uc_securable}
    */
    readonly ucSecurable?: DataDatabricksAppsSpacesSpacesResourcesUcSecurable;
}
export declare function dataDatabricksAppsSpacesSpacesResourcesToTerraform(struct?: DataDatabricksAppsSpacesSpacesResources): any;
export declare function dataDatabricksAppsSpacesSpacesResourcesToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesResources): any;
export declare class DataDatabricksAppsSpacesSpacesResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsSpacesSpacesResources | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesResources | undefined);
    private _app;
    get app(): DataDatabricksAppsSpacesSpacesResourcesAppOutputReference;
    putApp(value: DataDatabricksAppsSpacesSpacesResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesApp | undefined;
    private _database;
    get database(): DataDatabricksAppsSpacesSpacesResourcesDatabaseOutputReference;
    putDatabase(value: DataDatabricksAppsSpacesSpacesResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): DataDatabricksAppsSpacesSpacesResourcesExperimentOutputReference;
    putExperiment(value: DataDatabricksAppsSpacesSpacesResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): DataDatabricksAppsSpacesSpacesResourcesGenieSpaceOutputReference;
    putGenieSpace(value: DataDatabricksAppsSpacesSpacesResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesGenieSpace | undefined;
    private _job;
    get job(): DataDatabricksAppsSpacesSpacesResourcesJobOutputReference;
    putJob(value: DataDatabricksAppsSpacesSpacesResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secret;
    get secret(): DataDatabricksAppsSpacesSpacesResourcesSecretOutputReference;
    putSecret(value: DataDatabricksAppsSpacesSpacesResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): DataDatabricksAppsSpacesSpacesResourcesServingEndpointOutputReference;
    putServingEndpoint(value: DataDatabricksAppsSpacesSpacesResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): DataDatabricksAppsSpacesSpacesResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): DataDatabricksAppsSpacesSpacesResourcesUcSecurableOutputReference;
    putUcSecurable(value: DataDatabricksAppsSpacesSpacesResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesResourcesUcSecurable | undefined;
}
export declare class DataDatabricksAppsSpacesSpacesResourcesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksAppsSpacesSpacesResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsSpacesSpacesResourcesOutputReference;
}
export interface DataDatabricksAppsSpacesSpacesStatus {
}
export declare function dataDatabricksAppsSpacesSpacesStatusToTerraform(struct?: DataDatabricksAppsSpacesSpacesStatus): any;
export declare function dataDatabricksAppsSpacesSpacesStatusToHclTerraform(struct?: DataDatabricksAppsSpacesSpacesStatus): any;
export declare class DataDatabricksAppsSpacesSpacesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSpacesSpacesStatus | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpacesStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppsSpacesSpaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#name DataDatabricksAppsSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#provider_config DataDatabricksAppsSpaces#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppsSpacesSpacesProviderConfig;
}
export declare function dataDatabricksAppsSpacesSpacesToTerraform(struct?: DataDatabricksAppsSpacesSpaces): any;
export declare function dataDatabricksAppsSpacesSpacesToHclTerraform(struct?: DataDatabricksAppsSpacesSpaces): any;
export declare class DataDatabricksAppsSpacesSpacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsSpacesSpaces | undefined;
    set internalValue(value: DataDatabricksAppsSpacesSpaces | undefined);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oauth2AppClientId(): string;
    get oauth2AppIntegrationId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppsSpacesSpacesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppsSpacesSpacesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppsSpacesSpacesProviderConfig | undefined;
    private _resources;
    get resources(): DataDatabricksAppsSpacesSpacesResourcesList;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _status;
    get status(): DataDatabricksAppsSpacesSpacesStatusOutputReference;
    get updateTime(): string;
    get updater(): string;
    get usagePolicyId(): string;
    get userApiScopes(): string[];
}
export declare class DataDatabricksAppsSpacesSpacesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksAppsSpacesSpaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsSpacesSpacesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces databricks_apps_spaces}
*/
export declare class DataDatabricksAppsSpaces extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_apps_spaces";
    /**
    * Generates CDKTN code for importing a DataDatabricksAppsSpaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAppsSpaces to import
    * @param importFromId The id of the existing DataDatabricksAppsSpaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAppsSpaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/apps_spaces databricks_apps_spaces} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppsSpacesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAppsSpacesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppsSpacesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppsSpacesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppsSpacesProviderConfig | undefined;
    private _spaces;
    get spaces(): DataDatabricksAppsSpacesSpacesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
