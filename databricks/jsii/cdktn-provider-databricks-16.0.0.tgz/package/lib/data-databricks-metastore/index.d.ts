/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMetastoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#id DataDatabricksMetastore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#metastore_id DataDatabricksMetastore#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#name DataDatabricksMetastore#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#region DataDatabricksMetastore#region}
    */
    readonly region?: string;
    /**
    * metastore_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#metastore_info DataDatabricksMetastore#metastore_info}
    */
    readonly metastoreInfo?: DataDatabricksMetastoreMetastoreInfo;
}
export interface DataDatabricksMetastoreMetastoreInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#cloud DataDatabricksMetastore#cloud}
    */
    readonly cloud?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#created_at DataDatabricksMetastore#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#created_by DataDatabricksMetastore#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#default_data_access_config_id DataDatabricksMetastore#default_data_access_config_id}
    */
    readonly defaultDataAccessConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#delta_sharing_organization_name DataDatabricksMetastore#delta_sharing_organization_name}
    */
    readonly deltaSharingOrganizationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#delta_sharing_recipient_token_lifetime_in_seconds DataDatabricksMetastore#delta_sharing_recipient_token_lifetime_in_seconds}
    */
    readonly deltaSharingRecipientTokenLifetimeInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#delta_sharing_scope DataDatabricksMetastore#delta_sharing_scope}
    */
    readonly deltaSharingScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#external_access_enabled DataDatabricksMetastore#external_access_enabled}
    */
    readonly externalAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#global_metastore_id DataDatabricksMetastore#global_metastore_id}
    */
    readonly globalMetastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#metastore_id DataDatabricksMetastore#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#name DataDatabricksMetastore#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#owner DataDatabricksMetastore#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#privilege_model_version DataDatabricksMetastore#privilege_model_version}
    */
    readonly privilegeModelVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#region DataDatabricksMetastore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#storage_root DataDatabricksMetastore#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#storage_root_credential_id DataDatabricksMetastore#storage_root_credential_id}
    */
    readonly storageRootCredentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#storage_root_credential_name DataDatabricksMetastore#storage_root_credential_name}
    */
    readonly storageRootCredentialName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#updated_at DataDatabricksMetastore#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#updated_by DataDatabricksMetastore#updated_by}
    */
    readonly updatedBy?: string;
}
export declare function dataDatabricksMetastoreMetastoreInfoToTerraform(struct?: DataDatabricksMetastoreMetastoreInfoOutputReference | DataDatabricksMetastoreMetastoreInfo): any;
export declare function dataDatabricksMetastoreMetastoreInfoToHclTerraform(struct?: DataDatabricksMetastoreMetastoreInfoOutputReference | DataDatabricksMetastoreMetastoreInfo): any;
export declare class DataDatabricksMetastoreMetastoreInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMetastoreMetastoreInfo | undefined;
    set internalValue(value: DataDatabricksMetastoreMetastoreInfo | undefined);
    private _cloud?;
    get cloud(): string;
    set cloud(value: string);
    resetCloud(): void;
    get cloudInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _defaultDataAccessConfigId?;
    get defaultDataAccessConfigId(): string;
    set defaultDataAccessConfigId(value: string);
    resetDefaultDataAccessConfigId(): void;
    get defaultDataAccessConfigIdInput(): string | undefined;
    private _deltaSharingOrganizationName?;
    get deltaSharingOrganizationName(): string;
    set deltaSharingOrganizationName(value: string);
    resetDeltaSharingOrganizationName(): void;
    get deltaSharingOrganizationNameInput(): string | undefined;
    private _deltaSharingRecipientTokenLifetimeInSeconds?;
    get deltaSharingRecipientTokenLifetimeInSeconds(): number;
    set deltaSharingRecipientTokenLifetimeInSeconds(value: number);
    resetDeltaSharingRecipientTokenLifetimeInSeconds(): void;
    get deltaSharingRecipientTokenLifetimeInSecondsInput(): number | undefined;
    private _deltaSharingScope?;
    get deltaSharingScope(): string;
    set deltaSharingScope(value: string);
    resetDeltaSharingScope(): void;
    get deltaSharingScopeInput(): string | undefined;
    private _externalAccessEnabled?;
    get externalAccessEnabled(): boolean | cdktn.IResolvable;
    set externalAccessEnabled(value: boolean | cdktn.IResolvable);
    resetExternalAccessEnabled(): void;
    get externalAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _globalMetastoreId?;
    get globalMetastoreId(): string;
    set globalMetastoreId(value: string);
    resetGlobalMetastoreId(): void;
    get globalMetastoreIdInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _privilegeModelVersion?;
    get privilegeModelVersion(): string;
    set privilegeModelVersion(value: string);
    resetPrivilegeModelVersion(): void;
    get privilegeModelVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    private _storageRootCredentialId?;
    get storageRootCredentialId(): string;
    set storageRootCredentialId(value: string);
    resetStorageRootCredentialId(): void;
    get storageRootCredentialIdInput(): string | undefined;
    private _storageRootCredentialName?;
    get storageRootCredentialName(): string;
    set storageRootCredentialName(value: string);
    resetStorageRootCredentialName(): void;
    get storageRootCredentialNameInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore databricks_metastore}
*/
export declare class DataDatabricksMetastore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_metastore";
    /**
    * Generates CDKTN code for importing a DataDatabricksMetastore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMetastore to import
    * @param importFromId The id of the existing DataDatabricksMetastore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMetastore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/metastore databricks_metastore} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMetastoreConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksMetastoreConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _metastoreInfo;
    get metastoreInfo(): DataDatabricksMetastoreMetastoreInfoOutputReference;
    putMetastoreInfo(value: DataDatabricksMetastoreMetastoreInfo): void;
    resetMetastoreInfo(): void;
    get metastoreInfoInput(): DataDatabricksMetastoreMetastoreInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
