/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksQualityMonitorsV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#page_size DataDatabricksQualityMonitorsV2#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#provider_config DataDatabricksQualityMonitorsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksQualityMonitorsV2ProviderConfig;
}
export interface DataDatabricksQualityMonitorsV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#workspace_id DataDatabricksQualityMonitorsV2#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksQualityMonitorsV2ProviderConfigToTerraform(struct?: DataDatabricksQualityMonitorsV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorsV2ProviderConfigToHclTerraform(struct?: DataDatabricksQualityMonitorsV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorsV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorsV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#excluded_table_full_names DataDatabricksQualityMonitorsV2#excluded_table_full_names}
    */
    readonly excludedTableFullNames?: string[];
}
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfigToTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfig): any;
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfigToHclTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfig): any;
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfig | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfig | undefined);
    private _excludedTableFullNames?;
    get excludedTableFullNames(): string[];
    set excludedTableFullNames(value: string[]);
    resetExcludedTableFullNames(): void;
    get excludedTableFullNamesInput(): string[] | undefined;
    get lastRunId(): string;
    get latestRunStatus(): string;
}
export interface DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#workspace_id DataDatabricksQualityMonitorsV2#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsProviderConfigToTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsProviderConfigToHclTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#column_names DataDatabricksQualityMonitorsV2#column_names}
    */
    readonly columnNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#upper_bound DataDatabricksQualityMonitorsV2#upper_bound}
    */
    readonly upperBound?: number;
}
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheckToTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheckToHclTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
    private _upperBound?;
    get upperBound(): number;
    set upperBound(value: number);
    resetUpperBound(): void;
    get upperBoundInput(): number | undefined;
}
export interface DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#column_names DataDatabricksQualityMonitorsV2#column_names}
    */
    readonly columnNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#lower_bound DataDatabricksQualityMonitorsV2#lower_bound}
    */
    readonly lowerBound?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#upper_bound DataDatabricksQualityMonitorsV2#upper_bound}
    */
    readonly upperBound?: number;
}
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheckToTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheckToHclTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
    private _lowerBound?;
    get lowerBound(): number;
    set lowerBound(value: number);
    resetLowerBound(): void;
    get lowerBoundInput(): number | undefined;
    private _upperBound?;
    get upperBound(): number;
    set upperBound(value: number);
    resetUpperBound(): void;
    get upperBoundInput(): number | undefined;
}
export interface DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#column_names DataDatabricksQualityMonitorsV2#column_names}
    */
    readonly columnNames?: string[];
}
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheckToTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheckToHclTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
}
export interface DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#name DataDatabricksQualityMonitorsV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#percent_null_validity_check DataDatabricksQualityMonitorsV2#percent_null_validity_check}
    */
    readonly percentNullValidityCheck?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#range_validity_check DataDatabricksQualityMonitorsV2#range_validity_check}
    */
    readonly rangeValidityCheck?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#uniqueness_validity_check DataDatabricksQualityMonitorsV2#uniqueness_validity_check}
    */
    readonly uniquenessValidityCheck?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck;
}
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsToTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurations): any;
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsToHclTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurations): any;
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurations | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurations | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _percentNullValidityCheck;
    get percentNullValidityCheck(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheckOutputReference;
    putPercentNullValidityCheck(value: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck): void;
    resetPercentNullValidityCheck(): void;
    get percentNullValidityCheckInput(): cdktn.IResolvable | DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsPercentNullValidityCheck | undefined;
    private _rangeValidityCheck;
    get rangeValidityCheck(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheckOutputReference;
    putRangeValidityCheck(value: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck): void;
    resetRangeValidityCheck(): void;
    get rangeValidityCheckInput(): cdktn.IResolvable | DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsRangeValidityCheck | undefined;
    private _uniquenessValidityCheck;
    get uniquenessValidityCheck(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheckOutputReference;
    putUniquenessValidityCheck(value: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck): void;
    resetUniquenessValidityCheck(): void;
    get uniquenessValidityCheckInput(): cdktn.IResolvable | DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsUniquenessValidityCheck | undefined;
}
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsOutputReference;
}
export interface DataDatabricksQualityMonitorsV2QualityMonitors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#object_id DataDatabricksQualityMonitorsV2#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#object_type DataDatabricksQualityMonitorsV2#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#provider_config DataDatabricksQualityMonitorsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig;
}
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsToTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitors): any;
export declare function dataDatabricksQualityMonitorsV2QualityMonitorsToHclTerraform(struct?: DataDatabricksQualityMonitorsV2QualityMonitors): any;
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksQualityMonitorsV2QualityMonitors | undefined;
    set internalValue(value: DataDatabricksQualityMonitorsV2QualityMonitors | undefined);
    private _anomalyDetectionConfig;
    get anomalyDetectionConfig(): DataDatabricksQualityMonitorsV2QualityMonitorsAnomalyDetectionConfigOutputReference;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksQualityMonitorsV2QualityMonitorsProviderConfig | undefined;
    private _validityCheckConfigurations;
    get validityCheckConfigurations(): DataDatabricksQualityMonitorsV2QualityMonitorsValidityCheckConfigurationsList;
}
export declare class DataDatabricksQualityMonitorsV2QualityMonitorsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksQualityMonitorsV2QualityMonitors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksQualityMonitorsV2QualityMonitorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2 databricks_quality_monitors_v2}
*/
export declare class DataDatabricksQualityMonitorsV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_quality_monitors_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksQualityMonitorsV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksQualityMonitorsV2 to import
    * @param importFromId The id of the existing DataDatabricksQualityMonitorsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksQualityMonitorsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/quality_monitors_v2 databricks_quality_monitors_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksQualityMonitorsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksQualityMonitorsV2Config);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksQualityMonitorsV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksQualityMonitorsV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksQualityMonitorsV2ProviderConfig | undefined;
    private _qualityMonitors;
    get qualityMonitors(): DataDatabricksQualityMonitorsV2QualityMonitorsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
