/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountFederationPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#page_size DataDatabricksAccountFederationPolicies#page_size}
    */
    readonly pageSize?: number;
}
export interface DataDatabricksAccountFederationPoliciesPoliciesOidcPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#audiences DataDatabricksAccountFederationPolicies#audiences}
    */
    readonly audiences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#issuer DataDatabricksAccountFederationPolicies#issuer}
    */
    readonly issuer?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#jwks_json DataDatabricksAccountFederationPolicies#jwks_json}
    */
    readonly jwksJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#jwks_uri DataDatabricksAccountFederationPolicies#jwks_uri}
    */
    readonly jwksUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#subject DataDatabricksAccountFederationPolicies#subject}
    */
    readonly subject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#subject_claim DataDatabricksAccountFederationPolicies#subject_claim}
    */
    readonly subjectClaim?: string;
}
export declare function dataDatabricksAccountFederationPoliciesPoliciesOidcPolicyToTerraform(struct?: DataDatabricksAccountFederationPoliciesPoliciesOidcPolicy): any;
export declare function dataDatabricksAccountFederationPoliciesPoliciesOidcPolicyToHclTerraform(struct?: DataDatabricksAccountFederationPoliciesPoliciesOidcPolicy): any;
export declare class DataDatabricksAccountFederationPoliciesPoliciesOidcPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountFederationPoliciesPoliciesOidcPolicy | undefined;
    set internalValue(value: DataDatabricksAccountFederationPoliciesPoliciesOidcPolicy | undefined);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    resetAudiences(): void;
    get audiencesInput(): string[] | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
    private _jwksJson?;
    get jwksJson(): string;
    set jwksJson(value: string);
    resetJwksJson(): void;
    get jwksJsonInput(): string | undefined;
    private _jwksUri?;
    get jwksUri(): string;
    set jwksUri(value: string);
    resetJwksUri(): void;
    get jwksUriInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
    private _subjectClaim?;
    get subjectClaim(): string;
    set subjectClaim(value: string);
    resetSubjectClaim(): void;
    get subjectClaimInput(): string | undefined;
}
export interface DataDatabricksAccountFederationPoliciesPolicies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#policy_id DataDatabricksAccountFederationPolicies#policy_id}
    */
    readonly policyId: string;
}
export declare function dataDatabricksAccountFederationPoliciesPoliciesToTerraform(struct?: DataDatabricksAccountFederationPoliciesPolicies): any;
export declare function dataDatabricksAccountFederationPoliciesPoliciesToHclTerraform(struct?: DataDatabricksAccountFederationPoliciesPolicies): any;
export declare class DataDatabricksAccountFederationPoliciesPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountFederationPoliciesPolicies | undefined;
    set internalValue(value: DataDatabricksAccountFederationPoliciesPolicies | undefined);
    get createTime(): string;
    get description(): string;
    get name(): string;
    private _oidcPolicy;
    get oidcPolicy(): DataDatabricksAccountFederationPoliciesPoliciesOidcPolicyOutputReference;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    get servicePrincipalId(): number;
    get uid(): string;
    get updateTime(): string;
}
export declare class DataDatabricksAccountFederationPoliciesPoliciesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksAccountFederationPoliciesPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountFederationPoliciesPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies databricks_account_federation_policies}
*/
export declare class DataDatabricksAccountFederationPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_federation_policies";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountFederationPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountFederationPolicies to import
    * @param importFromId The id of the existing DataDatabricksAccountFederationPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountFederationPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/data-sources/account_federation_policies databricks_account_federation_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountFederationPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAccountFederationPoliciesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _policies;
    get policies(): DataDatabricksAccountFederationPoliciesPoliciesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
