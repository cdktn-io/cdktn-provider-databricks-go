/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ModelServingProvisionedThroughputConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#budget_policy_id ModelServingProvisionedThroughput#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#id ModelServingProvisionedThroughput#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#name ModelServingProvisionedThroughput#name}
    */
    readonly name: string;
    /**
    * ai_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#ai_gateway ModelServingProvisionedThroughput#ai_gateway}
    */
    readonly aiGateway?: ModelServingProvisionedThroughputAiGateway;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#config ModelServingProvisionedThroughput#config}
    */
    readonly config: ModelServingProvisionedThroughputConfigA;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#email_notifications ModelServingProvisionedThroughput#email_notifications}
    */
    readonly emailNotifications?: ModelServingProvisionedThroughputEmailNotifications;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#provider_config ModelServingProvisionedThroughput#provider_config}
    */
    readonly providerConfig?: ModelServingProvisionedThroughputProviderConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#tags ModelServingProvisionedThroughput#tags}
    */
    readonly tags?: ModelServingProvisionedThroughputTags[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#timeouts ModelServingProvisionedThroughput#timeouts}
    */
    readonly timeouts?: ModelServingProvisionedThroughputTimeouts;
}
export interface ModelServingProvisionedThroughputAiGatewayFallbackConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#enabled ModelServingProvisionedThroughput#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function modelServingProvisionedThroughputAiGatewayFallbackConfigToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayFallbackConfigOutputReference | ModelServingProvisionedThroughputAiGatewayFallbackConfig): any;
export declare function modelServingProvisionedThroughputAiGatewayFallbackConfigToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayFallbackConfigOutputReference | ModelServingProvisionedThroughputAiGatewayFallbackConfig): any;
export declare class ModelServingProvisionedThroughputAiGatewayFallbackConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayFallbackConfig | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayFallbackConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#behavior ModelServingProvisionedThroughput#behavior}
    */
    readonly behavior?: string;
}
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsInputPiiToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsInputPiiOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii): any;
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsInputPiiToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsInputPiiOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii): any;
export declare class ModelServingProvisionedThroughputAiGatewayGuardrailsInputPiiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
}
export interface ModelServingProvisionedThroughputAiGatewayGuardrailsInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#invalid_keywords ModelServingProvisionedThroughput#invalid_keywords}
    */
    readonly invalidKeywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#safety ModelServingProvisionedThroughput#safety}
    */
    readonly safety?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#valid_topics ModelServingProvisionedThroughput#valid_topics}
    */
    readonly validTopics?: string[];
    /**
    * pii block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#pii ModelServingProvisionedThroughput#pii}
    */
    readonly pii?: ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii;
}
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsInputToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsInputOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsInput): any;
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsInputToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsInputOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsInput): any;
export declare class ModelServingProvisionedThroughputAiGatewayGuardrailsInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayGuardrailsInput | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayGuardrailsInput | undefined);
    private _invalidKeywords?;
    get invalidKeywords(): string[];
    set invalidKeywords(value: string[]);
    resetInvalidKeywords(): void;
    get invalidKeywordsInput(): string[] | undefined;
    private _safety?;
    get safety(): boolean | cdktn.IResolvable;
    set safety(value: boolean | cdktn.IResolvable);
    resetSafety(): void;
    get safetyInput(): boolean | cdktn.IResolvable | undefined;
    private _validTopics?;
    get validTopics(): string[];
    set validTopics(value: string[]);
    resetValidTopics(): void;
    get validTopicsInput(): string[] | undefined;
    private _pii;
    get pii(): ModelServingProvisionedThroughputAiGatewayGuardrailsInputPiiOutputReference;
    putPii(value: ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii): void;
    resetPii(): void;
    get piiInput(): ModelServingProvisionedThroughputAiGatewayGuardrailsInputPii | undefined;
}
export interface ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#behavior ModelServingProvisionedThroughput#behavior}
    */
    readonly behavior?: string;
}
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsOutputPiiToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPiiOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii): any;
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsOutputPiiToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPiiOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii): any;
export declare class ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPiiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
}
export interface ModelServingProvisionedThroughputAiGatewayGuardrailsOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#invalid_keywords ModelServingProvisionedThroughput#invalid_keywords}
    */
    readonly invalidKeywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#safety ModelServingProvisionedThroughput#safety}
    */
    readonly safety?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#valid_topics ModelServingProvisionedThroughput#valid_topics}
    */
    readonly validTopics?: string[];
    /**
    * pii block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#pii ModelServingProvisionedThroughput#pii}
    */
    readonly pii?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii;
}
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsOutputToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsOutput): any;
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsOutputToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrailsOutput): any;
export declare class ModelServingProvisionedThroughputAiGatewayGuardrailsOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayGuardrailsOutput | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayGuardrailsOutput | undefined);
    private _invalidKeywords?;
    get invalidKeywords(): string[];
    set invalidKeywords(value: string[]);
    resetInvalidKeywords(): void;
    get invalidKeywordsInput(): string[] | undefined;
    private _safety?;
    get safety(): boolean | cdktn.IResolvable;
    set safety(value: boolean | cdktn.IResolvable);
    resetSafety(): void;
    get safetyInput(): boolean | cdktn.IResolvable | undefined;
    private _validTopics?;
    get validTopics(): string[];
    set validTopics(value: string[]);
    resetValidTopics(): void;
    get validTopicsInput(): string[] | undefined;
    private _pii;
    get pii(): ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPiiOutputReference;
    putPii(value: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii): void;
    resetPii(): void;
    get piiInput(): ModelServingProvisionedThroughputAiGatewayGuardrailsOutputPii | undefined;
}
export interface ModelServingProvisionedThroughputAiGatewayGuardrails {
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#input ModelServingProvisionedThroughput#input}
    */
    readonly input?: ModelServingProvisionedThroughputAiGatewayGuardrailsInput;
    /**
    * output block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#output ModelServingProvisionedThroughput#output}
    */
    readonly output?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutput;
}
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrails): any;
export declare function modelServingProvisionedThroughputAiGatewayGuardrailsToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayGuardrailsOutputReference | ModelServingProvisionedThroughputAiGatewayGuardrails): any;
export declare class ModelServingProvisionedThroughputAiGatewayGuardrailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayGuardrails | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayGuardrails | undefined);
    private _input;
    get input(): ModelServingProvisionedThroughputAiGatewayGuardrailsInputOutputReference;
    putInput(value: ModelServingProvisionedThroughputAiGatewayGuardrailsInput): void;
    resetInput(): void;
    get inputInput(): ModelServingProvisionedThroughputAiGatewayGuardrailsInput | undefined;
    private _output;
    get output(): ModelServingProvisionedThroughputAiGatewayGuardrailsOutputOutputReference;
    putOutput(value: ModelServingProvisionedThroughputAiGatewayGuardrailsOutput): void;
    resetOutput(): void;
    get outputInput(): ModelServingProvisionedThroughputAiGatewayGuardrailsOutput | undefined;
}
export interface ModelServingProvisionedThroughputAiGatewayInferenceTableConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#catalog_name ModelServingProvisionedThroughput#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#enabled ModelServingProvisionedThroughput#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#schema_name ModelServingProvisionedThroughput#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#table_name_prefix ModelServingProvisionedThroughput#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function modelServingProvisionedThroughputAiGatewayInferenceTableConfigToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayInferenceTableConfigOutputReference | ModelServingProvisionedThroughputAiGatewayInferenceTableConfig): any;
export declare function modelServingProvisionedThroughputAiGatewayInferenceTableConfigToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayInferenceTableConfigOutputReference | ModelServingProvisionedThroughputAiGatewayInferenceTableConfig): any;
export declare class ModelServingProvisionedThroughputAiGatewayInferenceTableConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayInferenceTableConfig | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayInferenceTableConfig | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface ModelServingProvisionedThroughputAiGatewayRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#calls ModelServingProvisionedThroughput#calls}
    */
    readonly calls?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#key ModelServingProvisionedThroughput#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#principal ModelServingProvisionedThroughput#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#renewal_period ModelServingProvisionedThroughput#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#tokens ModelServingProvisionedThroughput#tokens}
    */
    readonly tokens?: number;
}
export declare function modelServingProvisionedThroughputAiGatewayRateLimitsToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayRateLimits | cdktn.IResolvable): any;
export declare function modelServingProvisionedThroughputAiGatewayRateLimitsToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayRateLimits | cdktn.IResolvable): any;
export declare class ModelServingProvisionedThroughputAiGatewayRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayRateLimits | cdktn.IResolvable | undefined);
    private _calls?;
    get calls(): number;
    set calls(value: number);
    resetCalls(): void;
    get callsInput(): number | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class ModelServingProvisionedThroughputAiGatewayRateLimitsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ModelServingProvisionedThroughputAiGatewayRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingProvisionedThroughputAiGatewayRateLimitsOutputReference;
}
export interface ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#enabled ModelServingProvisionedThroughput#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function modelServingProvisionedThroughputAiGatewayUsageTrackingConfigToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayUsageTrackingConfigOutputReference | ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig): any;
export declare function modelServingProvisionedThroughputAiGatewayUsageTrackingConfigToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayUsageTrackingConfigOutputReference | ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig): any;
export declare class ModelServingProvisionedThroughputAiGatewayUsageTrackingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ModelServingProvisionedThroughputAiGateway {
    /**
    * fallback_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#fallback_config ModelServingProvisionedThroughput#fallback_config}
    */
    readonly fallbackConfig?: ModelServingProvisionedThroughputAiGatewayFallbackConfig;
    /**
    * guardrails block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#guardrails ModelServingProvisionedThroughput#guardrails}
    */
    readonly guardrails?: ModelServingProvisionedThroughputAiGatewayGuardrails;
    /**
    * inference_table_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#inference_table_config ModelServingProvisionedThroughput#inference_table_config}
    */
    readonly inferenceTableConfig?: ModelServingProvisionedThroughputAiGatewayInferenceTableConfig;
    /**
    * rate_limits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#rate_limits ModelServingProvisionedThroughput#rate_limits}
    */
    readonly rateLimits?: ModelServingProvisionedThroughputAiGatewayRateLimits[] | cdktn.IResolvable;
    /**
    * usage_tracking_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#usage_tracking_config ModelServingProvisionedThroughput#usage_tracking_config}
    */
    readonly usageTrackingConfig?: ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig;
}
export declare function modelServingProvisionedThroughputAiGatewayToTerraform(struct?: ModelServingProvisionedThroughputAiGatewayOutputReference | ModelServingProvisionedThroughputAiGateway): any;
export declare function modelServingProvisionedThroughputAiGatewayToHclTerraform(struct?: ModelServingProvisionedThroughputAiGatewayOutputReference | ModelServingProvisionedThroughputAiGateway): any;
export declare class ModelServingProvisionedThroughputAiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputAiGateway | undefined;
    set internalValue(value: ModelServingProvisionedThroughputAiGateway | undefined);
    private _fallbackConfig;
    get fallbackConfig(): ModelServingProvisionedThroughputAiGatewayFallbackConfigOutputReference;
    putFallbackConfig(value: ModelServingProvisionedThroughputAiGatewayFallbackConfig): void;
    resetFallbackConfig(): void;
    get fallbackConfigInput(): ModelServingProvisionedThroughputAiGatewayFallbackConfig | undefined;
    private _guardrails;
    get guardrails(): ModelServingProvisionedThroughputAiGatewayGuardrailsOutputReference;
    putGuardrails(value: ModelServingProvisionedThroughputAiGatewayGuardrails): void;
    resetGuardrails(): void;
    get guardrailsInput(): ModelServingProvisionedThroughputAiGatewayGuardrails | undefined;
    private _inferenceTableConfig;
    get inferenceTableConfig(): ModelServingProvisionedThroughputAiGatewayInferenceTableConfigOutputReference;
    putInferenceTableConfig(value: ModelServingProvisionedThroughputAiGatewayInferenceTableConfig): void;
    resetInferenceTableConfig(): void;
    get inferenceTableConfigInput(): ModelServingProvisionedThroughputAiGatewayInferenceTableConfig | undefined;
    private _rateLimits;
    get rateLimits(): ModelServingProvisionedThroughputAiGatewayRateLimitsList;
    putRateLimits(value: ModelServingProvisionedThroughputAiGatewayRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | ModelServingProvisionedThroughputAiGatewayRateLimits[] | undefined;
    private _usageTrackingConfig;
    get usageTrackingConfig(): ModelServingProvisionedThroughputAiGatewayUsageTrackingConfigOutputReference;
    putUsageTrackingConfig(value: ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig): void;
    resetUsageTrackingConfig(): void;
    get usageTrackingConfigInput(): ModelServingProvisionedThroughputAiGatewayUsageTrackingConfig | undefined;
}
export interface ModelServingProvisionedThroughputConfigServedEntities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#burst_scaling_enabled ModelServingProvisionedThroughput#burst_scaling_enabled}
    */
    readonly burstScalingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#entity_name ModelServingProvisionedThroughput#entity_name}
    */
    readonly entityName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#entity_version ModelServingProvisionedThroughput#entity_version}
    */
    readonly entityVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#name ModelServingProvisionedThroughput#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#provisioned_model_units ModelServingProvisionedThroughput#provisioned_model_units}
    */
    readonly provisionedModelUnits: number;
}
export declare function modelServingProvisionedThroughputConfigServedEntitiesToTerraform(struct?: ModelServingProvisionedThroughputConfigServedEntities | cdktn.IResolvable): any;
export declare function modelServingProvisionedThroughputConfigServedEntitiesToHclTerraform(struct?: ModelServingProvisionedThroughputConfigServedEntities | cdktn.IResolvable): any;
export declare class ModelServingProvisionedThroughputConfigServedEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingProvisionedThroughputConfigServedEntities | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingProvisionedThroughputConfigServedEntities | cdktn.IResolvable | undefined);
    private _burstScalingEnabled?;
    get burstScalingEnabled(): boolean | cdktn.IResolvable;
    set burstScalingEnabled(value: boolean | cdktn.IResolvable);
    resetBurstScalingEnabled(): void;
    get burstScalingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    get entityNameInput(): string | undefined;
    private _entityVersion?;
    get entityVersion(): string;
    set entityVersion(value: string);
    get entityVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _provisionedModelUnits?;
    get provisionedModelUnits(): number;
    set provisionedModelUnits(value: number);
    get provisionedModelUnitsInput(): number | undefined;
}
export declare class ModelServingProvisionedThroughputConfigServedEntitiesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ModelServingProvisionedThroughputConfigServedEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingProvisionedThroughputConfigServedEntitiesOutputReference;
}
export interface ModelServingProvisionedThroughputConfigTrafficConfigRoutes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#served_entity_name ModelServingProvisionedThroughput#served_entity_name}
    */
    readonly servedEntityName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#served_model_name ModelServingProvisionedThroughput#served_model_name}
    */
    readonly servedModelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#traffic_percentage ModelServingProvisionedThroughput#traffic_percentage}
    */
    readonly trafficPercentage: number;
}
export declare function modelServingProvisionedThroughputConfigTrafficConfigRoutesToTerraform(struct?: ModelServingProvisionedThroughputConfigTrafficConfigRoutes | cdktn.IResolvable): any;
export declare function modelServingProvisionedThroughputConfigTrafficConfigRoutesToHclTerraform(struct?: ModelServingProvisionedThroughputConfigTrafficConfigRoutes | cdktn.IResolvable): any;
export declare class ModelServingProvisionedThroughputConfigTrafficConfigRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingProvisionedThroughputConfigTrafficConfigRoutes | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingProvisionedThroughputConfigTrafficConfigRoutes | cdktn.IResolvable | undefined);
    private _servedEntityName?;
    get servedEntityName(): string;
    set servedEntityName(value: string);
    resetServedEntityName(): void;
    get servedEntityNameInput(): string | undefined;
    private _servedModelName?;
    get servedModelName(): string;
    set servedModelName(value: string);
    resetServedModelName(): void;
    get servedModelNameInput(): string | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    get trafficPercentageInput(): number | undefined;
}
export declare class ModelServingProvisionedThroughputConfigTrafficConfigRoutesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ModelServingProvisionedThroughputConfigTrafficConfigRoutes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingProvisionedThroughputConfigTrafficConfigRoutesOutputReference;
}
export interface ModelServingProvisionedThroughputConfigTrafficConfig {
    /**
    * routes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#routes ModelServingProvisionedThroughput#routes}
    */
    readonly routes?: ModelServingProvisionedThroughputConfigTrafficConfigRoutes[] | cdktn.IResolvable;
}
export declare function modelServingProvisionedThroughputConfigTrafficConfigToTerraform(struct?: ModelServingProvisionedThroughputConfigTrafficConfigOutputReference | ModelServingProvisionedThroughputConfigTrafficConfig): any;
export declare function modelServingProvisionedThroughputConfigTrafficConfigToHclTerraform(struct?: ModelServingProvisionedThroughputConfigTrafficConfigOutputReference | ModelServingProvisionedThroughputConfigTrafficConfig): any;
export declare class ModelServingProvisionedThroughputConfigTrafficConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputConfigTrafficConfig | undefined;
    set internalValue(value: ModelServingProvisionedThroughputConfigTrafficConfig | undefined);
    private _routes;
    get routes(): ModelServingProvisionedThroughputConfigTrafficConfigRoutesList;
    putRoutes(value: ModelServingProvisionedThroughputConfigTrafficConfigRoutes[] | cdktn.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktn.IResolvable | ModelServingProvisionedThroughputConfigTrafficConfigRoutes[] | undefined;
}
export interface ModelServingProvisionedThroughputConfigA {
    /**
    * served_entities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#served_entities ModelServingProvisionedThroughput#served_entities}
    */
    readonly servedEntities?: ModelServingProvisionedThroughputConfigServedEntities[] | cdktn.IResolvable;
    /**
    * traffic_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#traffic_config ModelServingProvisionedThroughput#traffic_config}
    */
    readonly trafficConfig?: ModelServingProvisionedThroughputConfigTrafficConfig;
}
export declare function modelServingProvisionedThroughputConfigAToTerraform(struct?: ModelServingProvisionedThroughputConfigAOutputReference | ModelServingProvisionedThroughputConfigA): any;
export declare function modelServingProvisionedThroughputConfigAToHclTerraform(struct?: ModelServingProvisionedThroughputConfigAOutputReference | ModelServingProvisionedThroughputConfigA): any;
export declare class ModelServingProvisionedThroughputConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputConfigA | undefined;
    set internalValue(value: ModelServingProvisionedThroughputConfigA | undefined);
    private _servedEntities;
    get servedEntities(): ModelServingProvisionedThroughputConfigServedEntitiesList;
    putServedEntities(value: ModelServingProvisionedThroughputConfigServedEntities[] | cdktn.IResolvable): void;
    resetServedEntities(): void;
    get servedEntitiesInput(): cdktn.IResolvable | ModelServingProvisionedThroughputConfigServedEntities[] | undefined;
    private _trafficConfig;
    get trafficConfig(): ModelServingProvisionedThroughputConfigTrafficConfigOutputReference;
    putTrafficConfig(value: ModelServingProvisionedThroughputConfigTrafficConfig): void;
    resetTrafficConfig(): void;
    get trafficConfigInput(): ModelServingProvisionedThroughputConfigTrafficConfig | undefined;
}
export interface ModelServingProvisionedThroughputEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#on_update_failure ModelServingProvisionedThroughput#on_update_failure}
    */
    readonly onUpdateFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#on_update_success ModelServingProvisionedThroughput#on_update_success}
    */
    readonly onUpdateSuccess?: string[];
}
export declare function modelServingProvisionedThroughputEmailNotificationsToTerraform(struct?: ModelServingProvisionedThroughputEmailNotificationsOutputReference | ModelServingProvisionedThroughputEmailNotifications): any;
export declare function modelServingProvisionedThroughputEmailNotificationsToHclTerraform(struct?: ModelServingProvisionedThroughputEmailNotificationsOutputReference | ModelServingProvisionedThroughputEmailNotifications): any;
export declare class ModelServingProvisionedThroughputEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputEmailNotifications | undefined;
    set internalValue(value: ModelServingProvisionedThroughputEmailNotifications | undefined);
    private _onUpdateFailure?;
    get onUpdateFailure(): string[];
    set onUpdateFailure(value: string[]);
    resetOnUpdateFailure(): void;
    get onUpdateFailureInput(): string[] | undefined;
    private _onUpdateSuccess?;
    get onUpdateSuccess(): string[];
    set onUpdateSuccess(value: string[]);
    resetOnUpdateSuccess(): void;
    get onUpdateSuccessInput(): string[] | undefined;
}
export interface ModelServingProvisionedThroughputProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#workspace_id ModelServingProvisionedThroughput#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function modelServingProvisionedThroughputProviderConfigToTerraform(struct?: ModelServingProvisionedThroughputProviderConfigOutputReference | ModelServingProvisionedThroughputProviderConfig): any;
export declare function modelServingProvisionedThroughputProviderConfigToHclTerraform(struct?: ModelServingProvisionedThroughputProviderConfigOutputReference | ModelServingProvisionedThroughputProviderConfig): any;
export declare class ModelServingProvisionedThroughputProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputProviderConfig | undefined;
    set internalValue(value: ModelServingProvisionedThroughputProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface ModelServingProvisionedThroughputTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#key ModelServingProvisionedThroughput#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#value ModelServingProvisionedThroughput#value}
    */
    readonly value?: string;
}
export declare function modelServingProvisionedThroughputTagsToTerraform(struct?: ModelServingProvisionedThroughputTags | cdktn.IResolvable): any;
export declare function modelServingProvisionedThroughputTagsToHclTerraform(struct?: ModelServingProvisionedThroughputTags | cdktn.IResolvable): any;
export declare class ModelServingProvisionedThroughputTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingProvisionedThroughputTags | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingProvisionedThroughputTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ModelServingProvisionedThroughputTagsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ModelServingProvisionedThroughputTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingProvisionedThroughputTagsOutputReference;
}
export interface ModelServingProvisionedThroughputTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#create ModelServingProvisionedThroughput#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#update ModelServingProvisionedThroughput#update}
    */
    readonly update?: string;
}
export declare function modelServingProvisionedThroughputTimeoutsToTerraform(struct?: ModelServingProvisionedThroughputTimeouts | cdktn.IResolvable): any;
export declare function modelServingProvisionedThroughputTimeoutsToHclTerraform(struct?: ModelServingProvisionedThroughputTimeouts | cdktn.IResolvable): any;
export declare class ModelServingProvisionedThroughputTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProvisionedThroughputTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingProvisionedThroughputTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput databricks_model_serving_provisioned_throughput}
*/
export declare class ModelServingProvisionedThroughput extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_model_serving_provisioned_throughput";
    /**
    * Generates CDKTN code for importing a ModelServingProvisionedThroughput resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ModelServingProvisionedThroughput to import
    * @param importFromId The id of the existing ModelServingProvisionedThroughput that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ModelServingProvisionedThroughput to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.110.0/docs/resources/model_serving_provisioned_throughput databricks_model_serving_provisioned_throughput} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ModelServingProvisionedThroughputConfig
    */
    constructor(scope: Construct, id: string, config: ModelServingProvisionedThroughputConfig);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get servingEndpointId(): string;
    private _aiGateway;
    get aiGateway(): ModelServingProvisionedThroughputAiGatewayOutputReference;
    putAiGateway(value: ModelServingProvisionedThroughputAiGateway): void;
    resetAiGateway(): void;
    get aiGatewayInput(): ModelServingProvisionedThroughputAiGateway | undefined;
    private _config;
    get config(): ModelServingProvisionedThroughputConfigAOutputReference;
    putConfig(value: ModelServingProvisionedThroughputConfigA): void;
    get configInput(): ModelServingProvisionedThroughputConfigA | undefined;
    private _emailNotifications;
    get emailNotifications(): ModelServingProvisionedThroughputEmailNotificationsOutputReference;
    putEmailNotifications(value: ModelServingProvisionedThroughputEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): ModelServingProvisionedThroughputEmailNotifications | undefined;
    private _providerConfig;
    get providerConfig(): ModelServingProvisionedThroughputProviderConfigOutputReference;
    putProviderConfig(value: ModelServingProvisionedThroughputProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ModelServingProvisionedThroughputProviderConfig | undefined;
    private _tags;
    get tags(): ModelServingProvisionedThroughputTagsList;
    putTags(value: ModelServingProvisionedThroughputTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ModelServingProvisionedThroughputTags[] | undefined;
    private _timeouts;
    get timeouts(): ModelServingProvisionedThroughputTimeoutsOutputReference;
    putTimeouts(value: ModelServingProvisionedThroughputTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ModelServingProvisionedThroughputTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
