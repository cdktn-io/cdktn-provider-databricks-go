/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface PipelineClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#max_workers Pipeline#max_workers}
    */
    readonly maxWorkers: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#min_workers Pipeline#min_workers}
    */
    readonly minWorkers: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#mode Pipeline#mode}
    */
    readonly mode?: string;
}
export declare function pipelineClusterAutoscaleToTerraform(struct?: PipelineClusterAutoscaleOutputReference | PipelineClusterAutoscale): any;
export declare function pipelineClusterAutoscaleToHclTerraform(struct?: PipelineClusterAutoscaleOutputReference | PipelineClusterAutoscale): any;
export declare class PipelineClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterAutoscale | undefined;
    set internalValue(value: PipelineClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    get minWorkersInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface PipelineClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#availability Pipeline#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ebs_volume_count Pipeline#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ebs_volume_iops Pipeline#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ebs_volume_size Pipeline#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ebs_volume_throughput Pipeline#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ebs_volume_type Pipeline#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#first_on_demand Pipeline#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#instance_profile_arn Pipeline#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#spot_bid_price_percent Pipeline#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#zone_id Pipeline#zone_id}
    */
    readonly zoneId?: string;
}
export declare function pipelineClusterAwsAttributesToTerraform(struct?: PipelineClusterAwsAttributesOutputReference | PipelineClusterAwsAttributes): any;
export declare function pipelineClusterAwsAttributesToHclTerraform(struct?: PipelineClusterAwsAttributesOutputReference | PipelineClusterAwsAttributes): any;
export declare class PipelineClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterAwsAttributes | undefined;
    set internalValue(value: PipelineClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface PipelineClusterAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#log_analytics_primary_key Pipeline#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#log_analytics_workspace_id Pipeline#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function pipelineClusterAzureAttributesLogAnalyticsInfoToTerraform(struct?: PipelineClusterAzureAttributesLogAnalyticsInfoOutputReference | PipelineClusterAzureAttributesLogAnalyticsInfo): any;
export declare function pipelineClusterAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: PipelineClusterAzureAttributesLogAnalyticsInfoOutputReference | PipelineClusterAzureAttributesLogAnalyticsInfo): any;
export declare class PipelineClusterAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: PipelineClusterAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface PipelineClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#availability Pipeline#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#capacity_reservation_group Pipeline#capacity_reservation_group}
    */
    readonly capacityReservationGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#first_on_demand Pipeline#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#spot_bid_max_price Pipeline#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#log_analytics_info Pipeline#log_analytics_info}
    */
    readonly logAnalyticsInfo?: PipelineClusterAzureAttributesLogAnalyticsInfo;
}
export declare function pipelineClusterAzureAttributesToTerraform(struct?: PipelineClusterAzureAttributesOutputReference | PipelineClusterAzureAttributes): any;
export declare function pipelineClusterAzureAttributesToHclTerraform(struct?: PipelineClusterAzureAttributesOutputReference | PipelineClusterAzureAttributes): any;
export declare class PipelineClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterAzureAttributes | undefined;
    set internalValue(value: PipelineClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _capacityReservationGroup?;
    get capacityReservationGroup(): string;
    set capacityReservationGroup(value: string);
    resetCapacityReservationGroup(): void;
    get capacityReservationGroupInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): PipelineClusterAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: PipelineClusterAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): PipelineClusterAzureAttributesLogAnalyticsInfo | undefined;
}
export interface PipelineClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterClusterLogConfDbfsToTerraform(struct?: PipelineClusterClusterLogConfDbfsOutputReference | PipelineClusterClusterLogConfDbfs): any;
export declare function pipelineClusterClusterLogConfDbfsToHclTerraform(struct?: PipelineClusterClusterLogConfDbfsOutputReference | PipelineClusterClusterLogConfDbfs): any;
export declare class PipelineClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterClusterLogConfDbfs | undefined;
    set internalValue(value: PipelineClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#canned_acl Pipeline#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enable_encryption Pipeline#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#encryption_type Pipeline#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#endpoint Pipeline#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#kms_key Pipeline#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#region Pipeline#region}
    */
    readonly region?: string;
}
export declare function pipelineClusterClusterLogConfS3ToTerraform(struct?: PipelineClusterClusterLogConfS3OutputReference | PipelineClusterClusterLogConfS3): any;
export declare function pipelineClusterClusterLogConfS3ToHclTerraform(struct?: PipelineClusterClusterLogConfS3OutputReference | PipelineClusterClusterLogConfS3): any;
export declare class PipelineClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterClusterLogConfS3 | undefined;
    set internalValue(value: PipelineClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface PipelineClusterClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterClusterLogConfVolumesToTerraform(struct?: PipelineClusterClusterLogConfVolumesOutputReference | PipelineClusterClusterLogConfVolumes): any;
export declare function pipelineClusterClusterLogConfVolumesToHclTerraform(struct?: PipelineClusterClusterLogConfVolumesOutputReference | PipelineClusterClusterLogConfVolumes): any;
export declare class PipelineClusterClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterClusterLogConfVolumes | undefined;
    set internalValue(value: PipelineClusterClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#dbfs Pipeline#dbfs}
    */
    readonly dbfs?: PipelineClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#s3 Pipeline#s3}
    */
    readonly s3?: PipelineClusterClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#volumes Pipeline#volumes}
    */
    readonly volumes?: PipelineClusterClusterLogConfVolumes;
}
export declare function pipelineClusterClusterLogConfToTerraform(struct?: PipelineClusterClusterLogConfOutputReference | PipelineClusterClusterLogConf): any;
export declare function pipelineClusterClusterLogConfToHclTerraform(struct?: PipelineClusterClusterLogConfOutputReference | PipelineClusterClusterLogConf): any;
export declare class PipelineClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterClusterLogConf | undefined;
    set internalValue(value: PipelineClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): PipelineClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: PipelineClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): PipelineClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): PipelineClusterClusterLogConfS3OutputReference;
    putS3(value: PipelineClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): PipelineClusterClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): PipelineClusterClusterLogConfVolumesOutputReference;
    putVolumes(value: PipelineClusterClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): PipelineClusterClusterLogConfVolumes | undefined;
}
export interface PipelineClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#availability Pipeline#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confidential_compute_type Pipeline#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#first_on_demand Pipeline#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#google_service_account Pipeline#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#local_ssd_count Pipeline#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#zone_id Pipeline#zone_id}
    */
    readonly zoneId?: string;
}
export declare function pipelineClusterGcpAttributesToTerraform(struct?: PipelineClusterGcpAttributesOutputReference | PipelineClusterGcpAttributes): any;
export declare function pipelineClusterGcpAttributesToHclTerraform(struct?: PipelineClusterGcpAttributesOutputReference | PipelineClusterGcpAttributes): any;
export declare class PipelineClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterGcpAttributes | undefined;
    set internalValue(value: PipelineClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface PipelineClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterInitScriptsAbfssToTerraform(struct?: PipelineClusterInitScriptsAbfssOutputReference | PipelineClusterInitScriptsAbfss): any;
export declare function pipelineClusterInitScriptsAbfssToHclTerraform(struct?: PipelineClusterInitScriptsAbfssOutputReference | PipelineClusterInitScriptsAbfss): any;
export declare class PipelineClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterInitScriptsAbfss | undefined;
    set internalValue(value: PipelineClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterInitScriptsDbfsToTerraform(struct?: PipelineClusterInitScriptsDbfsOutputReference | PipelineClusterInitScriptsDbfs): any;
export declare function pipelineClusterInitScriptsDbfsToHclTerraform(struct?: PipelineClusterInitScriptsDbfsOutputReference | PipelineClusterInitScriptsDbfs): any;
export declare class PipelineClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterInitScriptsDbfs | undefined;
    set internalValue(value: PipelineClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterInitScriptsFileToTerraform(struct?: PipelineClusterInitScriptsFileOutputReference | PipelineClusterInitScriptsFile): any;
export declare function pipelineClusterInitScriptsFileToHclTerraform(struct?: PipelineClusterInitScriptsFileOutputReference | PipelineClusterInitScriptsFile): any;
export declare class PipelineClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterInitScriptsFile | undefined;
    set internalValue(value: PipelineClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterInitScriptsGcsToTerraform(struct?: PipelineClusterInitScriptsGcsOutputReference | PipelineClusterInitScriptsGcs): any;
export declare function pipelineClusterInitScriptsGcsToHclTerraform(struct?: PipelineClusterInitScriptsGcsOutputReference | PipelineClusterInitScriptsGcs): any;
export declare class PipelineClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterInitScriptsGcs | undefined;
    set internalValue(value: PipelineClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#canned_acl Pipeline#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enable_encryption Pipeline#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#encryption_type Pipeline#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#endpoint Pipeline#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#kms_key Pipeline#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#region Pipeline#region}
    */
    readonly region?: string;
}
export declare function pipelineClusterInitScriptsS3ToTerraform(struct?: PipelineClusterInitScriptsS3OutputReference | PipelineClusterInitScriptsS3): any;
export declare function pipelineClusterInitScriptsS3ToHclTerraform(struct?: PipelineClusterInitScriptsS3OutputReference | PipelineClusterInitScriptsS3): any;
export declare class PipelineClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterInitScriptsS3 | undefined;
    set internalValue(value: PipelineClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface PipelineClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterInitScriptsVolumesToTerraform(struct?: PipelineClusterInitScriptsVolumesOutputReference | PipelineClusterInitScriptsVolumes): any;
export declare function pipelineClusterInitScriptsVolumesToHclTerraform(struct?: PipelineClusterInitScriptsVolumesOutputReference | PipelineClusterInitScriptsVolumes): any;
export declare class PipelineClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterInitScriptsVolumes | undefined;
    set internalValue(value: PipelineClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination Pipeline#destination}
    */
    readonly destination: string;
}
export declare function pipelineClusterInitScriptsWorkspaceToTerraform(struct?: PipelineClusterInitScriptsWorkspaceOutputReference | PipelineClusterInitScriptsWorkspace): any;
export declare function pipelineClusterInitScriptsWorkspaceToHclTerraform(struct?: PipelineClusterInitScriptsWorkspaceOutputReference | PipelineClusterInitScriptsWorkspace): any;
export declare class PipelineClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineClusterInitScriptsWorkspace | undefined;
    set internalValue(value: PipelineClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface PipelineClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#abfss Pipeline#abfss}
    */
    readonly abfss?: PipelineClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#dbfs Pipeline#dbfs}
    */
    readonly dbfs?: PipelineClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file Pipeline#file}
    */
    readonly file?: PipelineClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#gcs Pipeline#gcs}
    */
    readonly gcs?: PipelineClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#s3 Pipeline#s3}
    */
    readonly s3?: PipelineClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#volumes Pipeline#volumes}
    */
    readonly volumes?: PipelineClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#workspace Pipeline#workspace}
    */
    readonly workspace?: PipelineClusterInitScriptsWorkspace;
}
export declare function pipelineClusterInitScriptsToTerraform(struct?: PipelineClusterInitScripts | cdktn.IResolvable): any;
export declare function pipelineClusterInitScriptsToHclTerraform(struct?: PipelineClusterInitScripts | cdktn.IResolvable): any;
export declare class PipelineClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): PipelineClusterInitScriptsAbfssOutputReference;
    putAbfss(value: PipelineClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): PipelineClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): PipelineClusterInitScriptsDbfsOutputReference;
    putDbfs(value: PipelineClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): PipelineClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): PipelineClusterInitScriptsFileOutputReference;
    putFile(value: PipelineClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): PipelineClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): PipelineClusterInitScriptsGcsOutputReference;
    putGcs(value: PipelineClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): PipelineClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): PipelineClusterInitScriptsS3OutputReference;
    putS3(value: PipelineClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): PipelineClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): PipelineClusterInitScriptsVolumesOutputReference;
    putVolumes(value: PipelineClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): PipelineClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): PipelineClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: PipelineClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): PipelineClusterInitScriptsWorkspace | undefined;
}
export declare class PipelineClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: PipelineClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineClusterInitScriptsOutputReference;
}
export interface PipelineCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#apply_policy_default_values Pipeline#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_tags Pipeline#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#driver_instance_pool_id Pipeline#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#driver_node_type_id Pipeline#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enable_local_disk_encryption Pipeline#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#instance_pool_id Pipeline#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#label Pipeline#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#node_type_id Pipeline#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#num_workers Pipeline#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#policy_id Pipeline#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#spark_conf Pipeline#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#spark_env_vars Pipeline#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ssh_public_keys Pipeline#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#autoscale Pipeline#autoscale}
    */
    readonly autoscale?: PipelineClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#aws_attributes Pipeline#aws_attributes}
    */
    readonly awsAttributes?: PipelineClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#azure_attributes Pipeline#azure_attributes}
    */
    readonly azureAttributes?: PipelineClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#cluster_log_conf Pipeline#cluster_log_conf}
    */
    readonly clusterLogConf?: PipelineClusterClusterLogConf;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#gcp_attributes Pipeline#gcp_attributes}
    */
    readonly gcpAttributes?: PipelineClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#init_scripts Pipeline#init_scripts}
    */
    readonly initScripts?: PipelineClusterInitScripts[] | cdktn.IResolvable;
}
export declare function pipelineClusterToTerraform(struct?: PipelineCluster | cdktn.IResolvable): any;
export declare function pipelineClusterToHclTerraform(struct?: PipelineCluster | cdktn.IResolvable): any;
export declare class PipelineClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineCluster | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineCluster | cdktn.IResolvable | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _autoscale;
    get autoscale(): PipelineClusterAutoscaleOutputReference;
    putAutoscale(value: PipelineClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): PipelineClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): PipelineClusterAwsAttributesOutputReference;
    putAwsAttributes(value: PipelineClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): PipelineClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): PipelineClusterAzureAttributesOutputReference;
    putAzureAttributes(value: PipelineClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): PipelineClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): PipelineClusterClusterLogConfOutputReference;
    putClusterLogConf(value: PipelineClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): PipelineClusterClusterLogConf | undefined;
    private _gcpAttributes;
    get gcpAttributes(): PipelineClusterGcpAttributesOutputReference;
    putGcpAttributes(value: PipelineClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): PipelineClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): PipelineClusterInitScriptsList;
    putInitScripts(value: PipelineClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | PipelineClusterInitScripts[] | undefined;
}
export declare class PipelineClusterList extends cdktn.ComplexList {
    internalValue?: PipelineCluster[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineClusterOutputReference;
}
export interface PipelineDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#deployment_id Pipeline#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#kind Pipeline#kind}
    */
    readonly kind: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metadata_file_path Pipeline#metadata_file_path}
    */
    readonly metadataFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#version_id Pipeline#version_id}
    */
    readonly versionId?: string;
}
export declare function pipelineDeploymentToTerraform(struct?: PipelineDeploymentOutputReference | PipelineDeployment): any;
export declare function pipelineDeploymentToHclTerraform(struct?: PipelineDeploymentOutputReference | PipelineDeployment): any;
export declare class PipelineDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineDeployment | undefined;
    set internalValue(value: PipelineDeployment | undefined);
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _metadataFilePath?;
    get metadataFilePath(): string;
    set metadataFilePath(value: string);
    resetMetadataFilePath(): void;
    get metadataFilePathInput(): string | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
}
export interface PipelineEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#dependencies Pipeline#dependencies}
    */
    readonly dependencies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#environment_version Pipeline#environment_version}
    */
    readonly environmentVersion?: string;
}
export declare function pipelineEnvironmentToTerraform(struct?: PipelineEnvironmentOutputReference | PipelineEnvironment): any;
export declare function pipelineEnvironmentToHclTerraform(struct?: PipelineEnvironmentOutputReference | PipelineEnvironment): any;
export declare class PipelineEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineEnvironment | undefined;
    set internalValue(value: PipelineEnvironment | undefined);
    private _dependencies?;
    get dependencies(): string[];
    set dependencies(value: string[]);
    resetDependencies(): void;
    get dependenciesInput(): string[] | undefined;
    private _environmentVersion?;
    get environmentVersion(): string;
    set environmentVersion(value: string);
    resetEnvironmentVersion(): void;
    get environmentVersionInput(): string | undefined;
}
export interface PipelineEventLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#catalog Pipeline#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#name Pipeline#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
}
export declare function pipelineEventLogToTerraform(struct?: PipelineEventLogOutputReference | PipelineEventLog): any;
export declare function pipelineEventLogToHclTerraform(struct?: PipelineEventLogOutputReference | PipelineEventLog): any;
export declare class PipelineEventLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineEventLog | undefined;
    set internalValue(value: PipelineEventLog | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface PipelineFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#exclude Pipeline#exclude}
    */
    readonly exclude?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include Pipeline#include}
    */
    readonly include?: string[];
}
export declare function pipelineFiltersToTerraform(struct?: PipelineFiltersOutputReference | PipelineFilters): any;
export declare function pipelineFiltersToHclTerraform(struct?: PipelineFiltersOutputReference | PipelineFilters): any;
export declare class PipelineFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineFilters | undefined;
    set internalValue(value: PipelineFilters | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface PipelineGatewayDefinitionConnectionParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#source_catalog Pipeline#source_catalog}
    */
    readonly sourceCatalog?: string;
}
export declare function pipelineGatewayDefinitionConnectionParametersToTerraform(struct?: PipelineGatewayDefinitionConnectionParametersOutputReference | PipelineGatewayDefinitionConnectionParameters): any;
export declare function pipelineGatewayDefinitionConnectionParametersToHclTerraform(struct?: PipelineGatewayDefinitionConnectionParametersOutputReference | PipelineGatewayDefinitionConnectionParameters): any;
export declare class PipelineGatewayDefinitionConnectionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineGatewayDefinitionConnectionParameters | undefined;
    set internalValue(value: PipelineGatewayDefinitionConnectionParameters | undefined);
    private _sourceCatalog?;
    get sourceCatalog(): string;
    set sourceCatalog(value: string);
    resetSourceCatalog(): void;
    get sourceCatalogInput(): string | undefined;
}
export interface PipelineGatewayDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_id Pipeline#connection_id}
    */
    readonly connectionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#gateway_storage_catalog Pipeline#gateway_storage_catalog}
    */
    readonly gatewayStorageCatalog: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#gateway_storage_name Pipeline#gateway_storage_name}
    */
    readonly gatewayStorageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#gateway_storage_schema Pipeline#gateway_storage_schema}
    */
    readonly gatewayStorageSchema: string;
    /**
    * connection_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_parameters Pipeline#connection_parameters}
    */
    readonly connectionParameters?: PipelineGatewayDefinitionConnectionParameters;
}
export declare function pipelineGatewayDefinitionToTerraform(struct?: PipelineGatewayDefinitionOutputReference | PipelineGatewayDefinition): any;
export declare function pipelineGatewayDefinitionToHclTerraform(struct?: PipelineGatewayDefinitionOutputReference | PipelineGatewayDefinition): any;
export declare class PipelineGatewayDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineGatewayDefinition | undefined;
    set internalValue(value: PipelineGatewayDefinition | undefined);
    private _connectionId?;
    get connectionId(): string;
    set connectionId(value: string);
    resetConnectionId(): void;
    get connectionIdInput(): string | undefined;
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    get connectionNameInput(): string | undefined;
    private _gatewayStorageCatalog?;
    get gatewayStorageCatalog(): string;
    set gatewayStorageCatalog(value: string);
    get gatewayStorageCatalogInput(): string | undefined;
    private _gatewayStorageName?;
    get gatewayStorageName(): string;
    set gatewayStorageName(value: string);
    resetGatewayStorageName(): void;
    get gatewayStorageNameInput(): string | undefined;
    private _gatewayStorageSchema?;
    get gatewayStorageSchema(): string;
    set gatewayStorageSchema(value: string);
    get gatewayStorageSchemaInput(): string | undefined;
    private _connectionParameters;
    get connectionParameters(): PipelineGatewayDefinitionConnectionParametersOutputReference;
    putConnectionParameters(value: PipelineGatewayDefinitionConnectionParameters): void;
    resetConnectionParameters(): void;
    get connectionParametersInput(): PipelineGatewayDefinitionConnectionParameters | undefined;
}
export interface PipelineIngestionDefinitionDataStagingOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#catalog_name Pipeline#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_name Pipeline#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#volume_name Pipeline#volume_name}
    */
    readonly volumeName?: string;
}
export declare function pipelineIngestionDefinitionDataStagingOptionsToTerraform(struct?: PipelineIngestionDefinitionDataStagingOptionsOutputReference | PipelineIngestionDefinitionDataStagingOptions): any;
export declare function pipelineIngestionDefinitionDataStagingOptionsToHclTerraform(struct?: PipelineIngestionDefinitionDataStagingOptionsOutputReference | PipelineIngestionDefinitionDataStagingOptions): any;
export declare class PipelineIngestionDefinitionDataStagingOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionDataStagingOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionDataStagingOptions | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _volumeName?;
    get volumeName(): string;
    set volumeName(value: string);
    resetVolumeName(): void;
    get volumeNameInput(): string | undefined;
}
export interface PipelineIngestionDefinitionFullRefreshWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#days_of_week Pipeline#days_of_week}
    */
    readonly daysOfWeek?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#start_hour Pipeline#start_hour}
    */
    readonly startHour: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#time_zone_id Pipeline#time_zone_id}
    */
    readonly timeZoneId?: string;
}
export declare function pipelineIngestionDefinitionFullRefreshWindowToTerraform(struct?: PipelineIngestionDefinitionFullRefreshWindowOutputReference | PipelineIngestionDefinitionFullRefreshWindow): any;
export declare function pipelineIngestionDefinitionFullRefreshWindowToHclTerraform(struct?: PipelineIngestionDefinitionFullRefreshWindowOutputReference | PipelineIngestionDefinitionFullRefreshWindow): any;
export declare class PipelineIngestionDefinitionFullRefreshWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionFullRefreshWindow | undefined;
    set internalValue(value: PipelineIngestionDefinitionFullRefreshWindow | undefined);
    private _daysOfWeek?;
    get daysOfWeek(): string[];
    set daysOfWeek(value: string[]);
    resetDaysOfWeek(): void;
    get daysOfWeekInput(): string[] | undefined;
    private _startHour?;
    get startHour(): number;
    set startHour(value: number);
    get startHourInput(): number | undefined;
    private _timeZoneId?;
    get timeZoneId(): string;
    set timeZoneId(value: string);
    resetTimeZoneId(): void;
    get timeZoneIdInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enabled Pipeline#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#min_interval_hours Pipeline#min_interval_hours}
    */
    readonly minIntervalHours?: number;
}
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicyToTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy): any;
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicyToHclTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy): any;
export declare class PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _minIntervalHours?;
    get minIntervalHours(): number;
    set minIntervalHours(value: number);
    resetMinIntervalHours(): void;
    get minIntervalHoursInput(): number | undefined;
}
export interface PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#cursor_columns Pipeline#cursor_columns}
    */
    readonly cursorColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#deletion_condition Pipeline#deletion_condition}
    */
    readonly deletionCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#hard_deletion_sync_min_interval_in_seconds Pipeline#hard_deletion_sync_min_interval_in_seconds}
    */
    readonly hardDeletionSyncMinIntervalInSeconds?: number;
}
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfigToTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig): any;
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfigToHclTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig): any;
export declare class PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig | undefined);
    private _cursorColumns?;
    get cursorColumns(): string[];
    set cursorColumns(value: string[]);
    resetCursorColumns(): void;
    get cursorColumnsInput(): string[] | undefined;
    private _deletionCondition?;
    get deletionCondition(): string;
    set deletionCondition(value: string);
    resetDeletionCondition(): void;
    get deletionConditionInput(): string | undefined;
    private _hardDeletionSyncMinIntervalInSeconds?;
    get hardDeletionSyncMinIntervalInSeconds(): number;
    set hardDeletionSyncMinIntervalInSeconds(value: number);
    resetHardDeletionSyncMinIntervalInSeconds(): void;
    get hardDeletionSyncMinIntervalInSecondsInput(): number | undefined;
}
export interface PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#key Pipeline#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#value Pipeline#value}
    */
    readonly value?: string;
}
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParametersToTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParametersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParametersOutputReference;
}
export interface PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#incremental Pipeline#incremental}
    */
    readonly incremental?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parameters Pipeline#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#report_parameters Pipeline#report_parameters}
    */
    readonly reportParameters?: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersToTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters): any;
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters): any;
export declare class PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters | undefined);
    private _incremental?;
    get incremental(): boolean | cdktn.IResolvable;
    set incremental(value: boolean | cdktn.IResolvable);
    resetIncremental(): void;
    get incrementalInput(): boolean | cdktn.IResolvable | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _reportParameters;
    get reportParameters(): PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParametersList;
    putReportParameters(value: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable): void;
    resetReportParameters(): void;
    get reportParametersInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersReportParameters[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsReportTableConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#clustering_columns Pipeline#clustering_columns}
    */
    readonly clusteringColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enable_auto_clustering Pipeline#enable_auto_clustering}
    */
    readonly enableAutoClustering?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#exclude_columns Pipeline#exclude_columns}
    */
    readonly excludeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_columns Pipeline#include_columns}
    */
    readonly includeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#primary_keys Pipeline#primary_keys}
    */
    readonly primaryKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#row_filter Pipeline#row_filter}
    */
    readonly rowFilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#salesforce_include_formula_fields Pipeline#salesforce_include_formula_fields}
    */
    readonly salesforceIncludeFormulaFields?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#scd_type Pipeline#scd_type}
    */
    readonly scdType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sequence_by Pipeline#sequence_by}
    */
    readonly sequenceBy?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#source_metadata_column Pipeline#source_metadata_column}
    */
    readonly sourceMetadataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#table_properties Pipeline#table_properties}
    */
    readonly tableProperties?: {
        [key: string]: string;
    };
    /**
    * auto_full_refresh_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#auto_full_refresh_policy Pipeline#auto_full_refresh_policy}
    */
    readonly autoFullRefreshPolicy?: PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy;
    /**
    * query_based_connector_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#query_based_connector_config Pipeline#query_based_connector_config}
    */
    readonly queryBasedConnectorConfig?: PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig;
    /**
    * workday_report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#workday_report_parameters Pipeline#workday_report_parameters}
    */
    readonly workdayReportParameters?: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters;
}
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationToTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationOutputReference | PipelineIngestionDefinitionObjectsReportTableConfiguration): any;
export declare function pipelineIngestionDefinitionObjectsReportTableConfigurationToHclTerraform(struct?: PipelineIngestionDefinitionObjectsReportTableConfigurationOutputReference | PipelineIngestionDefinitionObjectsReportTableConfiguration): any;
export declare class PipelineIngestionDefinitionObjectsReportTableConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsReportTableConfiguration | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsReportTableConfiguration | undefined);
    private _clusteringColumns?;
    get clusteringColumns(): string[];
    set clusteringColumns(value: string[]);
    resetClusteringColumns(): void;
    get clusteringColumnsInput(): string[] | undefined;
    private _enableAutoClustering?;
    get enableAutoClustering(): boolean | cdktn.IResolvable;
    set enableAutoClustering(value: boolean | cdktn.IResolvable);
    resetEnableAutoClustering(): void;
    get enableAutoClusteringInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeColumns?;
    get excludeColumns(): string[];
    set excludeColumns(value: string[]);
    resetExcludeColumns(): void;
    get excludeColumnsInput(): string[] | undefined;
    private _includeColumns?;
    get includeColumns(): string[];
    set includeColumns(value: string[]);
    resetIncludeColumns(): void;
    get includeColumnsInput(): string[] | undefined;
    private _primaryKeys?;
    get primaryKeys(): string[];
    set primaryKeys(value: string[]);
    resetPrimaryKeys(): void;
    get primaryKeysInput(): string[] | undefined;
    private _rowFilter?;
    get rowFilter(): string;
    set rowFilter(value: string);
    resetRowFilter(): void;
    get rowFilterInput(): string | undefined;
    private _salesforceIncludeFormulaFields?;
    get salesforceIncludeFormulaFields(): boolean | cdktn.IResolvable;
    set salesforceIncludeFormulaFields(value: boolean | cdktn.IResolvable);
    resetSalesforceIncludeFormulaFields(): void;
    get salesforceIncludeFormulaFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _scdType?;
    get scdType(): string;
    set scdType(value: string);
    resetScdType(): void;
    get scdTypeInput(): string | undefined;
    private _sequenceBy?;
    get sequenceBy(): string[];
    set sequenceBy(value: string[]);
    resetSequenceBy(): void;
    get sequenceByInput(): string[] | undefined;
    private _sourceMetadataColumn?;
    get sourceMetadataColumn(): string;
    set sourceMetadataColumn(value: string);
    resetSourceMetadataColumn(): void;
    get sourceMetadataColumnInput(): string | undefined;
    private _tableProperties?;
    get tableProperties(): {
        [key: string]: string;
    };
    set tableProperties(value: {
        [key: string]: string;
    });
    resetTableProperties(): void;
    get tablePropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _autoFullRefreshPolicy;
    get autoFullRefreshPolicy(): PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicyOutputReference;
    putAutoFullRefreshPolicy(value: PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy): void;
    resetAutoFullRefreshPolicy(): void;
    get autoFullRefreshPolicyInput(): PipelineIngestionDefinitionObjectsReportTableConfigurationAutoFullRefreshPolicy | undefined;
    private _queryBasedConnectorConfig;
    get queryBasedConnectorConfig(): PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfigOutputReference;
    putQueryBasedConnectorConfig(value: PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig): void;
    resetQueryBasedConnectorConfig(): void;
    get queryBasedConnectorConfigInput(): PipelineIngestionDefinitionObjectsReportTableConfigurationQueryBasedConnectorConfig | undefined;
    private _workdayReportParameters;
    get workdayReportParameters(): PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParametersOutputReference;
    putWorkdayReportParameters(value: PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters): void;
    resetWorkdayReportParameters(): void;
    get workdayReportParametersInput(): PipelineIngestionDefinitionObjectsReportTableConfigurationWorkdayReportParameters | undefined;
}
export interface PipelineIngestionDefinitionObjectsReport {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination_catalog Pipeline#destination_catalog}
    */
    readonly destinationCatalog: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination_schema Pipeline#destination_schema}
    */
    readonly destinationSchema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination_table Pipeline#destination_table}
    */
    readonly destinationTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#source_url Pipeline#source_url}
    */
    readonly sourceUrl: string;
    /**
    * table_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#table_configuration Pipeline#table_configuration}
    */
    readonly tableConfiguration?: PipelineIngestionDefinitionObjectsReportTableConfiguration;
}
export declare function pipelineIngestionDefinitionObjectsReportToTerraform(struct?: PipelineIngestionDefinitionObjectsReportOutputReference | PipelineIngestionDefinitionObjectsReport): any;
export declare function pipelineIngestionDefinitionObjectsReportToHclTerraform(struct?: PipelineIngestionDefinitionObjectsReportOutputReference | PipelineIngestionDefinitionObjectsReport): any;
export declare class PipelineIngestionDefinitionObjectsReportOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsReport | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsReport | undefined);
    private _destinationCatalog?;
    get destinationCatalog(): string;
    set destinationCatalog(value: string);
    get destinationCatalogInput(): string | undefined;
    private _destinationSchema?;
    get destinationSchema(): string;
    set destinationSchema(value: string);
    get destinationSchemaInput(): string | undefined;
    private _destinationTable?;
    get destinationTable(): string;
    set destinationTable(value: string);
    resetDestinationTable(): void;
    get destinationTableInput(): string | undefined;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    get sourceUrlInput(): string | undefined;
    private _tableConfiguration;
    get tableConfiguration(): PipelineIngestionDefinitionObjectsReportTableConfigurationOutputReference;
    putTableConfiguration(value: PipelineIngestionDefinitionObjectsReportTableConfiguration): void;
    resetTableConfiguration(): void;
    get tableConfigurationInput(): PipelineIngestionDefinitionObjectsReportTableConfiguration | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#options Pipeline#options}
    */
    readonly options?: {
        [key: string]: string;
    };
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions | undefined);
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_confluence_spaces Pipeline#include_confluence_spaces}
    */
    readonly includeConfluenceSpaces?: string[];
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions | undefined);
    private _includeConfluenceSpaces?;
    get includeConfluenceSpaces(): string[];
    set includeConfluenceSpaces(value: string[]);
    resetIncludeConfluenceSpaces(): void;
    get includeConfluenceSpacesInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_after Pipeline#modified_after}
    */
    readonly modifiedAfter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_before Pipeline#modified_before}
    */
    readonly modifiedBefore?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#path_filter Pipeline#path_filter}
    */
    readonly pathFilter?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined);
    private _modifiedAfter?;
    get modifiedAfter(): string;
    set modifiedAfter(value: string);
    resetModifiedAfter(): void;
    get modifiedAfterInput(): string | undefined;
    private _modifiedBefore?;
    get modifiedBefore(): string;
    set modifiedBefore(value: string);
    resetModifiedBefore(): void;
    get modifiedBeforeInput(): string | undefined;
    private _pathFilter?;
    get pathFilter(): string;
    set pathFilter(value: string);
    resetPathFilter(): void;
    get pathFilterInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersOutputReference;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#corrupt_record_column Pipeline#corrupt_record_column}
    */
    readonly corruptRecordColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format_options Pipeline#format_options}
    */
    readonly formatOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ignore_corrupt_files Pipeline#ignore_corrupt_files}
    */
    readonly ignoreCorruptFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#infer_column_types Pipeline#infer_column_types}
    */
    readonly inferColumnTypes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#reader_case_sensitive Pipeline#reader_case_sensitive}
    */
    readonly readerCaseSensitive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#rescued_data_column Pipeline#rescued_data_column}
    */
    readonly rescuedDataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#single_variant_column Pipeline#single_variant_column}
    */
    readonly singleVariantColumn?: string;
    /**
    * file_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_filters Pipeline#file_filters}
    */
    readonly fileFilters?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions | undefined);
    private _corruptRecordColumn?;
    get corruptRecordColumn(): string;
    set corruptRecordColumn(value: string);
    resetCorruptRecordColumn(): void;
    get corruptRecordColumnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _formatOptions?;
    get formatOptions(): {
        [key: string]: string;
    };
    set formatOptions(value: {
        [key: string]: string;
    });
    resetFormatOptions(): void;
    get formatOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _ignoreCorruptFiles?;
    get ignoreCorruptFiles(): boolean | cdktn.IResolvable;
    set ignoreCorruptFiles(value: boolean | cdktn.IResolvable);
    resetIgnoreCorruptFiles(): void;
    get ignoreCorruptFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _inferColumnTypes?;
    get inferColumnTypes(): boolean | cdktn.IResolvable;
    set inferColumnTypes(value: boolean | cdktn.IResolvable);
    resetInferColumnTypes(): void;
    get inferColumnTypesInput(): boolean | cdktn.IResolvable | undefined;
    private _readerCaseSensitive?;
    get readerCaseSensitive(): boolean | cdktn.IResolvable;
    set readerCaseSensitive(value: boolean | cdktn.IResolvable);
    resetReaderCaseSensitive(): void;
    get readerCaseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
    private _rescuedDataColumn?;
    get rescuedDataColumn(): string;
    set rescuedDataColumn(value: string);
    resetRescuedDataColumn(): void;
    get rescuedDataColumnInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
    private _singleVariantColumn?;
    get singleVariantColumn(): string;
    set singleVariantColumn(value: string);
    resetSingleVariantColumn(): void;
    get singleVariantColumnInput(): string | undefined;
    private _fileFilters;
    get fileFilters(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersList;
    putFileFilters(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable): void;
    resetFileFilters(): void;
    get fileFiltersInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#entity_type Pipeline#entity_type}
    */
    readonly entityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#url Pipeline#url}
    */
    readonly url?: string;
    /**
    * file_ingestion_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_ingestion_options Pipeline#file_ingestion_options}
    */
    readonly fileIngestionOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions | undefined);
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    resetEntityType(): void;
    get entityTypeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _fileIngestionOptions;
    get fileIngestionOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference;
    putFileIngestionOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions): void;
    resetFileIngestionOptions(): void;
    get fileIngestionOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsFileIngestionOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#resource Pipeline#resource}
    */
    readonly resource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#resource_fields Pipeline#resource_fields}
    */
    readonly resourceFields?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#segments Pipeline#segments}
    */
    readonly segments?: string[];
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions | undefined);
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
    private _resourceFields?;
    get resourceFields(): string[];
    set resourceFields(value: string[]);
    resetResourceFields(): void;
    get resourceFieldsInput(): string[] | undefined;
    private _segments?;
    get segments(): string[];
    set segments(value: string[]);
    resetSegments(): void;
    get segmentsInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#manager_account_id Pipeline#manager_account_id}
    */
    readonly managerAccountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions | undefined);
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _managerAccountId?;
    get managerAccountId(): string;
    set managerAccountId(value: string);
    get managerAccountIdInput(): string | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_jira_spaces Pipeline#include_jira_spaces}
    */
    readonly includeJiraSpaces?: string[];
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions | undefined);
    private _includeJiraSpaces?;
    get includeJiraSpaces(): string[];
    set includeJiraSpaces(value: string[]);
    resetIncludeJiraSpaces(): void;
    get includeJiraSpacesInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions | undefined);
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#as_variant Pipeline#as_variant}
    */
    readonly asVariant?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions | undefined);
    private _asVariant?;
    get asVariant(): boolean | cdktn.IResolvable;
    set asVariant(value: boolean | cdktn.IResolvable);
    resetAsVariant(): void;
    get asVariantInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#desc_file_path Pipeline#desc_file_path}
    */
    readonly descFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#message_name Pipeline#message_name}
    */
    readonly messageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#recursive_fields_max_depth Pipeline#recursive_fields_max_depth}
    */
    readonly recursiveFieldsMaxDepth?: number;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions | undefined);
    private _descFilePath?;
    get descFilePath(): string;
    set descFilePath(value: string);
    resetDescFilePath(): void;
    get descFilePathInput(): string | undefined;
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    resetMessageName(): void;
    get messageNameInput(): string | undefined;
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _recursiveFieldsMaxDepth?;
    get recursiveFieldsMaxDepth(): number;
    set recursiveFieldsMaxDepth(value: number);
    resetRecursiveFieldsMaxDepth(): void;
    get recursiveFieldsMaxDepthInput(): number | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#input_column Pipeline#input_column}
    */
    readonly inputColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#output_column Pipeline#output_column}
    */
    readonly outputColumn?: string;
    /**
    * avro_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#avro_options Pipeline#avro_options}
    */
    readonly avroOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions;
    /**
    * json_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#json_options Pipeline#json_options}
    */
    readonly jsonOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions;
    /**
    * protobuf_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_options Pipeline#protobuf_options}
    */
    readonly protobufOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _inputColumn?;
    get inputColumn(): string;
    set inputColumn(value: string);
    resetInputColumn(): void;
    get inputColumnInput(): string | undefined;
    private _outputColumn?;
    get outputColumn(): string;
    set outputColumn(value: string);
    resetOutputColumn(): void;
    get outputColumnInput(): string | undefined;
    private _avroOptions;
    get avroOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference;
    putAvroOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions): void;
    resetAvroOptions(): void;
    get avroOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerAvroOptions | undefined;
    private _jsonOptions;
    get jsonOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference;
    putJsonOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions): void;
    resetJsonOptions(): void;
    get jsonOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerJsonOptions | undefined;
    private _protobufOptions;
    get protobufOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference;
    putProtobufOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions): void;
    resetProtobufOptions(): void;
    get protobufOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions | undefined);
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#as_variant Pipeline#as_variant}
    */
    readonly asVariant?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions | undefined);
    private _asVariant?;
    get asVariant(): boolean | cdktn.IResolvable;
    set asVariant(value: boolean | cdktn.IResolvable);
    resetAsVariant(): void;
    get asVariantInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#desc_file_path Pipeline#desc_file_path}
    */
    readonly descFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#message_name Pipeline#message_name}
    */
    readonly messageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#recursive_fields_max_depth Pipeline#recursive_fields_max_depth}
    */
    readonly recursiveFieldsMaxDepth?: number;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions | undefined);
    private _descFilePath?;
    get descFilePath(): string;
    set descFilePath(value: string);
    resetDescFilePath(): void;
    get descFilePathInput(): string | undefined;
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    resetMessageName(): void;
    get messageNameInput(): string | undefined;
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _recursiveFieldsMaxDepth?;
    get recursiveFieldsMaxDepth(): number;
    set recursiveFieldsMaxDepth(value: number);
    resetRecursiveFieldsMaxDepth(): void;
    get recursiveFieldsMaxDepthInput(): number | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#input_column Pipeline#input_column}
    */
    readonly inputColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#output_column Pipeline#output_column}
    */
    readonly outputColumn?: string;
    /**
    * avro_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#avro_options Pipeline#avro_options}
    */
    readonly avroOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions;
    /**
    * json_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#json_options Pipeline#json_options}
    */
    readonly jsonOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions;
    /**
    * protobuf_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_options Pipeline#protobuf_options}
    */
    readonly protobufOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _inputColumn?;
    get inputColumn(): string;
    set inputColumn(value: string);
    resetInputColumn(): void;
    get inputColumnInput(): string | undefined;
    private _outputColumn?;
    get outputColumn(): string;
    set outputColumn(value: string);
    resetOutputColumn(): void;
    get outputColumnInput(): string | undefined;
    private _avroOptions;
    get avroOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference;
    putAvroOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions): void;
    resetAvroOptions(): void;
    get avroOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerAvroOptions | undefined;
    private _jsonOptions;
    get jsonOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference;
    putJsonOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions): void;
    resetJsonOptions(): void;
    get jsonOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerJsonOptions | undefined;
    private _protobufOptions;
    get protobufOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference;
    putProtobufOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions): void;
    resetProtobufOptions(): void;
    get protobufOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerProtobufOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#client_config Pipeline#client_config}
    */
    readonly clientConfig?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#max_offsets_per_trigger Pipeline#max_offsets_per_trigger}
    */
    readonly maxOffsetsPerTrigger?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#starting_offset Pipeline#starting_offset}
    */
    readonly startingOffset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#topic_pattern Pipeline#topic_pattern}
    */
    readonly topicPattern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#topics Pipeline#topics}
    */
    readonly topics?: string[];
    /**
    * key_transformer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#key_transformer Pipeline#key_transformer}
    */
    readonly keyTransformer?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer;
    /**
    * value_transformer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#value_transformer Pipeline#value_transformer}
    */
    readonly valueTransformer?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions | undefined);
    private _clientConfig?;
    get clientConfig(): {
        [key: string]: string;
    };
    set clientConfig(value: {
        [key: string]: string;
    });
    resetClientConfig(): void;
    get clientConfigInput(): {
        [key: string]: string;
    } | undefined;
    private _maxOffsetsPerTrigger?;
    get maxOffsetsPerTrigger(): number;
    set maxOffsetsPerTrigger(value: number);
    resetMaxOffsetsPerTrigger(): void;
    get maxOffsetsPerTriggerInput(): number | undefined;
    private _startingOffset?;
    get startingOffset(): string;
    set startingOffset(value: string);
    resetStartingOffset(): void;
    get startingOffsetInput(): string | undefined;
    private _topicPattern?;
    get topicPattern(): string;
    set topicPattern(value: string);
    resetTopicPattern(): void;
    get topicPatternInput(): string | undefined;
    private _topics?;
    get topics(): string[];
    set topics(value: string[]);
    resetTopics(): void;
    get topicsInput(): string[] | undefined;
    private _keyTransformer;
    get keyTransformer(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformerOutputReference;
    putKeyTransformer(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer): void;
    resetKeyTransformer(): void;
    get keyTransformerInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsKeyTransformer | undefined;
    private _valueTransformer;
    get valueTransformer(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformerOutputReference;
    putValueTransformer(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer): void;
    resetValueTransformer(): void;
    get valueTransformerInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsValueTransformer | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#entity_granularity Pipeline#entity_granularity}
    */
    readonly entityGranularity?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#finder Pipeline#finder}
    */
    readonly finder: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#time_granularity Pipeline#time_granularity}
    */
    readonly timeGranularity?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions | undefined);
    private _entityGranularity?;
    get entityGranularity(): string[];
    set entityGranularity(value: string[]);
    resetEntityGranularity(): void;
    get entityGranularityInput(): string[] | undefined;
    private _finder?;
    get finder(): string;
    set finder(value: string);
    get finderInput(): string | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _timeGranularity?;
    get timeGranularity(): string;
    set timeGranularity(value: string);
    resetTimeGranularity(): void;
    get timeGranularityInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions | undefined);
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions | undefined);
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_attribution_windows Pipeline#action_attribution_windows}
    */
    readonly actionAttributionWindows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_breakdowns Pipeline#action_breakdowns}
    */
    readonly actionBreakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_report_time Pipeline#action_report_time}
    */
    readonly actionReportTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#breakdowns Pipeline#breakdowns}
    */
    readonly breakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#level Pipeline#level}
    */
    readonly level?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#time_increment Pipeline#time_increment}
    */
    readonly timeIncrement?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions | undefined);
    private _actionAttributionWindows?;
    get actionAttributionWindows(): string[];
    set actionAttributionWindows(value: string[]);
    resetActionAttributionWindows(): void;
    get actionAttributionWindowsInput(): string[] | undefined;
    private _actionBreakdowns?;
    get actionBreakdowns(): string[];
    set actionBreakdowns(value: string[]);
    resetActionBreakdowns(): void;
    get actionBreakdownsInput(): string[] | undefined;
    private _actionReportTime?;
    get actionReportTime(): string;
    set actionReportTime(value: string);
    resetActionReportTime(): void;
    get actionReportTimeInput(): string | undefined;
    private _breakdowns?;
    get breakdowns(): string[];
    set breakdowns(value: string[]);
    resetBreakdowns(): void;
    get breakdownsInput(): string[] | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _timeIncrement?;
    get timeIncrement(): string;
    set timeIncrement(value: string);
    resetTimeIncrement(): void;
    get timeIncrementInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_attribution_windows Pipeline#action_attribution_windows}
    */
    readonly actionAttributionWindows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_breakdowns Pipeline#action_breakdowns}
    */
    readonly actionBreakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_report_time Pipeline#action_report_time}
    */
    readonly actionReportTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#breakdowns Pipeline#breakdowns}
    */
    readonly breakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_insights_lookback_window Pipeline#custom_insights_lookback_window}
    */
    readonly customInsightsLookbackWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#level Pipeline#level}
    */
    readonly level?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#start_date Pipeline#start_date}
    */
    readonly startDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#time_increment Pipeline#time_increment}
    */
    readonly timeIncrement?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions | undefined);
    private _actionAttributionWindows?;
    get actionAttributionWindows(): string[];
    set actionAttributionWindows(value: string[]);
    resetActionAttributionWindows(): void;
    get actionAttributionWindowsInput(): string[] | undefined;
    private _actionBreakdowns?;
    get actionBreakdowns(): string[];
    set actionBreakdowns(value: string[]);
    resetActionBreakdowns(): void;
    get actionBreakdownsInput(): string[] | undefined;
    private _actionReportTime?;
    get actionReportTime(): string;
    set actionReportTime(value: string);
    resetActionReportTime(): void;
    get actionReportTimeInput(): string | undefined;
    private _breakdowns?;
    get breakdowns(): string[];
    set breakdowns(value: string[]);
    resetBreakdowns(): void;
    get breakdownsInput(): string[] | undefined;
    private _customInsightsLookbackWindow?;
    get customInsightsLookbackWindow(): number;
    set customInsightsLookbackWindow(value: number);
    resetCustomInsightsLookbackWindow(): void;
    get customInsightsLookbackWindowInput(): number | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    private _timeIncrement?;
    get timeIncrement(): string;
    set timeIncrement(value: string);
    resetTimeIncrement(): void;
    get timeIncrementInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#attachment_mode Pipeline#attachment_mode}
    */
    readonly attachmentMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#body_format Pipeline#body_format}
    */
    readonly bodyFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#folder_filter Pipeline#folder_filter}
    */
    readonly folderFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_folders Pipeline#include_folders}
    */
    readonly includeFolders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_mailboxes Pipeline#include_mailboxes}
    */
    readonly includeMailboxes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_senders Pipeline#include_senders}
    */
    readonly includeSenders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_subjects Pipeline#include_subjects}
    */
    readonly includeSubjects?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sender_filter Pipeline#sender_filter}
    */
    readonly senderFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#start_date Pipeline#start_date}
    */
    readonly startDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject_filter Pipeline#subject_filter}
    */
    readonly subjectFilter?: string[];
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions | undefined);
    private _attachmentMode?;
    get attachmentMode(): string;
    set attachmentMode(value: string);
    resetAttachmentMode(): void;
    get attachmentModeInput(): string | undefined;
    private _bodyFormat?;
    get bodyFormat(): string;
    set bodyFormat(value: string);
    resetBodyFormat(): void;
    get bodyFormatInput(): string | undefined;
    private _folderFilter?;
    get folderFilter(): string[];
    set folderFilter(value: string[]);
    resetFolderFilter(): void;
    get folderFilterInput(): string[] | undefined;
    private _includeFolders?;
    get includeFolders(): string[];
    set includeFolders(value: string[]);
    resetIncludeFolders(): void;
    get includeFoldersInput(): string[] | undefined;
    private _includeMailboxes?;
    get includeMailboxes(): string[];
    set includeMailboxes(value: string[]);
    resetIncludeMailboxes(): void;
    get includeMailboxesInput(): string[] | undefined;
    private _includeSenders?;
    get includeSenders(): string[];
    set includeSenders(value: string[]);
    resetIncludeSenders(): void;
    get includeSendersInput(): string[] | undefined;
    private _includeSubjects?;
    get includeSubjects(): string[];
    set includeSubjects(value: string[]);
    resetIncludeSubjects(): void;
    get includeSubjectsInput(): string[] | undefined;
    private _senderFilter?;
    get senderFilter(): string[];
    set senderFilter(value: string[]);
    resetSenderFilter(): void;
    get senderFilterInput(): string[] | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    private _subjectFilter?;
    get subjectFilter(): string[];
    set subjectFilter(value: string[]);
    resetSubjectFilter(): void;
    get subjectFilterInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#queue Pipeline#queue}
    */
    readonly queue: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions | undefined);
    private _queue?;
    get queue(): string;
    set queue(value: string);
    get queueInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#breakdowns Pipeline#breakdowns}
    */
    readonly breakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#fields Pipeline#fields}
    */
    readonly fields?: string[];
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions | undefined);
    private _breakdowns?;
    get breakdowns(): string[];
    set breakdowns(value: string[]);
    resetBreakdowns(): void;
    get breakdownsInput(): string[] | undefined;
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    resetFields(): void;
    get fieldsInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions | undefined);
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_after Pipeline#modified_after}
    */
    readonly modifiedAfter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_before Pipeline#modified_before}
    */
    readonly modifiedBefore?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#path_filter Pipeline#path_filter}
    */
    readonly pathFilter?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined);
    private _modifiedAfter?;
    get modifiedAfter(): string;
    set modifiedAfter(value: string);
    resetModifiedAfter(): void;
    get modifiedAfterInput(): string | undefined;
    private _modifiedBefore?;
    get modifiedBefore(): string;
    set modifiedBefore(value: string);
    resetModifiedBefore(): void;
    get modifiedBeforeInput(): string | undefined;
    private _pathFilter?;
    get pathFilter(): string;
    set pathFilter(value: string);
    resetPathFilter(): void;
    get pathFilterInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersOutputReference;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#corrupt_record_column Pipeline#corrupt_record_column}
    */
    readonly corruptRecordColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format_options Pipeline#format_options}
    */
    readonly formatOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ignore_corrupt_files Pipeline#ignore_corrupt_files}
    */
    readonly ignoreCorruptFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#infer_column_types Pipeline#infer_column_types}
    */
    readonly inferColumnTypes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#reader_case_sensitive Pipeline#reader_case_sensitive}
    */
    readonly readerCaseSensitive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#rescued_data_column Pipeline#rescued_data_column}
    */
    readonly rescuedDataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#single_variant_column Pipeline#single_variant_column}
    */
    readonly singleVariantColumn?: string;
    /**
    * file_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_filters Pipeline#file_filters}
    */
    readonly fileFilters?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions | undefined);
    private _corruptRecordColumn?;
    get corruptRecordColumn(): string;
    set corruptRecordColumn(value: string);
    resetCorruptRecordColumn(): void;
    get corruptRecordColumnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _formatOptions?;
    get formatOptions(): {
        [key: string]: string;
    };
    set formatOptions(value: {
        [key: string]: string;
    });
    resetFormatOptions(): void;
    get formatOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _ignoreCorruptFiles?;
    get ignoreCorruptFiles(): boolean | cdktn.IResolvable;
    set ignoreCorruptFiles(value: boolean | cdktn.IResolvable);
    resetIgnoreCorruptFiles(): void;
    get ignoreCorruptFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _inferColumnTypes?;
    get inferColumnTypes(): boolean | cdktn.IResolvable;
    set inferColumnTypes(value: boolean | cdktn.IResolvable);
    resetInferColumnTypes(): void;
    get inferColumnTypesInput(): boolean | cdktn.IResolvable | undefined;
    private _readerCaseSensitive?;
    get readerCaseSensitive(): boolean | cdktn.IResolvable;
    set readerCaseSensitive(value: boolean | cdktn.IResolvable);
    resetReaderCaseSensitive(): void;
    get readerCaseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
    private _rescuedDataColumn?;
    get rescuedDataColumn(): string;
    set rescuedDataColumn(value: string);
    resetRescuedDataColumn(): void;
    get rescuedDataColumnInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
    private _singleVariantColumn?;
    get singleVariantColumn(): string;
    set singleVariantColumn(value: string);
    resetSingleVariantColumn(): void;
    get singleVariantColumnInput(): string | undefined;
    private _fileFilters;
    get fileFilters(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersList;
    putFileFilters(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable): void;
    resetFileFilters(): void;
    get fileFiltersInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#entity_type Pipeline#entity_type}
    */
    readonly entityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#url Pipeline#url}
    */
    readonly url?: string;
    /**
    * file_ingestion_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_ingestion_options Pipeline#file_ingestion_options}
    */
    readonly fileIngestionOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions | undefined);
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    resetEntityType(): void;
    get entityTypeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _fileIngestionOptions;
    get fileIngestionOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference;
    putFileIngestionOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions): void;
    resetFileIngestionOptions(): void;
    get fileIngestionOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsFileIngestionOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enforce_schema Pipeline#enforce_schema}
    */
    readonly enforceSchema?: boolean | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions | undefined);
    private _enforceSchema?;
    get enforceSchema(): boolean | cdktn.IResolvable;
    set enforceSchema(value: boolean | cdktn.IResolvable);
    resetEnforceSchema(): void;
    get enforceSchemaInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#data_level Pipeline#data_level}
    */
    readonly dataLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#dimensions Pipeline#dimensions}
    */
    readonly dimensions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#query_lifetime Pipeline#query_lifetime}
    */
    readonly queryLifetime?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#report_type Pipeline#report_type}
    */
    readonly reportType?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions | undefined);
    private _dataLevel?;
    get dataLevel(): string;
    set dataLevel(value: string);
    resetDataLevel(): void;
    get dataLevelInput(): string | undefined;
    private _dimensions?;
    get dimensions(): string[];
    set dimensions(value: string[]);
    resetDimensions(): void;
    get dimensionsInput(): string[] | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _queryLifetime?;
    get queryLifetime(): boolean | cdktn.IResolvable;
    set queryLifetime(value: boolean | cdktn.IResolvable);
    resetQueryLifetime(): void;
    get queryLifetimeInput(): boolean | cdktn.IResolvable | undefined;
    private _reportType?;
    get reportType(): string;
    set reportType(value: string);
    resetReportType(): void;
    get reportTypeInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#data_level Pipeline#data_level}
    */
    readonly dataLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#dimensions Pipeline#dimensions}
    */
    readonly dimensions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#query_lifetime Pipeline#query_lifetime}
    */
    readonly queryLifetime?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#report_type Pipeline#report_type}
    */
    readonly reportType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions | undefined);
    private _dataLevel?;
    get dataLevel(): string;
    set dataLevel(value: string);
    resetDataLevel(): void;
    get dataLevelInput(): string | undefined;
    private _dimensions?;
    get dimensions(): string[];
    set dimensions(value: string[]);
    resetDimensions(): void;
    get dimensionsInput(): string[] | undefined;
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _queryLifetime?;
    get queryLifetime(): boolean | cdktn.IResolvable;
    set queryLifetime(value: boolean | cdktn.IResolvable);
    resetQueryLifetime(): void;
    get queryLifetimeInput(): boolean | cdktn.IResolvable | undefined;
    private _reportType?;
    get reportType(): string;
    set reportType(value: string);
    resetReportType(): void;
    get reportTypeInput(): string | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#start_date Pipeline#start_date}
    */
    readonly startDate?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions | undefined);
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaConnectorOptions {
    /**
    * api_source_connector_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#api_source_connector_options Pipeline#api_source_connector_options}
    */
    readonly apiSourceConnectorOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions;
    /**
    * confluence_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluence_options Pipeline#confluence_options}
    */
    readonly confluenceOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions;
    /**
    * gdrive_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#gdrive_options Pipeline#gdrive_options}
    */
    readonly gdriveOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions;
    /**
    * google_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#google_ads_options Pipeline#google_ads_options}
    */
    readonly googleAdsOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions;
    /**
    * jira_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#jira_options Pipeline#jira_options}
    */
    readonly jiraOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions;
    /**
    * kafka_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#kafka_options Pipeline#kafka_options}
    */
    readonly kafkaOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions;
    /**
    * linkedin_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#linkedin_ads_options Pipeline#linkedin_ads_options}
    */
    readonly linkedinAdsOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions;
    /**
    * marketo_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#marketo_options Pipeline#marketo_options}
    */
    readonly marketoOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions;
    /**
    * meta_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#meta_ads_options Pipeline#meta_ads_options}
    */
    readonly metaAdsOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions;
    /**
    * outlook_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#outlook_options Pipeline#outlook_options}
    */
    readonly outlookOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions;
    /**
    * rabbitmq_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#rabbitmq_options Pipeline#rabbitmq_options}
    */
    readonly rabbitmqOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions;
    /**
    * reddit_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#reddit_ads_options Pipeline#reddit_ads_options}
    */
    readonly redditAdsOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions;
    /**
    * sharepoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sharepoint_options Pipeline#sharepoint_options}
    */
    readonly sharepointOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions;
    /**
    * smartsheet_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#smartsheet_options Pipeline#smartsheet_options}
    */
    readonly smartsheetOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions;
    /**
    * tiktok_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#tiktok_ads_options Pipeline#tiktok_ads_options}
    */
    readonly tiktokAdsOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions;
    /**
    * zendesk_support_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#zendesk_support_options Pipeline#zendesk_support_options}
    */
    readonly zendeskSupportOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaConnectorOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaConnectorOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaConnectorOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptions | undefined);
    private _apiSourceConnectorOptions;
    get apiSourceConnectorOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptionsOutputReference;
    putApiSourceConnectorOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions): void;
    resetApiSourceConnectorOptions(): void;
    get apiSourceConnectorOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsApiSourceConnectorOptions | undefined;
    private _confluenceOptions;
    get confluenceOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptionsOutputReference;
    putConfluenceOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions): void;
    resetConfluenceOptions(): void;
    get confluenceOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsConfluenceOptions | undefined;
    private _gdriveOptions;
    get gdriveOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptionsOutputReference;
    putGdriveOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions): void;
    resetGdriveOptions(): void;
    get gdriveOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGdriveOptions | undefined;
    private _googleAdsOptions;
    get googleAdsOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptionsOutputReference;
    putGoogleAdsOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions): void;
    resetGoogleAdsOptions(): void;
    get googleAdsOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsGoogleAdsOptions | undefined;
    private _jiraOptions;
    get jiraOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptionsOutputReference;
    putJiraOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions): void;
    resetJiraOptions(): void;
    get jiraOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsJiraOptions | undefined;
    private _kafkaOptions;
    get kafkaOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptionsOutputReference;
    putKafkaOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions): void;
    resetKafkaOptions(): void;
    get kafkaOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsKafkaOptions | undefined;
    private _linkedinAdsOptions;
    get linkedinAdsOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptionsOutputReference;
    putLinkedinAdsOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions): void;
    resetLinkedinAdsOptions(): void;
    get linkedinAdsOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsLinkedinAdsOptions | undefined;
    private _marketoOptions;
    get marketoOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptionsOutputReference;
    putMarketoOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions): void;
    resetMarketoOptions(): void;
    get marketoOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMarketoOptions | undefined;
    private _metaAdsOptions;
    get metaAdsOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptionsOutputReference;
    putMetaAdsOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions): void;
    resetMetaAdsOptions(): void;
    get metaAdsOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsMetaAdsOptions | undefined;
    private _outlookOptions;
    get outlookOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptionsOutputReference;
    putOutlookOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions): void;
    resetOutlookOptions(): void;
    get outlookOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutlookOptions | undefined;
    private _rabbitmqOptions;
    get rabbitmqOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptionsOutputReference;
    putRabbitmqOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions): void;
    resetRabbitmqOptions(): void;
    get rabbitmqOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRabbitmqOptions | undefined;
    private _redditAdsOptions;
    get redditAdsOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptionsOutputReference;
    putRedditAdsOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions): void;
    resetRedditAdsOptions(): void;
    get redditAdsOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsRedditAdsOptions | undefined;
    private _sharepointOptions;
    get sharepointOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptionsOutputReference;
    putSharepointOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions): void;
    resetSharepointOptions(): void;
    get sharepointOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSharepointOptions | undefined;
    private _smartsheetOptions;
    get smartsheetOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptionsOutputReference;
    putSmartsheetOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions): void;
    resetSmartsheetOptions(): void;
    get smartsheetOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsSmartsheetOptions | undefined;
    private _tiktokAdsOptions;
    get tiktokAdsOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptionsOutputReference;
    putTiktokAdsOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions): void;
    resetTiktokAdsOptions(): void;
    get tiktokAdsOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsTiktokAdsOptions | undefined;
    private _zendeskSupportOptions;
    get zendeskSupportOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptionsOutputReference;
    putZendeskSupportOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions): void;
    resetZendeskSupportOptions(): void;
    get zendeskSupportOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsZendeskSupportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions | undefined);
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#as_variant Pipeline#as_variant}
    */
    readonly asVariant?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions | undefined);
    private _asVariant?;
    get asVariant(): boolean | cdktn.IResolvable;
    set asVariant(value: boolean | cdktn.IResolvable);
    resetAsVariant(): void;
    get asVariantInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#desc_file_path Pipeline#desc_file_path}
    */
    readonly descFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#message_name Pipeline#message_name}
    */
    readonly messageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#recursive_fields_max_depth Pipeline#recursive_fields_max_depth}
    */
    readonly recursiveFieldsMaxDepth?: number;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions | undefined);
    private _descFilePath?;
    get descFilePath(): string;
    set descFilePath(value: string);
    resetDescFilePath(): void;
    get descFilePathInput(): string | undefined;
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    resetMessageName(): void;
    get messageNameInput(): string | undefined;
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _recursiveFieldsMaxDepth?;
    get recursiveFieldsMaxDepth(): number;
    set recursiveFieldsMaxDepth(value: number);
    resetRecursiveFieldsMaxDepth(): void;
    get recursiveFieldsMaxDepthInput(): number | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#input_column Pipeline#input_column}
    */
    readonly inputColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#output_column Pipeline#output_column}
    */
    readonly outputColumn?: string;
    /**
    * avro_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#avro_options Pipeline#avro_options}
    */
    readonly avroOptions?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions;
    /**
    * json_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#json_options Pipeline#json_options}
    */
    readonly jsonOptions?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions;
    /**
    * protobuf_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_options Pipeline#protobuf_options}
    */
    readonly protobufOptions?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _inputColumn?;
    get inputColumn(): string;
    set inputColumn(value: string);
    resetInputColumn(): void;
    get inputColumnInput(): string | undefined;
    private _outputColumn?;
    get outputColumn(): string;
    set outputColumn(value: string);
    resetOutputColumn(): void;
    get outputColumnInput(): string | undefined;
    private _avroOptions;
    get avroOptions(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptionsOutputReference;
    putAvroOptions(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions): void;
    resetAvroOptions(): void;
    get avroOptionsInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsAvroOptions | undefined;
    private _jsonOptions;
    get jsonOptions(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptionsOutputReference;
    putJsonOptions(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions): void;
    resetJsonOptions(): void;
    get jsonOptionsInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsJsonOptions | undefined;
    private _protobufOptions;
    get protobufOptions(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptionsOutputReference;
    putProtobufOptions(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions): void;
    resetProtobufOptions(): void;
    get protobufOptionsInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsProtobufOptions | undefined;
}
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsOutputReference;
}
export interface PipelineIngestionDefinitionObjectsSchemaFanoutOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#fanout_by Pipeline#fanout_by}
    */
    readonly fanoutBy?: string;
    /**
    * transforms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#transforms Pipeline#transforms}
    */
    readonly transforms?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptions): any;
export declare function pipelineIngestionDefinitionObjectsSchemaFanoutOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsOutputReference | PipelineIngestionDefinitionObjectsSchemaFanoutOptions): any;
export declare class PipelineIngestionDefinitionObjectsSchemaFanoutOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaFanoutOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptions | undefined);
    private _fanoutBy?;
    get fanoutBy(): string;
    set fanoutBy(value: string);
    resetFanoutBy(): void;
    get fanoutByInput(): string | undefined;
    private _transforms;
    get transforms(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransformsList;
    putTransforms(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms[] | cdktn.IResolvable): void;
    resetTransforms(): void;
    get transformsInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsSchemaFanoutOptionsTransforms[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enabled Pipeline#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#min_interval_hours Pipeline#min_interval_hours}
    */
    readonly minIntervalHours?: number;
}
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicyToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy): any;
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicyToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy): any;
export declare class PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _minIntervalHours?;
    get minIntervalHours(): number;
    set minIntervalHours(value: number);
    resetMinIntervalHours(): void;
    get minIntervalHoursInput(): number | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#cursor_columns Pipeline#cursor_columns}
    */
    readonly cursorColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#deletion_condition Pipeline#deletion_condition}
    */
    readonly deletionCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#hard_deletion_sync_min_interval_in_seconds Pipeline#hard_deletion_sync_min_interval_in_seconds}
    */
    readonly hardDeletionSyncMinIntervalInSeconds?: number;
}
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfigToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig): any;
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfigToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig): any;
export declare class PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig | undefined);
    private _cursorColumns?;
    get cursorColumns(): string[];
    set cursorColumns(value: string[]);
    resetCursorColumns(): void;
    get cursorColumnsInput(): string[] | undefined;
    private _deletionCondition?;
    get deletionCondition(): string;
    set deletionCondition(value: string);
    resetDeletionCondition(): void;
    get deletionConditionInput(): string | undefined;
    private _hardDeletionSyncMinIntervalInSeconds?;
    get hardDeletionSyncMinIntervalInSeconds(): number;
    set hardDeletionSyncMinIntervalInSeconds(value: number);
    resetHardDeletionSyncMinIntervalInSeconds(): void;
    get hardDeletionSyncMinIntervalInSecondsInput(): number | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#key Pipeline#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#value Pipeline#value}
    */
    readonly value?: string;
}
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParametersToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParametersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParametersOutputReference;
}
export interface PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#incremental Pipeline#incremental}
    */
    readonly incremental?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parameters Pipeline#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#report_parameters Pipeline#report_parameters}
    */
    readonly reportParameters?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters): any;
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters): any;
export declare class PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters | undefined);
    private _incremental?;
    get incremental(): boolean | cdktn.IResolvable;
    set incremental(value: boolean | cdktn.IResolvable);
    resetIncremental(): void;
    get incrementalInput(): boolean | cdktn.IResolvable | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _reportParameters;
    get reportParameters(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParametersList;
    putReportParameters(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable): void;
    resetReportParameters(): void;
    get reportParametersInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersReportParameters[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchemaTableConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#clustering_columns Pipeline#clustering_columns}
    */
    readonly clusteringColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enable_auto_clustering Pipeline#enable_auto_clustering}
    */
    readonly enableAutoClustering?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#exclude_columns Pipeline#exclude_columns}
    */
    readonly excludeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_columns Pipeline#include_columns}
    */
    readonly includeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#primary_keys Pipeline#primary_keys}
    */
    readonly primaryKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#row_filter Pipeline#row_filter}
    */
    readonly rowFilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#salesforce_include_formula_fields Pipeline#salesforce_include_formula_fields}
    */
    readonly salesforceIncludeFormulaFields?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#scd_type Pipeline#scd_type}
    */
    readonly scdType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sequence_by Pipeline#sequence_by}
    */
    readonly sequenceBy?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#source_metadata_column Pipeline#source_metadata_column}
    */
    readonly sourceMetadataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#table_properties Pipeline#table_properties}
    */
    readonly tableProperties?: {
        [key: string]: string;
    };
    /**
    * auto_full_refresh_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#auto_full_refresh_policy Pipeline#auto_full_refresh_policy}
    */
    readonly autoFullRefreshPolicy?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy;
    /**
    * query_based_connector_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#query_based_connector_config Pipeline#query_based_connector_config}
    */
    readonly queryBasedConnectorConfig?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig;
    /**
    * workday_report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#workday_report_parameters Pipeline#workday_report_parameters}
    */
    readonly workdayReportParameters?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters;
}
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfiguration): any;
export declare function pipelineIngestionDefinitionObjectsSchemaTableConfigurationToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaTableConfigurationOutputReference | PipelineIngestionDefinitionObjectsSchemaTableConfiguration): any;
export declare class PipelineIngestionDefinitionObjectsSchemaTableConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchemaTableConfiguration | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchemaTableConfiguration | undefined);
    private _clusteringColumns?;
    get clusteringColumns(): string[];
    set clusteringColumns(value: string[]);
    resetClusteringColumns(): void;
    get clusteringColumnsInput(): string[] | undefined;
    private _enableAutoClustering?;
    get enableAutoClustering(): boolean | cdktn.IResolvable;
    set enableAutoClustering(value: boolean | cdktn.IResolvable);
    resetEnableAutoClustering(): void;
    get enableAutoClusteringInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeColumns?;
    get excludeColumns(): string[];
    set excludeColumns(value: string[]);
    resetExcludeColumns(): void;
    get excludeColumnsInput(): string[] | undefined;
    private _includeColumns?;
    get includeColumns(): string[];
    set includeColumns(value: string[]);
    resetIncludeColumns(): void;
    get includeColumnsInput(): string[] | undefined;
    private _primaryKeys?;
    get primaryKeys(): string[];
    set primaryKeys(value: string[]);
    resetPrimaryKeys(): void;
    get primaryKeysInput(): string[] | undefined;
    private _rowFilter?;
    get rowFilter(): string;
    set rowFilter(value: string);
    resetRowFilter(): void;
    get rowFilterInput(): string | undefined;
    private _salesforceIncludeFormulaFields?;
    get salesforceIncludeFormulaFields(): boolean | cdktn.IResolvable;
    set salesforceIncludeFormulaFields(value: boolean | cdktn.IResolvable);
    resetSalesforceIncludeFormulaFields(): void;
    get salesforceIncludeFormulaFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _scdType?;
    get scdType(): string;
    set scdType(value: string);
    resetScdType(): void;
    get scdTypeInput(): string | undefined;
    private _sequenceBy?;
    get sequenceBy(): string[];
    set sequenceBy(value: string[]);
    resetSequenceBy(): void;
    get sequenceByInput(): string[] | undefined;
    private _sourceMetadataColumn?;
    get sourceMetadataColumn(): string;
    set sourceMetadataColumn(value: string);
    resetSourceMetadataColumn(): void;
    get sourceMetadataColumnInput(): string | undefined;
    private _tableProperties?;
    get tableProperties(): {
        [key: string]: string;
    };
    set tableProperties(value: {
        [key: string]: string;
    });
    resetTableProperties(): void;
    get tablePropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _autoFullRefreshPolicy;
    get autoFullRefreshPolicy(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicyOutputReference;
    putAutoFullRefreshPolicy(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy): void;
    resetAutoFullRefreshPolicy(): void;
    get autoFullRefreshPolicyInput(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationAutoFullRefreshPolicy | undefined;
    private _queryBasedConnectorConfig;
    get queryBasedConnectorConfig(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfigOutputReference;
    putQueryBasedConnectorConfig(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig): void;
    resetQueryBasedConnectorConfig(): void;
    get queryBasedConnectorConfigInput(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationQueryBasedConnectorConfig | undefined;
    private _workdayReportParameters;
    get workdayReportParameters(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParametersOutputReference;
    putWorkdayReportParameters(value: PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters): void;
    resetWorkdayReportParameters(): void;
    get workdayReportParametersInput(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationWorkdayReportParameters | undefined;
}
export interface PipelineIngestionDefinitionObjectsSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination_catalog Pipeline#destination_catalog}
    */
    readonly destinationCatalog: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#destination_schema Pipeline#destination_schema}
    */
    readonly destinationSchema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#source_catalog Pipeline#source_catalog}
    */
    readonly sourceCatalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#source_schema Pipeline#source_schema}
    */
    readonly sourceSchema?: string;
    /**
    * connector_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connector_options Pipeline#connector_options}
    */
    readonly connectorOptions?: PipelineIngestionDefinitionObjectsSchemaConnectorOptions;
    /**
    * fanout_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#fanout_options Pipeline#fanout_options}
    */
    readonly fanoutOptions?: PipelineIngestionDefinitionObjectsSchemaFanoutOptions;
    /**
    * table_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#table_configuration Pipeline#table_configuration}
    */
    readonly tableConfiguration?: PipelineIngestionDefinitionObjectsSchemaTableConfiguration;
}
export declare function pipelineIngestionDefinitionObjectsSchemaToTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaOutputReference | PipelineIngestionDefinitionObjectsSchema): any;
export declare function pipelineIngestionDefinitionObjectsSchemaToHclTerraform(struct?: PipelineIngestionDefinitionObjectsSchemaOutputReference | PipelineIngestionDefinitionObjectsSchema): any;
export declare class PipelineIngestionDefinitionObjectsSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsSchema | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsSchema | undefined);
    private _destinationCatalog?;
    get destinationCatalog(): string;
    set destinationCatalog(value: string);
    get destinationCatalogInput(): string | undefined;
    private _destinationSchema?;
    get destinationSchema(): string;
    set destinationSchema(value: string);
    get destinationSchemaInput(): string | undefined;
    private _sourceCatalog?;
    get sourceCatalog(): string;
    set sourceCatalog(value: string);
    resetSourceCatalog(): void;
    get sourceCatalogInput(): string | undefined;
    private _sourceSchema?;
    get sourceSchema(): string;
    set sourceSchema(value: string);
    resetSourceSchema(): void;
    get sourceSchemaInput(): string | undefined;
    private _connectorOptions;
    get connectorOptions(): PipelineIngestionDefinitionObjectsSchemaConnectorOptionsOutputReference;
    putConnectorOptions(value: PipelineIngestionDefinitionObjectsSchemaConnectorOptions): void;
    resetConnectorOptions(): void;
    get connectorOptionsInput(): PipelineIngestionDefinitionObjectsSchemaConnectorOptions | undefined;
    private _fanoutOptions;
    get fanoutOptions(): PipelineIngestionDefinitionObjectsSchemaFanoutOptionsOutputReference;
    putFanoutOptions(value: PipelineIngestionDefinitionObjectsSchemaFanoutOptions): void;
    resetFanoutOptions(): void;
    get fanoutOptionsInput(): PipelineIngestionDefinitionObjectsSchemaFanoutOptions | undefined;
    private _tableConfiguration;
    get tableConfiguration(): PipelineIngestionDefinitionObjectsSchemaTableConfigurationOutputReference;
    putTableConfiguration(value: PipelineIngestionDefinitionObjectsSchemaTableConfiguration): void;
    resetTableConfiguration(): void;
    get tableConfigurationInput(): PipelineIngestionDefinitionObjectsSchemaTableConfiguration | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#options Pipeline#options}
    */
    readonly options?: {
        [key: string]: string;
    };
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions | undefined);
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_confluence_spaces Pipeline#include_confluence_spaces}
    */
    readonly includeConfluenceSpaces?: string[];
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions | undefined);
    private _includeConfluenceSpaces?;
    get includeConfluenceSpaces(): string[];
    set includeConfluenceSpaces(value: string[]);
    resetIncludeConfluenceSpaces(): void;
    get includeConfluenceSpacesInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_after Pipeline#modified_after}
    */
    readonly modifiedAfter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_before Pipeline#modified_before}
    */
    readonly modifiedBefore?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#path_filter Pipeline#path_filter}
    */
    readonly pathFilter?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined);
    private _modifiedAfter?;
    get modifiedAfter(): string;
    set modifiedAfter(value: string);
    resetModifiedAfter(): void;
    get modifiedAfterInput(): string | undefined;
    private _modifiedBefore?;
    get modifiedBefore(): string;
    set modifiedBefore(value: string);
    resetModifiedBefore(): void;
    get modifiedBeforeInput(): string | undefined;
    private _pathFilter?;
    get pathFilter(): string;
    set pathFilter(value: string);
    resetPathFilter(): void;
    get pathFilterInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersOutputReference;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#corrupt_record_column Pipeline#corrupt_record_column}
    */
    readonly corruptRecordColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format_options Pipeline#format_options}
    */
    readonly formatOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ignore_corrupt_files Pipeline#ignore_corrupt_files}
    */
    readonly ignoreCorruptFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#infer_column_types Pipeline#infer_column_types}
    */
    readonly inferColumnTypes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#reader_case_sensitive Pipeline#reader_case_sensitive}
    */
    readonly readerCaseSensitive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#rescued_data_column Pipeline#rescued_data_column}
    */
    readonly rescuedDataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#single_variant_column Pipeline#single_variant_column}
    */
    readonly singleVariantColumn?: string;
    /**
    * file_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_filters Pipeline#file_filters}
    */
    readonly fileFilters?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions | undefined);
    private _corruptRecordColumn?;
    get corruptRecordColumn(): string;
    set corruptRecordColumn(value: string);
    resetCorruptRecordColumn(): void;
    get corruptRecordColumnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _formatOptions?;
    get formatOptions(): {
        [key: string]: string;
    };
    set formatOptions(value: {
        [key: string]: string;
    });
    resetFormatOptions(): void;
    get formatOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _ignoreCorruptFiles?;
    get ignoreCorruptFiles(): boolean | cdktn.IResolvable;
    set ignoreCorruptFiles(value: boolean | cdktn.IResolvable);
    resetIgnoreCorruptFiles(): void;
    get ignoreCorruptFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _inferColumnTypes?;
    get inferColumnTypes(): boolean | cdktn.IResolvable;
    set inferColumnTypes(value: boolean | cdktn.IResolvable);
    resetInferColumnTypes(): void;
    get inferColumnTypesInput(): boolean | cdktn.IResolvable | undefined;
    private _readerCaseSensitive?;
    get readerCaseSensitive(): boolean | cdktn.IResolvable;
    set readerCaseSensitive(value: boolean | cdktn.IResolvable);
    resetReaderCaseSensitive(): void;
    get readerCaseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
    private _rescuedDataColumn?;
    get rescuedDataColumn(): string;
    set rescuedDataColumn(value: string);
    resetRescuedDataColumn(): void;
    get rescuedDataColumnInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
    private _singleVariantColumn?;
    get singleVariantColumn(): string;
    set singleVariantColumn(value: string);
    resetSingleVariantColumn(): void;
    get singleVariantColumnInput(): string | undefined;
    private _fileFilters;
    get fileFilters(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFiltersList;
    putFileFilters(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable): void;
    resetFileFilters(): void;
    get fileFiltersInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsFileFilters[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#entity_type Pipeline#entity_type}
    */
    readonly entityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#url Pipeline#url}
    */
    readonly url?: string;
    /**
    * file_ingestion_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_ingestion_options Pipeline#file_ingestion_options}
    */
    readonly fileIngestionOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions | undefined);
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    resetEntityType(): void;
    get entityTypeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _fileIngestionOptions;
    get fileIngestionOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptionsOutputReference;
    putFileIngestionOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions): void;
    resetFileIngestionOptions(): void;
    get fileIngestionOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsFileIngestionOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#resource Pipeline#resource}
    */
    readonly resource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#resource_fields Pipeline#resource_fields}
    */
    readonly resourceFields?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#segments Pipeline#segments}
    */
    readonly segments?: string[];
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions | undefined);
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
    private _resourceFields?;
    get resourceFields(): string[];
    set resourceFields(value: string[]);
    resetResourceFields(): void;
    get resourceFieldsInput(): string[] | undefined;
    private _segments?;
    get segments(): string[];
    set segments(value: string[]);
    resetSegments(): void;
    get segmentsInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#manager_account_id Pipeline#manager_account_id}
    */
    readonly managerAccountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions | undefined);
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _managerAccountId?;
    get managerAccountId(): string;
    set managerAccountId(value: string);
    get managerAccountIdInput(): string | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_jira_spaces Pipeline#include_jira_spaces}
    */
    readonly includeJiraSpaces?: string[];
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions | undefined);
    private _includeJiraSpaces?;
    get includeJiraSpaces(): string[];
    set includeJiraSpaces(value: string[]);
    resetIncludeJiraSpaces(): void;
    get includeJiraSpacesInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions | undefined);
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#as_variant Pipeline#as_variant}
    */
    readonly asVariant?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions | undefined);
    private _asVariant?;
    get asVariant(): boolean | cdktn.IResolvable;
    set asVariant(value: boolean | cdktn.IResolvable);
    resetAsVariant(): void;
    get asVariantInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#desc_file_path Pipeline#desc_file_path}
    */
    readonly descFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#message_name Pipeline#message_name}
    */
    readonly messageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#recursive_fields_max_depth Pipeline#recursive_fields_max_depth}
    */
    readonly recursiveFieldsMaxDepth?: number;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions | undefined);
    private _descFilePath?;
    get descFilePath(): string;
    set descFilePath(value: string);
    resetDescFilePath(): void;
    get descFilePathInput(): string | undefined;
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    resetMessageName(): void;
    get messageNameInput(): string | undefined;
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _recursiveFieldsMaxDepth?;
    get recursiveFieldsMaxDepth(): number;
    set recursiveFieldsMaxDepth(value: number);
    resetRecursiveFieldsMaxDepth(): void;
    get recursiveFieldsMaxDepthInput(): number | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#input_column Pipeline#input_column}
    */
    readonly inputColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#output_column Pipeline#output_column}
    */
    readonly outputColumn?: string;
    /**
    * avro_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#avro_options Pipeline#avro_options}
    */
    readonly avroOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions;
    /**
    * json_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#json_options Pipeline#json_options}
    */
    readonly jsonOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions;
    /**
    * protobuf_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_options Pipeline#protobuf_options}
    */
    readonly protobufOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _inputColumn?;
    get inputColumn(): string;
    set inputColumn(value: string);
    resetInputColumn(): void;
    get inputColumnInput(): string | undefined;
    private _outputColumn?;
    get outputColumn(): string;
    set outputColumn(value: string);
    resetOutputColumn(): void;
    get outputColumnInput(): string | undefined;
    private _avroOptions;
    get avroOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptionsOutputReference;
    putAvroOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions): void;
    resetAvroOptions(): void;
    get avroOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerAvroOptions | undefined;
    private _jsonOptions;
    get jsonOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptionsOutputReference;
    putJsonOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions): void;
    resetJsonOptions(): void;
    get jsonOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerJsonOptions | undefined;
    private _protobufOptions;
    get protobufOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptionsOutputReference;
    putProtobufOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions): void;
    resetProtobufOptions(): void;
    get protobufOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerProtobufOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions | undefined);
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#as_variant Pipeline#as_variant}
    */
    readonly asVariant?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_file_path Pipeline#schema_file_path}
    */
    readonly schemaFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions | undefined);
    private _asVariant?;
    get asVariant(): boolean | cdktn.IResolvable;
    set asVariant(value: boolean | cdktn.IResolvable);
    resetAsVariant(): void;
    get asVariantInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaFilePath?;
    get schemaFilePath(): string;
    set schemaFilePath(value: string);
    resetSchemaFilePath(): void;
    get schemaFilePathInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject Pipeline#subject}
    */
    readonly subject?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined);
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_message_name Pipeline#protobuf_message_name}
    */
    readonly protobufMessageName?: string;
    /**
    * confluent_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#confluent_options Pipeline#confluent_options}
    */
    readonly confluentOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _protobufMessageName?;
    get protobufMessageName(): string;
    set protobufMessageName(value: string);
    resetProtobufMessageName(): void;
    get protobufMessageNameInput(): string | undefined;
    private _confluentOptions;
    get confluentOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptionsOutputReference;
    putConfluentOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions): void;
    resetConfluentOptions(): void;
    get confluentOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryConfluentOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#desc_file_path Pipeline#desc_file_path}
    */
    readonly descFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#message_name Pipeline#message_name}
    */
    readonly messageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#parse_mode Pipeline#parse_mode}
    */
    readonly parseMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#recursive_fields_max_depth Pipeline#recursive_fields_max_depth}
    */
    readonly recursiveFieldsMaxDepth?: number;
    /**
    * schema_registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_registry Pipeline#schema_registry}
    */
    readonly schemaRegistry?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions | undefined);
    private _descFilePath?;
    get descFilePath(): string;
    set descFilePath(value: string);
    resetDescFilePath(): void;
    get descFilePathInput(): string | undefined;
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    resetMessageName(): void;
    get messageNameInput(): string | undefined;
    private _parseMode?;
    get parseMode(): string;
    set parseMode(value: string);
    resetParseMode(): void;
    get parseModeInput(): string | undefined;
    private _recursiveFieldsMaxDepth?;
    get recursiveFieldsMaxDepth(): number;
    set recursiveFieldsMaxDepth(value: number);
    resetRecursiveFieldsMaxDepth(): void;
    get recursiveFieldsMaxDepthInput(): number | undefined;
    private _schemaRegistry;
    get schemaRegistry(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistryOutputReference;
    putSchemaRegistry(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry): void;
    resetSchemaRegistry(): void;
    get schemaRegistryInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsSchemaRegistry | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#input_column Pipeline#input_column}
    */
    readonly inputColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#output_column Pipeline#output_column}
    */
    readonly outputColumn?: string;
    /**
    * avro_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#avro_options Pipeline#avro_options}
    */
    readonly avroOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions;
    /**
    * json_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#json_options Pipeline#json_options}
    */
    readonly jsonOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions;
    /**
    * protobuf_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#protobuf_options Pipeline#protobuf_options}
    */
    readonly protobufOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _inputColumn?;
    get inputColumn(): string;
    set inputColumn(value: string);
    resetInputColumn(): void;
    get inputColumnInput(): string | undefined;
    private _outputColumn?;
    get outputColumn(): string;
    set outputColumn(value: string);
    resetOutputColumn(): void;
    get outputColumnInput(): string | undefined;
    private _avroOptions;
    get avroOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptionsOutputReference;
    putAvroOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions): void;
    resetAvroOptions(): void;
    get avroOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerAvroOptions | undefined;
    private _jsonOptions;
    get jsonOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptionsOutputReference;
    putJsonOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions): void;
    resetJsonOptions(): void;
    get jsonOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerJsonOptions | undefined;
    private _protobufOptions;
    get protobufOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptionsOutputReference;
    putProtobufOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions): void;
    resetProtobufOptions(): void;
    get protobufOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerProtobufOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#client_config Pipeline#client_config}
    */
    readonly clientConfig?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#max_offsets_per_trigger Pipeline#max_offsets_per_trigger}
    */
    readonly maxOffsetsPerTrigger?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#starting_offset Pipeline#starting_offset}
    */
    readonly startingOffset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#topic_pattern Pipeline#topic_pattern}
    */
    readonly topicPattern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#topics Pipeline#topics}
    */
    readonly topics?: string[];
    /**
    * key_transformer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#key_transformer Pipeline#key_transformer}
    */
    readonly keyTransformer?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer;
    /**
    * value_transformer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#value_transformer Pipeline#value_transformer}
    */
    readonly valueTransformer?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions | undefined);
    private _clientConfig?;
    get clientConfig(): {
        [key: string]: string;
    };
    set clientConfig(value: {
        [key: string]: string;
    });
    resetClientConfig(): void;
    get clientConfigInput(): {
        [key: string]: string;
    } | undefined;
    private _maxOffsetsPerTrigger?;
    get maxOffsetsPerTrigger(): number;
    set maxOffsetsPerTrigger(value: number);
    resetMaxOffsetsPerTrigger(): void;
    get maxOffsetsPerTriggerInput(): number | undefined;
    private _startingOffset?;
    get startingOffset(): string;
    set startingOffset(value: string);
    resetStartingOffset(): void;
    get startingOffsetInput(): string | undefined;
    private _topicPattern?;
    get topicPattern(): string;
    set topicPattern(value: string);
    resetTopicPattern(): void;
    get topicPatternInput(): string | undefined;
    private _topics?;
    get topics(): string[];
    set topics(value: string[]);
    resetTopics(): void;
    get topicsInput(): string[] | undefined;
    private _keyTransformer;
    get keyTransformer(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformerOutputReference;
    putKeyTransformer(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer): void;
    resetKeyTransformer(): void;
    get keyTransformerInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsKeyTransformer | undefined;
    private _valueTransformer;
    get valueTransformer(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformerOutputReference;
    putValueTransformer(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer): void;
    resetValueTransformer(): void;
    get valueTransformerInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsValueTransformer | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#entity_granularity Pipeline#entity_granularity}
    */
    readonly entityGranularity?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#finder Pipeline#finder}
    */
    readonly finder: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#time_granularity Pipeline#time_granularity}
    */
    readonly timeGranularity?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions | undefined);
    private _entityGranularity?;
    get entityGranularity(): string[];
    set entityGranularity(value: string[]);
    resetEntityGranularity(): void;
    get entityGranularityInput(): string[] | undefined;
    private _finder?;
    get finder(): string;
    set finder(value: string);
    get finderInput(): string | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _timeGranularity?;
    get timeGranularity(): string;
    set timeGranularity(value: string);
    resetTimeGranularity(): void;
    get timeGranularityInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions | undefined);
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions | undefined);
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_attribution_windows Pipeline#action_attribution_windows}
    */
    readonly actionAttributionWindows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_breakdowns Pipeline#action_breakdowns}
    */
    readonly actionBreakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_report_time Pipeline#action_report_time}
    */
    readonly actionReportTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#breakdowns Pipeline#breakdowns}
    */
    readonly breakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#level Pipeline#level}
    */
    readonly level?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#time_increment Pipeline#time_increment}
    */
    readonly timeIncrement?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions | undefined);
    private _actionAttributionWindows?;
    get actionAttributionWindows(): string[];
    set actionAttributionWindows(value: string[]);
    resetActionAttributionWindows(): void;
    get actionAttributionWindowsInput(): string[] | undefined;
    private _actionBreakdowns?;
    get actionBreakdowns(): string[];
    set actionBreakdowns(value: string[]);
    resetActionBreakdowns(): void;
    get actionBreakdownsInput(): string[] | undefined;
    private _actionReportTime?;
    get actionReportTime(): string;
    set actionReportTime(value: string);
    resetActionReportTime(): void;
    get actionReportTimeInput(): string | undefined;
    private _breakdowns?;
    get breakdowns(): string[];
    set breakdowns(value: string[]);
    resetBreakdowns(): void;
    get breakdownsInput(): string[] | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _timeIncrement?;
    get timeIncrement(): string;
    set timeIncrement(value: string);
    resetTimeIncrement(): void;
    get timeIncrementInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_attribution_windows Pipeline#action_attribution_windows}
    */
    readonly actionAttributionWindows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_breakdowns Pipeline#action_breakdowns}
    */
    readonly actionBreakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#action_report_time Pipeline#action_report_time}
    */
    readonly actionReportTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#breakdowns Pipeline#breakdowns}
    */
    readonly breakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_insights_lookback_window Pipeline#custom_insights_lookback_window}
    */
    readonly customInsightsLookbackWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#level Pipeline#level}
    */
    readonly level?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#start_date Pipeline#start_date}
    */
    readonly startDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#time_increment Pipeline#time_increment}
    */
    readonly timeIncrement?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions | undefined);
    private _actionAttributionWindows?;
    get actionAttributionWindows(): string[];
    set actionAttributionWindows(value: string[]);
    resetActionAttributionWindows(): void;
    get actionAttributionWindowsInput(): string[] | undefined;
    private _actionBreakdowns?;
    get actionBreakdowns(): string[];
    set actionBreakdowns(value: string[]);
    resetActionBreakdowns(): void;
    get actionBreakdownsInput(): string[] | undefined;
    private _actionReportTime?;
    get actionReportTime(): string;
    set actionReportTime(value: string);
    resetActionReportTime(): void;
    get actionReportTimeInput(): string | undefined;
    private _breakdowns?;
    get breakdowns(): string[];
    set breakdowns(value: string[]);
    resetBreakdowns(): void;
    get breakdownsInput(): string[] | undefined;
    private _customInsightsLookbackWindow?;
    get customInsightsLookbackWindow(): number;
    set customInsightsLookbackWindow(value: number);
    resetCustomInsightsLookbackWindow(): void;
    get customInsightsLookbackWindowInput(): number | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    private _timeIncrement?;
    get timeIncrement(): string;
    set timeIncrement(value: string);
    resetTimeIncrement(): void;
    get timeIncrementInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#attachment_mode Pipeline#attachment_mode}
    */
    readonly attachmentMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#body_format Pipeline#body_format}
    */
    readonly bodyFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#folder_filter Pipeline#folder_filter}
    */
    readonly folderFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_folders Pipeline#include_folders}
    */
    readonly includeFolders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_mailboxes Pipeline#include_mailboxes}
    */
    readonly includeMailboxes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_senders Pipeline#include_senders}
    */
    readonly includeSenders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#include_subjects Pipeline#include_subjects}
    */
    readonly includeSubjects?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sender_filter Pipeline#sender_filter}
    */
    readonly senderFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#start_date Pipeline#start_date}
    */
    readonly startDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#subject_filter Pipeline#subject_filter}
    */
    readonly subjectFilter?: string[];
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions | undefined);
    private _attachmentMode?;
    get attachmentMode(): string;
    set attachmentMode(value: string);
    resetAttachmentMode(): void;
    get attachmentModeInput(): string | undefined;
    private _bodyFormat?;
    get bodyFormat(): string;
    set bodyFormat(value: string);
    resetBodyFormat(): void;
    get bodyFormatInput(): string | undefined;
    private _folderFilter?;
    get folderFilter(): string[];
    set folderFilter(value: string[]);
    resetFolderFilter(): void;
    get folderFilterInput(): string[] | undefined;
    private _includeFolders?;
    get includeFolders(): string[];
    set includeFolders(value: string[]);
    resetIncludeFolders(): void;
    get includeFoldersInput(): string[] | undefined;
    private _includeMailboxes?;
    get includeMailboxes(): string[];
    set includeMailboxes(value: string[]);
    resetIncludeMailboxes(): void;
    get includeMailboxesInput(): string[] | undefined;
    private _includeSenders?;
    get includeSenders(): string[];
    set includeSenders(value: string[]);
    resetIncludeSenders(): void;
    get includeSendersInput(): string[] | undefined;
    private _includeSubjects?;
    get includeSubjects(): string[];
    set includeSubjects(value: string[]);
    resetIncludeSubjects(): void;
    get includeSubjectsInput(): string[] | undefined;
    private _senderFilter?;
    get senderFilter(): string[];
    set senderFilter(value: string[]);
    resetSenderFilter(): void;
    get senderFilterInput(): string[] | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    private _subjectFilter?;
    get subjectFilter(): string[];
    set subjectFilter(value: string[]);
    resetSubjectFilter(): void;
    get subjectFilterInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#queue Pipeline#queue}
    */
    readonly queue: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions | undefined);
    private _queue?;
    get queue(): string;
    set queue(value: string);
    get queueInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#breakdowns Pipeline#breakdowns}
    */
    readonly breakdowns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#fields Pipeline#fields}
    */
    readonly fields?: string[];
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions | undefined);
    private _breakdowns?;
    get breakdowns(): string[];
    set breakdowns(value: string[]);
    resetBreakdowns(): void;
    get breakdownsInput(): string[] | undefined;
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    resetFields(): void;
    get fieldsInput(): string[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions | undefined);
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_after Pipeline#modified_after}
    */
    readonly modifiedAfter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#modified_before Pipeline#modified_before}
    */
    readonly modifiedBefore?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#path_filter Pipeline#path_filter}
    */
    readonly pathFilter?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters | cdktn.IResolvable | undefined);
    private _modifiedAfter?;
    get modifiedAfter(): string;
    set modifiedAfter(value: string);
    resetModifiedAfter(): void;
    get modifiedAfterInput(): string | undefined;
    private _modifiedBefore?;
    get modifiedBefore(): string;
    set modifiedBefore(value: string);
    resetModifiedBefore(): void;
    get modifiedBeforeInput(): string | undefined;
    private _pathFilter?;
    get pathFilter(): string;
    set pathFilter(value: string);
    resetPathFilter(): void;
    get pathFilterInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersOutputReference;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#corrupt_record_column Pipeline#corrupt_record_column}
    */
    readonly corruptRecordColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format Pipeline#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#format_options Pipeline#format_options}
    */
    readonly formatOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#ignore_corrupt_files Pipeline#ignore_corrupt_files}
    */
    readonly ignoreCorruptFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#infer_column_types Pipeline#infer_column_types}
    */
    readonly inferColumnTypes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#reader_case_sensitive Pipeline#reader_case_sensitive}
    */
    readonly readerCaseSensitive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#rescued_data_column Pipeline#rescued_data_column}
    */
    readonly rescuedDataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_evolution_mode Pipeline#schema_evolution_mode}
    */
    readonly schemaEvolutionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#schema_hints Pipeline#schema_hints}
    */
    readonly schemaHints?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#single_variant_column Pipeline#single_variant_column}
    */
    readonly singleVariantColumn?: string;
    /**
    * file_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_filters Pipeline#file_filters}
    */
    readonly fileFilters?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions | undefined);
    private _corruptRecordColumn?;
    get corruptRecordColumn(): string;
    set corruptRecordColumn(value: string);
    resetCorruptRecordColumn(): void;
    get corruptRecordColumnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _formatOptions?;
    get formatOptions(): {
        [key: string]: string;
    };
    set formatOptions(value: {
        [key: string]: string;
    });
    resetFormatOptions(): void;
    get formatOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _ignoreCorruptFiles?;
    get ignoreCorruptFiles(): boolean | cdktn.IResolvable;
    set ignoreCorruptFiles(value: boolean | cdktn.IResolvable);
    resetIgnoreCorruptFiles(): void;
    get ignoreCorruptFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _inferColumnTypes?;
    get inferColumnTypes(): boolean | cdktn.IResolvable;
    set inferColumnTypes(value: boolean | cdktn.IResolvable);
    resetInferColumnTypes(): void;
    get inferColumnTypesInput(): boolean | cdktn.IResolvable | undefined;
    private _readerCaseSensitive?;
    get readerCaseSensitive(): boolean | cdktn.IResolvable;
    set readerCaseSensitive(value: boolean | cdktn.IResolvable);
    resetReaderCaseSensitive(): void;
    get readerCaseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
    private _rescuedDataColumn?;
    get rescuedDataColumn(): string;
    set rescuedDataColumn(value: string);
    resetRescuedDataColumn(): void;
    get rescuedDataColumnInput(): string | undefined;
    private _schemaEvolutionMode?;
    get schemaEvolutionMode(): string;
    set schemaEvolutionMode(value: string);
    resetSchemaEvolutionMode(): void;
    get schemaEvolutionModeInput(): string | undefined;
    private _schemaHints?;
    get schemaHints(): string;
    set schemaHints(value: string);
    resetSchemaHints(): void;
    get schemaHintsInput(): string | undefined;
    private _singleVariantColumn?;
    get singleVariantColumn(): string;
    set singleVariantColumn(value: string);
    resetSingleVariantColumn(): void;
    get singleVariantColumnInput(): string | undefined;
    private _fileFilters;
    get fileFilters(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFiltersList;
    putFileFilters(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | cdktn.IResolvable): void;
    resetFileFilters(): void;
    get fileFiltersInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsFileFilters[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#entity_type Pipeline#entity_type}
    */
    readonly entityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#url Pipeline#url}
    */
    readonly url?: string;
    /**
    * file_ingestion_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#file_ingestion_options Pipeline#file_ingestion_options}
    */
    readonly fileIngestionOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions | undefined);
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    resetEntityType(): void;
    get entityTypeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _fileIngestionOptions;
    get fileIngestionOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptionsOutputReference;
    putFileIngestionOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions): void;
    resetFileIngestionOptions(): void;
    get fileIngestionOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsFileIngestionOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#enforce_schema Pipeline#enforce_schema}
    */
    readonly enforceSchema?: boolean | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions | undefined);
    private _enforceSchema?;
    get enforceSchema(): boolean | cdktn.IResolvable;
    set enforceSchema(value: boolean | cdktn.IResolvable);
    resetEnforceSchema(): void;
    get enforceSchemaInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#data_level Pipeline#data_level}
    */
    readonly dataLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#dimensions Pipeline#dimensions}
    */
    readonly dimensions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#query_lifetime Pipeline#query_lifetime}
    */
    readonly queryLifetime?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#report_type Pipeline#report_type}
    */
    readonly reportType?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions | undefined);
    private _dataLevel?;
    get dataLevel(): string;
    set dataLevel(value: string);
    resetDataLevel(): void;
    get dataLevelInput(): string | undefined;
    private _dimensions?;
    get dimensions(): string[];
    set dimensions(value: string[]);
    resetDimensions(): void;
    get dimensionsInput(): string[] | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _queryLifetime?;
    get queryLifetime(): boolean | cdktn.IResolvable;
    set queryLifetime(value: boolean | cdktn.IResolvable);
    resetQueryLifetime(): void;
    get queryLifetimeInput(): boolean | cdktn.IResolvable | undefined;
    private _reportType?;
    get reportType(): string;
    set reportType(value: string);
    resetReportType(): void;
    get reportTypeInput(): string | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#data_level Pipeline#data_level}
    */
    readonly dataLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#dimensions Pipeline#dimensions}
    */
    readonly dimensions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#lookback_window_days Pipeline#lookback_window_days}
    */
    readonly lookbackWindowDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#metrics Pipeline#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#query_lifetime Pipeline#query_lifetime}
    */
    readonly queryLifetime?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#report_type Pipeline#report_type}
    */
    readonly reportType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#sync_start_date Pipeline#sync_start_date}
    */
    readonly syncStartDate?: string;
    /**
    * custom_report_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#custom_report_options Pipeline#custom_report_options}
    */
    readonly customReportOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions | undefined);
    private _dataLevel?;
    get dataLevel(): string;
    set dataLevel(value: string);
    resetDataLevel(): void;
    get dataLevelInput(): string | undefined;
    private _dimensions?;
    get dimensions(): string[];
    set dimensions(value: string[]);
    resetDimensions(): void;
    get dimensionsInput(): string[] | undefined;
    private _lookbackWindowDays?;
    get lookbackWindowDays(): number;
    set lookbackWindowDays(value: number);
    resetLookbackWindowDays(): void;
    get lookbackWindowDaysInput(): number | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _queryLifetime?;
    get queryLifetime(): boolean | cdktn.IResolvable;
    set queryLifetime(value: boolean | cdktn.IResolvable);
    resetQueryLifetime(): void;
    get queryLifetimeInput(): boolean | cdktn.IResolvable | undefined;
    private _reportType?;
    get reportType(): string;
    set reportType(value: string);
    resetReportType(): void;
    get reportTypeInput(): string | undefined;
    private _syncStartDate?;
    get syncStartDate(): string;
    set syncStartDate(value: string);
    resetSyncStartDate(): void;
    get syncStartDateInput(): string | undefined;
    private _customReportOptions;
    get customReportOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptionsOutputReference;
    putCustomReportOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions): void;
    resetCustomReportOptions(): void;
    get customReportOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsCustomReportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.135.0/docs/resources/pipeline#start_date Pipeline#start_date}
    */
    readonly startDate?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions | undefined);
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
}
