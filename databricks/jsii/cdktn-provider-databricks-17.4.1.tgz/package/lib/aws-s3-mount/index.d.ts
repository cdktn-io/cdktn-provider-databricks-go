/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3MountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount#cluster_id AwsS3Mount#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount#id AwsS3Mount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount#instance_profile AwsS3Mount#instance_profile}
    */
    readonly instanceProfile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount#mount_name AwsS3Mount#mount_name}
    */
    readonly mountName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount#s3_bucket_name AwsS3Mount#s3_bucket_name}
    */
    readonly s3BucketName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount databricks_aws_s3_mount}
*/
export declare class AwsS3Mount extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_aws_s3_mount";
    /**
    * Generates CDKTN code for importing a AwsS3Mount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3Mount to import
    * @param importFromId The id of the existing AwsS3Mount that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3Mount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/aws_s3_mount databricks_aws_s3_mount} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3MountConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3MountConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfile?;
    get instanceProfile(): string;
    set instanceProfile(value: string);
    resetInstanceProfile(): void;
    get instanceProfileInput(): string | undefined;
    private _mountName?;
    get mountName(): string;
    set mountName(value: string);
    get mountNameInput(): string | undefined;
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    get s3BucketNameInput(): string | undefined;
    get source(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
