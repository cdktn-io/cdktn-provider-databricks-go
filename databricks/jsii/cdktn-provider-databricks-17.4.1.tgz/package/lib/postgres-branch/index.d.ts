/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresBranchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#branch_id PostgresBranch#branch_id}
    */
    readonly branchId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#parent PostgresBranch#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#provider_config PostgresBranch#provider_config}
    */
    readonly providerConfig?: PostgresBranchProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#purge_on_delete PostgresBranch#purge_on_delete}
    */
    readonly purgeOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#replace_existing PostgresBranch#replace_existing}
    */
    readonly replaceExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#spec PostgresBranch#spec}
    */
    readonly spec?: PostgresBranchSpec;
}
export interface PostgresBranchProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#workspace_id PostgresBranch#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresBranchProviderConfigToTerraform(struct?: PostgresBranchProviderConfig | cdktn.IResolvable): any;
export declare function postgresBranchProviderConfigToHclTerraform(struct?: PostgresBranchProviderConfig | cdktn.IResolvable): any;
export declare class PostgresBranchProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresBranchProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresBranchProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresBranchSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#expire_time PostgresBranch#expire_time}
    */
    readonly expireTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#is_protected PostgresBranch#is_protected}
    */
    readonly isProtected?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#no_expiry PostgresBranch#no_expiry}
    */
    readonly noExpiry?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#source_branch PostgresBranch#source_branch}
    */
    readonly sourceBranch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#source_branch_lsn PostgresBranch#source_branch_lsn}
    */
    readonly sourceBranchLsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#source_branch_time PostgresBranch#source_branch_time}
    */
    readonly sourceBranchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#ttl PostgresBranch#ttl}
    */
    readonly ttl?: string;
}
export declare function postgresBranchSpecToTerraform(struct?: PostgresBranchSpec | cdktn.IResolvable): any;
export declare function postgresBranchSpecToHclTerraform(struct?: PostgresBranchSpec | cdktn.IResolvable): any;
export declare class PostgresBranchSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresBranchSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresBranchSpec | cdktn.IResolvable | undefined);
    private _expireTime?;
    get expireTime(): string;
    set expireTime(value: string);
    resetExpireTime(): void;
    get expireTimeInput(): string | undefined;
    private _isProtected?;
    get isProtected(): boolean | cdktn.IResolvable;
    set isProtected(value: boolean | cdktn.IResolvable);
    resetIsProtected(): void;
    get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
    private _noExpiry?;
    get noExpiry(): boolean | cdktn.IResolvable;
    set noExpiry(value: boolean | cdktn.IResolvable);
    resetNoExpiry(): void;
    get noExpiryInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceBranch?;
    get sourceBranch(): string;
    set sourceBranch(value: string);
    resetSourceBranch(): void;
    get sourceBranchInput(): string | undefined;
    private _sourceBranchLsn?;
    get sourceBranchLsn(): string;
    set sourceBranchLsn(value: string);
    resetSourceBranchLsn(): void;
    get sourceBranchLsnInput(): string | undefined;
    private _sourceBranchTime?;
    get sourceBranchTime(): string;
    set sourceBranchTime(value: string);
    resetSourceBranchTime(): void;
    get sourceBranchTimeInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
}
export interface PostgresBranchStatus {
}
export declare function postgresBranchStatusToTerraform(struct?: PostgresBranchStatus): any;
export declare function postgresBranchStatusToHclTerraform(struct?: PostgresBranchStatus): any;
export declare class PostgresBranchStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresBranchStatus | undefined;
    set internalValue(value: PostgresBranchStatus | undefined);
    get branchId(): string;
    get currentState(): string;
    get default(): cdktn.IResolvable;
    get deleteTime(): string;
    get expireTime(): string;
    get isProtected(): cdktn.IResolvable;
    get logicalSizeBytes(): number;
    get pendingState(): string;
    get purgeTime(): string;
    get sourceBranch(): string;
    get sourceBranchLsn(): string;
    get sourceBranchTime(): string;
    get stateChangeTime(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch databricks_postgres_branch}
*/
export declare class PostgresBranch extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_branch";
    /**
    * Generates CDKTN code for importing a PostgresBranch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresBranch to import
    * @param importFromId The id of the existing PostgresBranch that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresBranch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/postgres_branch databricks_postgres_branch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresBranchConfig
    */
    constructor(scope: Construct, id: string, config: PostgresBranchConfig);
    private _branchId?;
    get branchId(): string;
    set branchId(value: string);
    get branchIdInput(): string | undefined;
    get createTime(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresBranchProviderConfigOutputReference;
    putProviderConfig(value: PostgresBranchProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresBranchProviderConfig | undefined;
    private _purgeOnDelete?;
    get purgeOnDelete(): boolean | cdktn.IResolvable;
    set purgeOnDelete(value: boolean | cdktn.IResolvable);
    resetPurgeOnDelete(): void;
    get purgeOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _replaceExisting?;
    get replaceExisting(): boolean | cdktn.IResolvable;
    set replaceExisting(value: boolean | cdktn.IResolvable);
    resetReplaceExisting(): void;
    get replaceExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _spec;
    get spec(): PostgresBranchSpecOutputReference;
    putSpec(value: PostgresBranchSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresBranchSpec | undefined;
    private _status;
    get status(): PostgresBranchStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
