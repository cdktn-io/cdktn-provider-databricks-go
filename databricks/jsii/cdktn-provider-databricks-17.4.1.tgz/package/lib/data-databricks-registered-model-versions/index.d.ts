/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksRegisteredModelVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#full_name DataDatabricksRegisteredModelVersions#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#model_versions DataDatabricksRegisteredModelVersions#model_versions}
    */
    readonly modelVersions?: DataDatabricksRegisteredModelVersionsModelVersions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#provider_config DataDatabricksRegisteredModelVersions#provider_config}
    */
    readonly providerConfig?: DataDatabricksRegisteredModelVersionsProviderConfig;
}
export interface DataDatabricksRegisteredModelVersionsModelVersionsAliases {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#alias_name DataDatabricksRegisteredModelVersions#alias_name}
    */
    readonly aliasName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#catalog_name DataDatabricksRegisteredModelVersions#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#id DataDatabricksRegisteredModelVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#model_name DataDatabricksRegisteredModelVersions#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#schema_name DataDatabricksRegisteredModelVersions#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#version_num DataDatabricksRegisteredModelVersions#version_num}
    */
    readonly versionNum?: number;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsAliasesToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsAliases | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsAliasesToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsAliases | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsAliasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersionsAliases | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersionsAliases | cdktn.IResolvable | undefined);
    private _aliasName?;
    get aliasName(): string;
    set aliasName(value: string);
    resetAliasName(): void;
    get aliasNameInput(): string | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _versionNum?;
    get versionNum(): number;
    set versionNum(value: number);
    resetVersionNum(): void;
    get versionNumInput(): number | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsAliasesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersionsAliases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsAliasesOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#connection_name DataDatabricksRegisteredModelVersions#connection_name}
    */
    readonly connectionName?: string;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnectionToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnectionToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection | cdktn.IResolvable | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnectionList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnectionOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#credential_name DataDatabricksRegisteredModelVersions#credential_name}
    */
    readonly credentialName?: string;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredentialToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredentialToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential | cdktn.IResolvable | undefined);
    private _credentialName?;
    get credentialName(): string;
    set credentialName(value: string);
    resetCredentialName(): void;
    get credentialNameInput(): string | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredentialList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredentialOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#function_full_name DataDatabricksRegisteredModelVersions#function_full_name}
    */
    readonly functionFullName: string;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunctionToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunctionToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction | cdktn.IResolvable | undefined);
    private _functionFullName?;
    get functionFullName(): string;
    set functionFullName(value: string);
    get functionFullNameInput(): string | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunctionList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunctionOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#table_full_name DataDatabricksRegisteredModelVersions#table_full_name}
    */
    readonly tableFullName: string;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTableToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTableToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable | cdktn.IResolvable | undefined);
    private _tableFullName?;
    get tableFullName(): string;
    set tableFullName(value: string);
    get tableFullNameInput(): string | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTableList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTableOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#connection DataDatabricksRegisteredModelVersions#connection}
    */
    readonly connection?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#credential DataDatabricksRegisteredModelVersions#credential}
    */
    readonly credential?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#function DataDatabricksRegisteredModelVersions#function}
    */
    readonly function?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#table DataDatabricksRegisteredModelVersions#table}
    */
    readonly table?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable[] | cdktn.IResolvable;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies | cdktn.IResolvable | undefined);
    private _connection;
    get connection(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnectionList;
    putConnection(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection[] | cdktn.IResolvable): void;
    resetConnection(): void;
    get connectionInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesConnection[] | undefined;
    private _credential;
    get credential(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredentialList;
    putCredential(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential[] | cdktn.IResolvable): void;
    resetCredential(): void;
    get credentialInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesCredential[] | undefined;
    private _function;
    get function(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunctionList;
    putFunction(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction[] | cdktn.IResolvable): void;
    resetFunction(): void;
    get functionInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesFunction[] | undefined;
    private _table;
    get table(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTableList;
    putTable(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable[] | cdktn.IResolvable): void;
    resetTable(): void;
    get tableInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesTable[] | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#dependencies DataDatabricksRegisteredModelVersions#dependencies}
    */
    readonly dependencies?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies[] | cdktn.IResolvable;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies | cdktn.IResolvable | undefined);
    private _dependencies;
    get dependencies(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependenciesList;
    putDependencies(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies[] | cdktn.IResolvable): void;
    resetDependencies(): void;
    get dependenciesInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesDependencies[] | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsModelVersions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#aliases DataDatabricksRegisteredModelVersions#aliases}
    */
    readonly aliases?: DataDatabricksRegisteredModelVersionsModelVersionsAliases[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#catalog_name DataDatabricksRegisteredModelVersions#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#comment DataDatabricksRegisteredModelVersions#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#created_at DataDatabricksRegisteredModelVersions#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#created_by DataDatabricksRegisteredModelVersions#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#id DataDatabricksRegisteredModelVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#metastore_id DataDatabricksRegisteredModelVersions#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#model_name DataDatabricksRegisteredModelVersions#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#model_version_dependencies DataDatabricksRegisteredModelVersions#model_version_dependencies}
    */
    readonly modelVersionDependencies?: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#run_id DataDatabricksRegisteredModelVersions#run_id}
    */
    readonly runId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#run_workspace_id DataDatabricksRegisteredModelVersions#run_workspace_id}
    */
    readonly runWorkspaceId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#schema_name DataDatabricksRegisteredModelVersions#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#source DataDatabricksRegisteredModelVersions#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#status DataDatabricksRegisteredModelVersions#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#storage_location DataDatabricksRegisteredModelVersions#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#updated_at DataDatabricksRegisteredModelVersions#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#updated_by DataDatabricksRegisteredModelVersions#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#version DataDatabricksRegisteredModelVersions#version}
    */
    readonly version?: number;
}
export declare function dataDatabricksRegisteredModelVersionsModelVersionsToTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersions | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsModelVersionsToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsModelVersions | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelVersionsModelVersions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsModelVersions | cdktn.IResolvable | undefined);
    private _aliases;
    get aliases(): DataDatabricksRegisteredModelVersionsModelVersionsAliasesList;
    putAliases(value: DataDatabricksRegisteredModelVersionsModelVersionsAliases[] | cdktn.IResolvable): void;
    resetAliases(): void;
    get aliasesInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersionsAliases[] | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _modelVersionDependencies;
    get modelVersionDependencies(): DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependenciesList;
    putModelVersionDependencies(value: DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies[] | cdktn.IResolvable): void;
    resetModelVersionDependencies(): void;
    get modelVersionDependenciesInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersionsModelVersionDependencies[] | undefined;
    private _runId?;
    get runId(): string;
    set runId(value: string);
    resetRunId(): void;
    get runIdInput(): string | undefined;
    private _runWorkspaceId?;
    get runWorkspaceId(): number;
    set runWorkspaceId(value: number);
    resetRunWorkspaceId(): void;
    get runWorkspaceIdInput(): number | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _version?;
    get version(): number;
    set version(value: number);
    resetVersion(): void;
    get versionInput(): number | undefined;
}
export declare class DataDatabricksRegisteredModelVersionsModelVersionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelVersionsModelVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelVersionsModelVersionsOutputReference;
}
export interface DataDatabricksRegisteredModelVersionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#workspace_id DataDatabricksRegisteredModelVersions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksRegisteredModelVersionsProviderConfigToTerraform(struct?: DataDatabricksRegisteredModelVersionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelVersionsProviderConfigToHclTerraform(struct?: DataDatabricksRegisteredModelVersionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelVersionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksRegisteredModelVersionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelVersionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions databricks_registered_model_versions}
*/
export declare class DataDatabricksRegisteredModelVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_registered_model_versions";
    /**
    * Generates CDKTN code for importing a DataDatabricksRegisteredModelVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksRegisteredModelVersions to import
    * @param importFromId The id of the existing DataDatabricksRegisteredModelVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksRegisteredModelVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/registered_model_versions databricks_registered_model_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksRegisteredModelVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksRegisteredModelVersionsConfig);
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _modelVersions;
    get modelVersions(): DataDatabricksRegisteredModelVersionsModelVersionsList;
    putModelVersions(value: DataDatabricksRegisteredModelVersionsModelVersions[] | cdktn.IResolvable): void;
    resetModelVersions(): void;
    get modelVersionsInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsModelVersions[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksRegisteredModelVersionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksRegisteredModelVersionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksRegisteredModelVersionsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
