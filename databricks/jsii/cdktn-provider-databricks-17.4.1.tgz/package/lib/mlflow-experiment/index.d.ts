/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MlflowExperimentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#artifact_location MlflowExperiment#artifact_location}
    */
    readonly artifactLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#creation_time MlflowExperiment#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#description MlflowExperiment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#experiment_id MlflowExperiment#experiment_id}
    */
    readonly experimentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#id MlflowExperiment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#last_update_time MlflowExperiment#last_update_time}
    */
    readonly lastUpdateTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#lifecycle_stage MlflowExperiment#lifecycle_stage}
    */
    readonly lifecycleStage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#name MlflowExperiment#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#provider_config MlflowExperiment#provider_config}
    */
    readonly providerConfig?: MlflowExperimentProviderConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#tags MlflowExperiment#tags}
    */
    readonly tags?: MlflowExperimentTags[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#timeouts MlflowExperiment#timeouts}
    */
    readonly timeouts?: MlflowExperimentTimeouts;
}
export interface MlflowExperimentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#workspace_id MlflowExperiment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function mlflowExperimentProviderConfigToTerraform(struct?: MlflowExperimentProviderConfigOutputReference | MlflowExperimentProviderConfig): any;
export declare function mlflowExperimentProviderConfigToHclTerraform(struct?: MlflowExperimentProviderConfigOutputReference | MlflowExperimentProviderConfig): any;
export declare class MlflowExperimentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MlflowExperimentProviderConfig | undefined;
    set internalValue(value: MlflowExperimentProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface MlflowExperimentTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#key MlflowExperiment#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#value MlflowExperiment#value}
    */
    readonly value?: string;
}
export declare function mlflowExperimentTagsToTerraform(struct?: MlflowExperimentTags | cdktn.IResolvable): any;
export declare function mlflowExperimentTagsToHclTerraform(struct?: MlflowExperimentTags | cdktn.IResolvable): any;
export declare class MlflowExperimentTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MlflowExperimentTags | cdktn.IResolvable | undefined;
    set internalValue(value: MlflowExperimentTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class MlflowExperimentTagsList extends cdktn.ComplexList {
    internalValue?: MlflowExperimentTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MlflowExperimentTagsOutputReference;
}
export interface MlflowExperimentTimeouts {
}
export declare function mlflowExperimentTimeoutsToTerraform(struct?: MlflowExperimentTimeouts | cdktn.IResolvable): any;
export declare function mlflowExperimentTimeoutsToHclTerraform(struct?: MlflowExperimentTimeouts | cdktn.IResolvable): any;
export declare class MlflowExperimentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MlflowExperimentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: MlflowExperimentTimeouts | cdktn.IResolvable | undefined);
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment databricks_mlflow_experiment}
*/
export declare class MlflowExperiment extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mlflow_experiment";
    /**
    * Generates CDKTN code for importing a MlflowExperiment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MlflowExperiment to import
    * @param importFromId The id of the existing MlflowExperiment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MlflowExperiment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/mlflow_experiment databricks_mlflow_experiment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MlflowExperimentConfig
    */
    constructor(scope: Construct, id: string, config: MlflowExperimentConfig);
    private _artifactLocation?;
    get artifactLocation(): string;
    set artifactLocation(value: string);
    resetArtifactLocation(): void;
    get artifactLocationInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    resetExperimentId(): void;
    get experimentIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastUpdateTime?;
    get lastUpdateTime(): number;
    set lastUpdateTime(value: number);
    resetLastUpdateTime(): void;
    get lastUpdateTimeInput(): number | undefined;
    private _lifecycleStage?;
    get lifecycleStage(): string;
    set lifecycleStage(value: string);
    resetLifecycleStage(): void;
    get lifecycleStageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): MlflowExperimentProviderConfigOutputReference;
    putProviderConfig(value: MlflowExperimentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): MlflowExperimentProviderConfig | undefined;
    private _tags;
    get tags(): MlflowExperimentTagsList;
    putTags(value: MlflowExperimentTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | MlflowExperimentTags[] | undefined;
    private _timeouts;
    get timeouts(): MlflowExperimentTimeoutsOutputReference;
    putTimeouts(value: MlflowExperimentTimeouts): void;
    get timeoutsInput(): cdktn.IResolvable | MlflowExperimentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
