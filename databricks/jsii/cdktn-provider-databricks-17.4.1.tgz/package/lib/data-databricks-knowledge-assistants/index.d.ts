/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksKnowledgeAssistantsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants#page_size DataDatabricksKnowledgeAssistants#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants#provider_config DataDatabricksKnowledgeAssistants#provider_config}
    */
    readonly providerConfig?: DataDatabricksKnowledgeAssistantsProviderConfig;
}
export interface DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants#workspace_id DataDatabricksKnowledgeAssistants#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfigToTerraform(struct?: DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfigToHclTerraform(struct?: DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantsKnowledgeAssistants {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants#name DataDatabricksKnowledgeAssistants#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants#provider_config DataDatabricksKnowledgeAssistants#provider_config}
    */
    readonly providerConfig?: DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig;
}
export declare function dataDatabricksKnowledgeAssistantsKnowledgeAssistantsToTerraform(struct?: DataDatabricksKnowledgeAssistantsKnowledgeAssistants): any;
export declare function dataDatabricksKnowledgeAssistantsKnowledgeAssistantsToHclTerraform(struct?: DataDatabricksKnowledgeAssistantsKnowledgeAssistants): any;
export declare class DataDatabricksKnowledgeAssistantsKnowledgeAssistantsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksKnowledgeAssistantsKnowledgeAssistants | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantsKnowledgeAssistants | undefined);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get displayName(): string;
    get endpointName(): string;
    get errorInfo(): string;
    get experimentId(): string;
    get id(): string;
    get instructions(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksKnowledgeAssistantsKnowledgeAssistantsProviderConfig | undefined;
    get state(): string;
}
export declare class DataDatabricksKnowledgeAssistantsKnowledgeAssistantsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksKnowledgeAssistantsKnowledgeAssistants[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksKnowledgeAssistantsKnowledgeAssistantsOutputReference;
}
export interface DataDatabricksKnowledgeAssistantsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants#workspace_id DataDatabricksKnowledgeAssistants#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksKnowledgeAssistantsProviderConfigToTerraform(struct?: DataDatabricksKnowledgeAssistantsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksKnowledgeAssistantsProviderConfigToHclTerraform(struct?: DataDatabricksKnowledgeAssistantsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksKnowledgeAssistantsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants databricks_knowledge_assistants}
*/
export declare class DataDatabricksKnowledgeAssistants extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_knowledge_assistants";
    /**
    * Generates CDKTN code for importing a DataDatabricksKnowledgeAssistants resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksKnowledgeAssistants to import
    * @param importFromId The id of the existing DataDatabricksKnowledgeAssistants that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksKnowledgeAssistants to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistants databricks_knowledge_assistants} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksKnowledgeAssistantsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksKnowledgeAssistantsConfig);
    private _knowledgeAssistants;
    get knowledgeAssistants(): DataDatabricksKnowledgeAssistantsKnowledgeAssistantsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksKnowledgeAssistantsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksKnowledgeAssistantsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksKnowledgeAssistantsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
