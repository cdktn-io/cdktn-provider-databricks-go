/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSqlWarehousesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses#id DataDatabricksSqlWarehouses#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses#ids DataDatabricksSqlWarehouses#ids}
    */
    readonly ids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses#warehouse_name_contains DataDatabricksSqlWarehouses#warehouse_name_contains}
    */
    readonly warehouseNameContains?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses#provider_config DataDatabricksSqlWarehouses#provider_config}
    */
    readonly providerConfig?: DataDatabricksSqlWarehousesProviderConfig;
}
export interface DataDatabricksSqlWarehousesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses#workspace_id DataDatabricksSqlWarehouses#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSqlWarehousesProviderConfigToTerraform(struct?: DataDatabricksSqlWarehousesProviderConfigOutputReference | DataDatabricksSqlWarehousesProviderConfig): any;
export declare function dataDatabricksSqlWarehousesProviderConfigToHclTerraform(struct?: DataDatabricksSqlWarehousesProviderConfigOutputReference | DataDatabricksSqlWarehousesProviderConfig): any;
export declare class DataDatabricksSqlWarehousesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSqlWarehousesProviderConfig | undefined;
    set internalValue(value: DataDatabricksSqlWarehousesProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses databricks_sql_warehouses}
*/
export declare class DataDatabricksSqlWarehouses extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_sql_warehouses";
    /**
    * Generates CDKTN code for importing a DataDatabricksSqlWarehouses resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSqlWarehouses to import
    * @param importFromId The id of the existing DataDatabricksSqlWarehouses that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSqlWarehouses to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/sql_warehouses databricks_sql_warehouses} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSqlWarehousesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksSqlWarehousesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _warehouseNameContains?;
    get warehouseNameContains(): string;
    set warehouseNameContains(value: string);
    resetWarehouseNameContains(): void;
    get warehouseNameContainsInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSqlWarehousesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSqlWarehousesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksSqlWarehousesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
