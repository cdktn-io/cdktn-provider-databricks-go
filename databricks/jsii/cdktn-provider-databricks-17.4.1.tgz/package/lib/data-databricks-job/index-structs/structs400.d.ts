/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptionsList, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOnList, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotificationsOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryList, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettingsOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask, DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskConditionTask, DataDatabricksJobJobSettingsSettingsTaskConditionTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskDashboardTask, DataDatabricksJobJobSettingsSettingsTaskDashboardTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskDbtTask, DataDatabricksJobJobSettingsSettingsTaskDbtTaskOutputReference, DataDatabricksJobJobSettingsSettingsTaskDependsOn, DataDatabricksJobJobSettingsSettingsTaskDependsOnList, DataDatabricksJobJobSettingsSettingsTaskEmailNotifications, DataDatabricksJobJobSettingsSettingsTaskEmailNotificationsOutputReference, DataDatabricksJobJobSettingsSettingsContinuous, DataDatabricksJobJobSettingsSettingsContinuousOutputReference, DataDatabricksJobJobSettingsSettingsDbtTask, DataDatabricksJobJobSettingsSettingsDbtTaskOutputReference, DataDatabricksJobJobSettingsSettingsDeployment, DataDatabricksJobJobSettingsSettingsDeploymentOutputReference, DataDatabricksJobJobSettingsSettingsEmailNotifications, DataDatabricksJobJobSettingsSettingsEmailNotificationsOutputReference, DataDatabricksJobJobSettingsSettingsEnvironment, DataDatabricksJobJobSettingsSettingsEnvironmentList, DataDatabricksJobJobSettingsSettingsGitSource, DataDatabricksJobJobSettingsSettingsGitSourceOutputReference, DataDatabricksJobJobSettingsSettingsHealth, DataDatabricksJobJobSettingsSettingsHealthOutputReference, DataDatabricksJobJobSettingsSettingsJobCluster, DataDatabricksJobJobSettingsSettingsJobClusterList, DataDatabricksJobJobSettingsSettingsLibrary, DataDatabricksJobJobSettingsSettingsLibraryList, DataDatabricksJobJobSettingsSettingsNewCluster, DataDatabricksJobJobSettingsSettingsNewClusterOutputReference, DataDatabricksJobJobSettingsSettingsNotebookTask, DataDatabricksJobJobSettingsSettingsNotebookTaskOutputReference, DataDatabricksJobJobSettingsSettingsNotificationSettings, DataDatabricksJobJobSettingsSettingsNotificationSettingsOutputReference, DataDatabricksJobJobSettingsSettingsParameter, DataDatabricksJobJobSettingsSettingsParameterList, DataDatabricksJobJobSettingsSettingsPipelineTask, DataDatabricksJobJobSettingsSettingsPipelineTaskOutputReference, DataDatabricksJobJobSettingsSettingsPythonWheelTask, DataDatabricksJobJobSettingsSettingsPythonWheelTaskOutputReference, DataDatabricksJobJobSettingsSettingsQueue, DataDatabricksJobJobSettingsSettingsQueueOutputReference, DataDatabricksJobJobSettingsSettingsRunAs, DataDatabricksJobJobSettingsSettingsRunAsOutputReference, DataDatabricksJobJobSettingsSettingsRunJobTask, DataDatabricksJobJobSettingsSettingsRunJobTaskOutputReference, DataDatabricksJobJobSettingsSettingsSchedule, DataDatabricksJobJobSettingsSettingsScheduleOutputReference, DataDatabricksJobJobSettingsSettingsSparkJarTask, DataDatabricksJobJobSettingsSettingsSparkJarTaskOutputReference, DataDatabricksJobJobSettingsSettingsSparkPythonTask, DataDatabricksJobJobSettingsSettingsSparkPythonTaskOutputReference, DataDatabricksJobJobSettingsSettingsSparkSubmitTask, DataDatabricksJobJobSettingsSettingsSparkSubmitTaskOutputReference } from './structs0';
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#alert_id DataDatabricksJob#alert_id}
    */
    readonly alertId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pause_subscriptions DataDatabricksJob#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#subscriptions DataDatabricksJob#subscriptions}
    */
    readonly subscriptions?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptionsList;
    putSubscriptions(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination_id DataDatabricksJob#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#user_name DataDatabricksJob#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptionsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptionsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptionsOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#custom_subject DataDatabricksJob#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dashboard_id DataDatabricksJob#dashboard_id}
    */
    readonly dashboardId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pause_subscriptions DataDatabricksJob#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#subscriptions DataDatabricksJob#subscriptions}
    */
    readonly subscriptions?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    get dashboardIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptionsList;
    putSubscriptions(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#path DataDatabricksJob#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFileToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFileToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#query_id DataDatabricksJob#query_id}
    */
    readonly queryId: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQueryToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQueryOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQueryToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQueryOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery | undefined);
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#alert DataDatabricksJob#alert}
    */
    readonly alert?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert;
    /**
    * dashboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dashboard DataDatabricksJob#dashboard}
    */
    readonly dashboard?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#file DataDatabricksJob#file}
    */
    readonly file?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#query DataDatabricksJob#query}
    */
    readonly query?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask | undefined);
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    private _alert;
    get alert(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertOutputReference;
    putAlert(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert): void;
    resetAlert(): void;
    get alertInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlert | undefined;
    private _dashboard;
    get dashboard(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboardOutputReference;
    putDashboard(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard): void;
    resetDashboard(): void;
    get dashboardInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskDashboard | undefined;
    private _file;
    get file(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFileOutputReference;
    putFile(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskFile | undefined;
    private _query;
    get query(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQueryOutputReference;
    putQuery(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery): void;
    resetQuery(): void;
    get queryInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskQuery | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailureToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailureToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailureOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStartToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStartToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStartOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccessToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccessToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccessOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_duration_warning_threshold_exceeded DataDatabricksJob#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_failure DataDatabricksJob#on_failure}
    */
    readonly onFailure?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_start DataDatabricksJob#on_start}
    */
    readonly onStart?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_streaming_backlog_exceeded DataDatabricksJob#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_success DataDatabricksJob#on_success}
    */
    readonly onSuccess?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailureList;
    putOnFailure(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnFailure[] | undefined;
    private _onStart;
    get onStart(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStartList;
    putOnStart(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccessList;
    putOnSuccess(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#description DataDatabricksJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#environment_key DataDatabricksJob#environment_key}
    */
    readonly environmentKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#existing_cluster_id DataDatabricksJob#existing_cluster_id}
    */
    readonly existingClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#job_cluster_key DataDatabricksJob#job_cluster_key}
    */
    readonly jobClusterKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#max_retries DataDatabricksJob#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#min_retry_interval_millis DataDatabricksJob#min_retry_interval_millis}
    */
    readonly minRetryIntervalMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#retry_on_timeout DataDatabricksJob#retry_on_timeout}
    */
    readonly retryOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#run_if DataDatabricksJob#run_if}
    */
    readonly runIf?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#task_key DataDatabricksJob#task_key}
    */
    readonly taskKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#timeout_seconds DataDatabricksJob#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * condition_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#condition_task DataDatabricksJob#condition_task}
    */
    readonly conditionTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask;
    /**
    * dashboard_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dashboard_task DataDatabricksJob#dashboard_task}
    */
    readonly dashboardTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask;
    /**
    * dbt_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dbt_task DataDatabricksJob#dbt_task}
    */
    readonly dbtTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask;
    /**
    * depends_on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#depends_on DataDatabricksJob#depends_on}
    */
    readonly dependsOn?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn[] | cdktn.IResolvable;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#email_notifications DataDatabricksJob#email_notifications}
    */
    readonly emailNotifications?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#health DataDatabricksJob#health}
    */
    readonly health?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#library DataDatabricksJob#library}
    */
    readonly library?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary[] | cdktn.IResolvable;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#new_cluster DataDatabricksJob#new_cluster}
    */
    readonly newCluster?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster;
    /**
    * notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notebook_task DataDatabricksJob#notebook_task}
    */
    readonly notebookTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask;
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notification_settings DataDatabricksJob#notification_settings}
    */
    readonly notificationSettings?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings;
    /**
    * pipeline_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pipeline_task DataDatabricksJob#pipeline_task}
    */
    readonly pipelineTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask;
    /**
    * power_bi_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#power_bi_task DataDatabricksJob#power_bi_task}
    */
    readonly powerBiTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask;
    /**
    * python_wheel_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#python_wheel_task DataDatabricksJob#python_wheel_task}
    */
    readonly pythonWheelTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask;
    /**
    * run_job_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#run_job_task DataDatabricksJob#run_job_task}
    */
    readonly runJobTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask;
    /**
    * spark_jar_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_jar_task DataDatabricksJob#spark_jar_task}
    */
    readonly sparkJarTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask;
    /**
    * spark_python_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_python_task DataDatabricksJob#spark_python_task}
    */
    readonly sparkPythonTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask;
    /**
    * spark_submit_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_submit_task DataDatabricksJob#spark_submit_task}
    */
    readonly sparkSubmitTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask;
    /**
    * sql_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#sql_task DataDatabricksJob#sql_task}
    */
    readonly sqlTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask;
    /**
    * webhook_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#webhook_notifications DataDatabricksJob#webhook_notifications}
    */
    readonly webhookNotifications?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentKey?;
    get environmentKey(): string;
    set environmentKey(value: string);
    resetEnvironmentKey(): void;
    get environmentKeyInput(): string | undefined;
    private _existingClusterId?;
    get existingClusterId(): string;
    set existingClusterId(value: string);
    resetExistingClusterId(): void;
    get existingClusterIdInput(): string | undefined;
    private _jobClusterKey?;
    get jobClusterKey(): string;
    set jobClusterKey(value: string);
    resetJobClusterKey(): void;
    get jobClusterKeyInput(): string | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minRetryIntervalMillis?;
    get minRetryIntervalMillis(): number;
    set minRetryIntervalMillis(value: number);
    resetMinRetryIntervalMillis(): void;
    get minRetryIntervalMillisInput(): number | undefined;
    private _retryOnTimeout?;
    get retryOnTimeout(): boolean | cdktn.IResolvable;
    set retryOnTimeout(value: boolean | cdktn.IResolvable);
    resetRetryOnTimeout(): void;
    get retryOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _runIf?;
    get runIf(): string;
    set runIf(value: string);
    resetRunIf(): void;
    get runIfInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _conditionTask;
    get conditionTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTaskOutputReference;
    putConditionTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask): void;
    resetConditionTask(): void;
    get conditionTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask | undefined;
    private _dashboardTask;
    get dashboardTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskOutputReference;
    putDashboardTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask): void;
    resetDashboardTask(): void;
    get dashboardTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask | undefined;
    private _dbtTask;
    get dbtTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTaskOutputReference;
    putDbtTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask): void;
    resetDbtTask(): void;
    get dbtTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask | undefined;
    private _dependsOn;
    get dependsOn(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOnList;
    putDependsOn(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn[] | cdktn.IResolvable): void;
    resetDependsOn(): void;
    get dependsOnInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn[] | undefined;
    private _emailNotifications;
    get emailNotifications(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotificationsOutputReference;
    putEmailNotifications(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications | undefined;
    private _health;
    get health(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthOutputReference;
    putHealth(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth): void;
    resetHealth(): void;
    get healthInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth | undefined;
    private _library;
    get library(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryList;
    putLibrary(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary[] | undefined;
    private _newCluster;
    get newCluster(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterOutputReference;
    putNewCluster(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster): void;
    resetNewCluster(): void;
    get newClusterInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster | undefined;
    private _notebookTask;
    get notebookTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTaskOutputReference;
    putNotebookTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask): void;
    resetNotebookTask(): void;
    get notebookTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask | undefined;
    private _notificationSettings;
    get notificationSettings(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettingsOutputReference;
    putNotificationSettings(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings | undefined;
    private _pipelineTask;
    get pipelineTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTaskOutputReference;
    putPipelineTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask): void;
    resetPipelineTask(): void;
    get pipelineTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask | undefined;
    private _powerBiTask;
    get powerBiTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskOutputReference;
    putPowerBiTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask): void;
    resetPowerBiTask(): void;
    get powerBiTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask | undefined;
    private _pythonWheelTask;
    get pythonWheelTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTaskOutputReference;
    putPythonWheelTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask): void;
    resetPythonWheelTask(): void;
    get pythonWheelTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask | undefined;
    private _runJobTask;
    get runJobTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTaskOutputReference;
    putRunJobTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask): void;
    resetRunJobTask(): void;
    get runJobTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask | undefined;
    private _sparkJarTask;
    get sparkJarTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTaskOutputReference;
    putSparkJarTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask): void;
    resetSparkJarTask(): void;
    get sparkJarTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask | undefined;
    private _sparkPythonTask;
    get sparkPythonTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTaskOutputReference;
    putSparkPythonTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask): void;
    resetSparkPythonTask(): void;
    get sparkPythonTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask | undefined;
    private _sparkSubmitTask;
    get sparkSubmitTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTaskOutputReference;
    putSparkSubmitTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask): void;
    resetSparkSubmitTask(): void;
    get sparkSubmitTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask | undefined;
    private _sqlTask;
    get sqlTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskOutputReference;
    putSqlTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask): void;
    resetSqlTask(): void;
    get sqlTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTask | undefined;
    private _webhookNotifications;
    get webhookNotifications(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotificationsOutputReference;
    putWebhookNotifications(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications): void;
    resetWebhookNotifications(): void;
    get webhookNotificationsInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskWebhookNotifications | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#concurrency DataDatabricksJob#concurrency}
    */
    readonly concurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#inputs DataDatabricksJob#inputs}
    */
    readonly inputs: string;
    /**
    * task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#task DataDatabricksJob#task}
    */
    readonly task: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTask | undefined);
    private _concurrency?;
    get concurrency(): number;
    set concurrency(value: number);
    resetConcurrency(): void;
    get concurrencyInput(): number | undefined;
    private _inputs?;
    get inputs(): string;
    set inputs(value: string);
    get inputsInput(): string | undefined;
    private _task;
    get task(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskOutputReference;
    putTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask): void;
    get taskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTask | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskHealthRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#metric DataDatabricksJob#metric}
    */
    readonly metric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#op DataDatabricksJob#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#value DataDatabricksJob#value}
    */
    readonly value: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskHealthRulesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskHealthRules | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskHealthRulesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskHealthRules | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskHealthRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskHealthRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskHealthRules | cdktn.IResolvable | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskHealthRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskHealthRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskHealthRulesOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskHealth {
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#rules DataDatabricksJob#rules}
    */
    readonly rules: DataDatabricksJobJobSettingsSettingsTaskHealthRules[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskHealthToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskHealthOutputReference | DataDatabricksJobJobSettingsSettingsTaskHealth): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskHealthToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskHealthOutputReference | DataDatabricksJobJobSettingsSettingsTaskHealth): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskHealth | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskHealth | undefined);
    private _rules;
    get rules(): DataDatabricksJobJobSettingsSettingsTaskHealthRulesList;
    putRules(value: DataDatabricksJobJobSettingsSettingsTaskHealthRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskHealthRules[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#package DataDatabricksJob#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryCranToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryCranOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryCran): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryCranToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryCranOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryCran): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskLibraryCran | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#coordinates DataDatabricksJob#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#exclusions DataDatabricksJob#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryMavenToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryMavenOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryMaven): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryMavenToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryMavenOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryMaven): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskLibraryMaven | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#workspace_id DataDatabricksJob#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfigToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfigOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfigToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfigOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#package DataDatabricksJob#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryPypiToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryPypiOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryPypi): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryPypiToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibraryPypiOutputReference | DataDatabricksJobJobSettingsSettingsTaskLibraryPypi): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskLibraryPypi | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#egg DataDatabricksJob#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#jar DataDatabricksJob#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#requirements DataDatabricksJob#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#whl DataDatabricksJob#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#cran DataDatabricksJob#cran}
    */
    readonly cran?: DataDatabricksJobJobSettingsSettingsTaskLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#maven DataDatabricksJob#maven}
    */
    readonly maven?: DataDatabricksJobJobSettingsSettingsTaskLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#provider_config DataDatabricksJob#provider_config}
    */
    readonly providerConfig?: DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pypi DataDatabricksJob#pypi}
    */
    readonly pypi?: DataDatabricksJobJobSettingsSettingsTaskLibraryPypi;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibrary | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskLibraryToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskLibrary | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): DataDatabricksJobJobSettingsSettingsTaskLibraryCranOutputReference;
    putCran(value: DataDatabricksJobJobSettingsSettingsTaskLibraryCran): void;
    resetCran(): void;
    get cranInput(): DataDatabricksJobJobSettingsSettingsTaskLibraryCran | undefined;
    private _maven;
    get maven(): DataDatabricksJobJobSettingsSettingsTaskLibraryMavenOutputReference;
    putMaven(value: DataDatabricksJobJobSettingsSettingsTaskLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): DataDatabricksJobJobSettingsSettingsTaskLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksJobJobSettingsSettingsTaskLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): DataDatabricksJobJobSettingsSettingsTaskLibraryPypiOutputReference;
    putPypi(value: DataDatabricksJobJobSettingsSettingsTaskLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): DataDatabricksJobJobSettingsSettingsTaskLibraryPypi | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskLibraryList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskLibraryOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#max_workers DataDatabricksJob#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#min_workers DataDatabricksJob#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscaleToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscaleToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#ebs_volume_count DataDatabricksJob#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#ebs_volume_size DataDatabricksJob#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#ebs_volume_type DataDatabricksJob#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#instance_profile_arn DataDatabricksJob#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spot_bid_price_percent DataDatabricksJob#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spot_bid_max_price DataDatabricksJob#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfS3 | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#mount_options DataDatabricksJob#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#server_address DataDatabricksJob#server_address}
    */
    readonly serverAddress: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#local_mount_dir_path DataDatabricksJob#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#remote_mount_dir_path DataDatabricksJob#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#network_filesystem_info DataDatabricksJob#network_filesystem_info}
    */
    readonly networkFilesystemInfo: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#password DataDatabricksJob#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#username DataDatabricksJob#username}
    */
    readonly username: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuthToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#url DataDatabricksJob#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#basic_auth DataDatabricksJob#basic_auth}
    */
    readonly basicAuth?: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageBasicAuth | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#boot_disk_size DataDatabricksJob#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#google_service_account DataDatabricksJob#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#local_ssd_count DataDatabricksJob#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#use_preemptible_executors DataDatabricksJob#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfssToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfssToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFileToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFileToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspaceToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#abfss DataDatabricksJob#abfss}
    */
    readonly abfss?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#file DataDatabricksJob#file}
    */
    readonly file?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#gcs DataDatabricksJob#gcs}
    */
    readonly gcs?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#volumes DataDatabricksJob#volumes}
    */
    readonly volumes?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#workspace DataDatabricksJob#workspace}
    */
    readonly workspace?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFileOutputReference;
    putFile(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcsOutputReference;
    putGcs(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsWorkspace | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#jobs DataDatabricksJob#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notebooks DataDatabricksJob#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClientsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#clients DataDatabricksJob#clients}
    */
    readonly clients: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients): void;
    get clientsInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeClients | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#apply_policy_default_values DataDatabricksJob#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#autotermination_minutes DataDatabricksJob#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#cluster_id DataDatabricksJob#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#cluster_name DataDatabricksJob#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#custom_tags DataDatabricksJob#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#data_security_mode DataDatabricksJob#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#driver_instance_pool_id DataDatabricksJob#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#driver_node_type_id DataDatabricksJob#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#enable_elastic_disk DataDatabricksJob#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#enable_local_disk_encryption DataDatabricksJob#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#idempotency_token DataDatabricksJob#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#instance_pool_id DataDatabricksJob#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#node_type_id DataDatabricksJob#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#num_workers DataDatabricksJob#num_workers}
    */
    readonly numWorkers: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#policy_id DataDatabricksJob#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#runtime_engine DataDatabricksJob#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#single_user_name DataDatabricksJob#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_conf DataDatabricksJob#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_env_vars DataDatabricksJob#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_version DataDatabricksJob#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#ssh_public_keys DataDatabricksJob#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#autoscale DataDatabricksJob#autoscale}
    */
    readonly autoscale?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#aws_attributes DataDatabricksJob#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#azure_attributes DataDatabricksJob#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#cluster_log_conf DataDatabricksJob#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#cluster_mount_info DataDatabricksJob#cluster_mount_info}
    */
    readonly clusterMountInfo?: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#docker_image DataDatabricksJob#docker_image}
    */
    readonly dockerImage?: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#gcp_attributes DataDatabricksJob#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#init_scripts DataDatabricksJob#init_scripts}
    */
    readonly initScripts?: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#workload_type DataDatabricksJob#workload_type}
    */
    readonly workloadType?: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewCluster): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNewClusterToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsTaskNewCluster): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNewCluster | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNewCluster | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _autoscale;
    get autoscale(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscaleOutputReference;
    putAutoscale(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfoList;
    putClusterMountInfo(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImageOutputReference;
    putDockerImage(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterDockerImage | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScriptsList;
    putInitScripts(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskNewClusterInitScripts[] | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): DataDatabricksJobJobSettingsSettingsTaskNewClusterWorkloadType | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#base_parameters DataDatabricksJob#base_parameters}
    */
    readonly baseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notebook_path DataDatabricksJob#notebook_path}
    */
    readonly notebookPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNotebookTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNotebookTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskNotebookTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNotebookTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNotebookTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskNotebookTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNotebookTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNotebookTask | undefined);
    private _baseParameters?;
    get baseParameters(): {
        [key: string]: string;
    };
    set baseParameters(value: {
        [key: string]: string;
    });
    resetBaseParameters(): void;
    get baseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    get notebookPathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#alert_on_last_attempt DataDatabricksJob#alert_on_last_attempt}
    */
    readonly alertOnLastAttempt?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#no_alert_for_canceled_runs DataDatabricksJob#no_alert_for_canceled_runs}
    */
    readonly noAlertForCanceledRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#no_alert_for_skipped_runs DataDatabricksJob#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskNotificationSettingsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNotificationSettingsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNotificationSettings): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskNotificationSettingsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskNotificationSettingsOutputReference | DataDatabricksJobJobSettingsSettingsTaskNotificationSettings): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskNotificationSettings | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskNotificationSettings | undefined);
    private _alertOnLastAttempt?;
    get alertOnLastAttempt(): boolean | cdktn.IResolvable;
    set alertOnLastAttempt(value: boolean | cdktn.IResolvable);
    resetAlertOnLastAttempt(): void;
    get alertOnLastAttemptInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForCanceledRuns?;
    get noAlertForCanceledRuns(): boolean | cdktn.IResolvable;
    set noAlertForCanceledRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForCanceledRuns(): void;
    get noAlertForCanceledRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskPipelineTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#full_refresh DataDatabricksJob#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pipeline_id DataDatabricksJob#pipeline_id}
    */
    readonly pipelineId: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskPipelineTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPipelineTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskPipelineTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskPipelineTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPipelineTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskPipelineTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskPipelineTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskPipelineTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskPipelineTask | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#authentication_method DataDatabricksJob#authentication_method}
    */
    readonly authenticationMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#model_name DataDatabricksJob#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#overwrite_existing DataDatabricksJob#overwrite_existing}
    */
    readonly overwriteExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#storage_mode DataDatabricksJob#storage_mode}
    */
    readonly storageMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#workspace_name DataDatabricksJob#workspace_name}
    */
    readonly workspaceName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModelToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModelOutputReference | DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModelToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModelOutputReference | DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel | undefined);
    private _authenticationMethod?;
    get authenticationMethod(): string;
    set authenticationMethod(value: string);
    resetAuthenticationMethod(): void;
    get authenticationMethodInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _overwriteExisting?;
    get overwriteExisting(): boolean | cdktn.IResolvable;
    set overwriteExisting(value: boolean | cdktn.IResolvable);
    resetOverwriteExisting(): void;
    get overwriteExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
    private _workspaceName?;
    get workspaceName(): string;
    set workspaceName(value: string);
    resetWorkspaceName(): void;
    get workspaceNameInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#catalog DataDatabricksJob#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#name DataDatabricksJob#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#schema DataDatabricksJob#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#storage_mode DataDatabricksJob#storage_mode}
    */
    readonly storageMode?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTablesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTablesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables | cdktn.IResolvable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTablesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTablesOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskPowerBiTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#connection_resource_name DataDatabricksJob#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#refresh_after_update DataDatabricksJob#refresh_after_update}
    */
    readonly refreshAfterUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * power_bi_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#power_bi_model DataDatabricksJob#power_bi_model}
    */
    readonly powerBiModel?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel;
    /**
    * tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#tables DataDatabricksJob#tables}
    */
    readonly tables?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskPowerBiTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskPowerBiTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskPowerBiTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskPowerBiTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskPowerBiTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _refreshAfterUpdate?;
    get refreshAfterUpdate(): boolean | cdktn.IResolvable;
    set refreshAfterUpdate(value: boolean | cdktn.IResolvable);
    resetRefreshAfterUpdate(): void;
    get refreshAfterUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _powerBiModel;
    get powerBiModel(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModelOutputReference;
    putPowerBiModel(value: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel): void;
    resetPowerBiModel(): void;
    get powerBiModelInput(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskPowerBiModel | undefined;
    private _tables;
    get tables(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTablesList;
    putTables(value: DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskTables[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#entry_point DataDatabricksJob#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#named_parameters DataDatabricksJob#named_parameters}
    */
    readonly namedParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#package_name DataDatabricksJob#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskPythonWheelTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPythonWheelTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskPythonWheelTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskPythonWheelTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskPythonWheelTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask | undefined);
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _namedParameters?;
    get namedParameters(): {
        [key: string]: string;
    };
    set namedParameters(value: {
        [key: string]: string;
    });
    resetNamedParameters(): void;
    get namedParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskRunJobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#job_id DataDatabricksJob#job_id}
    */
    readonly jobId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#job_parameters DataDatabricksJob#job_parameters}
    */
    readonly jobParameters?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksJobJobSettingsSettingsTaskRunJobTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskRunJobTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskRunJobTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskRunJobTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskRunJobTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskRunJobTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskRunJobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskRunJobTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskRunJobTask | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    private _jobParameters?;
    get jobParameters(): {
        [key: string]: string;
    };
    set jobParameters(value: {
        [key: string]: string;
    });
    resetJobParameters(): void;
    get jobParametersInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSparkJarTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#jar_uri DataDatabricksJob#jar_uri}
    */
    readonly jarUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#main_class_name DataDatabricksJob#main_class_name}
    */
    readonly mainClassName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSparkJarTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSparkJarTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSparkJarTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSparkJarTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSparkJarTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSparkJarTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSparkJarTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSparkJarTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSparkJarTask | undefined);
    private _jarUri?;
    get jarUri(): string;
    set jarUri(value: string);
    resetJarUri(): void;
    get jarUriInput(): string | undefined;
    private _mainClassName?;
    get mainClassName(): string;
    set mainClassName(value: string);
    resetMainClassName(): void;
    get mainClassNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#python_file DataDatabricksJob#python_file}
    */
    readonly pythonFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSparkPythonTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSparkPythonTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSparkPythonTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSparkPythonTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSparkPythonTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pythonFile?;
    get pythonFile(): string;
    set pythonFile(value: string);
    get pythonFileInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSparkSubmitTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSparkSubmitTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination_id DataDatabricksJob#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#user_name DataDatabricksJob#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptionsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptionsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptionsOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#alert_id DataDatabricksJob#alert_id}
    */
    readonly alertId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pause_subscriptions DataDatabricksJob#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#subscriptions DataDatabricksJob#subscriptions}
    */
    readonly subscriptions?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptionsList;
    putSubscriptions(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertSubscriptions[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#destination_id DataDatabricksJob#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#user_name DataDatabricksJob#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptionsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptionsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptionsOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#custom_subject DataDatabricksJob#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dashboard_id DataDatabricksJob#dashboard_id}
    */
    readonly dashboardId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pause_subscriptions DataDatabricksJob#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#subscriptions DataDatabricksJob#subscriptions}
    */
    readonly subscriptions?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    get dashboardIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptionsList;
    putSubscriptions(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardSubscriptions[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#path DataDatabricksJob#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskFileToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskFileToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#query_id DataDatabricksJob#query_id}
    */
    readonly queryId: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskQueryToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskQueryOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskQueryToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskQueryOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery | undefined);
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskSqlTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#alert DataDatabricksJob#alert}
    */
    readonly alert?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert;
    /**
    * dashboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dashboard DataDatabricksJob#dashboard}
    */
    readonly dashboard?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#file DataDatabricksJob#file}
    */
    readonly file?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#query DataDatabricksJob#query}
    */
    readonly query?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskSqlTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskSqlTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskSqlTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskSqlTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskSqlTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskSqlTask | undefined);
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    private _alert;
    get alert(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlertOutputReference;
    putAlert(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert): void;
    resetAlert(): void;
    get alertInput(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskAlert | undefined;
    private _dashboard;
    get dashboard(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboardOutputReference;
    putDashboard(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard): void;
    resetDashboard(): void;
    get dashboardInput(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskDashboard | undefined;
    private _file;
    get file(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskFileOutputReference;
    putFile(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskFile | undefined;
    private _query;
    get query(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskQueryOutputReference;
    putQuery(value: DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery): void;
    resetQuery(): void;
    get queryInput(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskQuery | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailureToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailureToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailureOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStartToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStartToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStartOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccessToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccessToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccessOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_duration_warning_threshold_exceeded DataDatabricksJob#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_failure DataDatabricksJob#on_failure}
    */
    readonly onFailure?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_start DataDatabricksJob#on_start}
    */
    readonly onStart?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_streaming_backlog_exceeded DataDatabricksJob#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_success DataDatabricksJob#on_success}
    */
    readonly onSuccess?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailureList;
    putOnFailure(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnFailure[] | undefined;
    private _onStart;
    get onStart(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStartList;
    putOnStart(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccessList;
    putOnSuccess(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOnSuccess[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#description DataDatabricksJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#environment_key DataDatabricksJob#environment_key}
    */
    readonly environmentKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#existing_cluster_id DataDatabricksJob#existing_cluster_id}
    */
    readonly existingClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#job_cluster_key DataDatabricksJob#job_cluster_key}
    */
    readonly jobClusterKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#max_retries DataDatabricksJob#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#min_retry_interval_millis DataDatabricksJob#min_retry_interval_millis}
    */
    readonly minRetryIntervalMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#retry_on_timeout DataDatabricksJob#retry_on_timeout}
    */
    readonly retryOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#run_if DataDatabricksJob#run_if}
    */
    readonly runIf?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#task_key DataDatabricksJob#task_key}
    */
    readonly taskKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#timeout_seconds DataDatabricksJob#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * condition_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#condition_task DataDatabricksJob#condition_task}
    */
    readonly conditionTask?: DataDatabricksJobJobSettingsSettingsTaskConditionTask;
    /**
    * dashboard_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dashboard_task DataDatabricksJob#dashboard_task}
    */
    readonly dashboardTask?: DataDatabricksJobJobSettingsSettingsTaskDashboardTask;
    /**
    * dbt_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dbt_task DataDatabricksJob#dbt_task}
    */
    readonly dbtTask?: DataDatabricksJobJobSettingsSettingsTaskDbtTask;
    /**
    * depends_on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#depends_on DataDatabricksJob#depends_on}
    */
    readonly dependsOn?: DataDatabricksJobJobSettingsSettingsTaskDependsOn[] | cdktn.IResolvable;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#email_notifications DataDatabricksJob#email_notifications}
    */
    readonly emailNotifications?: DataDatabricksJobJobSettingsSettingsTaskEmailNotifications;
    /**
    * for_each_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#for_each_task DataDatabricksJob#for_each_task}
    */
    readonly forEachTask?: DataDatabricksJobJobSettingsSettingsTaskForEachTask;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#health DataDatabricksJob#health}
    */
    readonly health?: DataDatabricksJobJobSettingsSettingsTaskHealth;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#library DataDatabricksJob#library}
    */
    readonly library?: DataDatabricksJobJobSettingsSettingsTaskLibrary[] | cdktn.IResolvable;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#new_cluster DataDatabricksJob#new_cluster}
    */
    readonly newCluster?: DataDatabricksJobJobSettingsSettingsTaskNewCluster;
    /**
    * notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notebook_task DataDatabricksJob#notebook_task}
    */
    readonly notebookTask?: DataDatabricksJobJobSettingsSettingsTaskNotebookTask;
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notification_settings DataDatabricksJob#notification_settings}
    */
    readonly notificationSettings?: DataDatabricksJobJobSettingsSettingsTaskNotificationSettings;
    /**
    * pipeline_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pipeline_task DataDatabricksJob#pipeline_task}
    */
    readonly pipelineTask?: DataDatabricksJobJobSettingsSettingsTaskPipelineTask;
    /**
    * power_bi_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#power_bi_task DataDatabricksJob#power_bi_task}
    */
    readonly powerBiTask?: DataDatabricksJobJobSettingsSettingsTaskPowerBiTask;
    /**
    * python_wheel_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#python_wheel_task DataDatabricksJob#python_wheel_task}
    */
    readonly pythonWheelTask?: DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask;
    /**
    * run_job_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#run_job_task DataDatabricksJob#run_job_task}
    */
    readonly runJobTask?: DataDatabricksJobJobSettingsSettingsTaskRunJobTask;
    /**
    * spark_jar_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_jar_task DataDatabricksJob#spark_jar_task}
    */
    readonly sparkJarTask?: DataDatabricksJobJobSettingsSettingsTaskSparkJarTask;
    /**
    * spark_python_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_python_task DataDatabricksJob#spark_python_task}
    */
    readonly sparkPythonTask?: DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask;
    /**
    * spark_submit_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_submit_task DataDatabricksJob#spark_submit_task}
    */
    readonly sparkSubmitTask?: DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask;
    /**
    * sql_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#sql_task DataDatabricksJob#sql_task}
    */
    readonly sqlTask?: DataDatabricksJobJobSettingsSettingsTaskSqlTask;
    /**
    * webhook_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#webhook_notifications DataDatabricksJob#webhook_notifications}
    */
    readonly webhookNotifications?: DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTask | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTask | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTask | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTask | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentKey?;
    get environmentKey(): string;
    set environmentKey(value: string);
    resetEnvironmentKey(): void;
    get environmentKeyInput(): string | undefined;
    private _existingClusterId?;
    get existingClusterId(): string;
    set existingClusterId(value: string);
    resetExistingClusterId(): void;
    get existingClusterIdInput(): string | undefined;
    private _jobClusterKey?;
    get jobClusterKey(): string;
    set jobClusterKey(value: string);
    resetJobClusterKey(): void;
    get jobClusterKeyInput(): string | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minRetryIntervalMillis?;
    get minRetryIntervalMillis(): number;
    set minRetryIntervalMillis(value: number);
    resetMinRetryIntervalMillis(): void;
    get minRetryIntervalMillisInput(): number | undefined;
    private _retryOnTimeout?;
    get retryOnTimeout(): boolean | cdktn.IResolvable;
    set retryOnTimeout(value: boolean | cdktn.IResolvable);
    resetRetryOnTimeout(): void;
    get retryOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _runIf?;
    get runIf(): string;
    set runIf(value: string);
    resetRunIf(): void;
    get runIfInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _conditionTask;
    get conditionTask(): DataDatabricksJobJobSettingsSettingsTaskConditionTaskOutputReference;
    putConditionTask(value: DataDatabricksJobJobSettingsSettingsTaskConditionTask): void;
    resetConditionTask(): void;
    get conditionTaskInput(): DataDatabricksJobJobSettingsSettingsTaskConditionTask | undefined;
    private _dashboardTask;
    get dashboardTask(): DataDatabricksJobJobSettingsSettingsTaskDashboardTaskOutputReference;
    putDashboardTask(value: DataDatabricksJobJobSettingsSettingsTaskDashboardTask): void;
    resetDashboardTask(): void;
    get dashboardTaskInput(): DataDatabricksJobJobSettingsSettingsTaskDashboardTask | undefined;
    private _dbtTask;
    get dbtTask(): DataDatabricksJobJobSettingsSettingsTaskDbtTaskOutputReference;
    putDbtTask(value: DataDatabricksJobJobSettingsSettingsTaskDbtTask): void;
    resetDbtTask(): void;
    get dbtTaskInput(): DataDatabricksJobJobSettingsSettingsTaskDbtTask | undefined;
    private _dependsOn;
    get dependsOn(): DataDatabricksJobJobSettingsSettingsTaskDependsOnList;
    putDependsOn(value: DataDatabricksJobJobSettingsSettingsTaskDependsOn[] | cdktn.IResolvable): void;
    resetDependsOn(): void;
    get dependsOnInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskDependsOn[] | undefined;
    private _emailNotifications;
    get emailNotifications(): DataDatabricksJobJobSettingsSettingsTaskEmailNotificationsOutputReference;
    putEmailNotifications(value: DataDatabricksJobJobSettingsSettingsTaskEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): DataDatabricksJobJobSettingsSettingsTaskEmailNotifications | undefined;
    private _forEachTask;
    get forEachTask(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskOutputReference;
    putForEachTask(value: DataDatabricksJobJobSettingsSettingsTaskForEachTask): void;
    resetForEachTask(): void;
    get forEachTaskInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTask | undefined;
    private _health;
    get health(): DataDatabricksJobJobSettingsSettingsTaskHealthOutputReference;
    putHealth(value: DataDatabricksJobJobSettingsSettingsTaskHealth): void;
    resetHealth(): void;
    get healthInput(): DataDatabricksJobJobSettingsSettingsTaskHealth | undefined;
    private _library;
    get library(): DataDatabricksJobJobSettingsSettingsTaskLibraryList;
    putLibrary(value: DataDatabricksJobJobSettingsSettingsTaskLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskLibrary[] | undefined;
    private _newCluster;
    get newCluster(): DataDatabricksJobJobSettingsSettingsTaskNewClusterOutputReference;
    putNewCluster(value: DataDatabricksJobJobSettingsSettingsTaskNewCluster): void;
    resetNewCluster(): void;
    get newClusterInput(): DataDatabricksJobJobSettingsSettingsTaskNewCluster | undefined;
    private _notebookTask;
    get notebookTask(): DataDatabricksJobJobSettingsSettingsTaskNotebookTaskOutputReference;
    putNotebookTask(value: DataDatabricksJobJobSettingsSettingsTaskNotebookTask): void;
    resetNotebookTask(): void;
    get notebookTaskInput(): DataDatabricksJobJobSettingsSettingsTaskNotebookTask | undefined;
    private _notificationSettings;
    get notificationSettings(): DataDatabricksJobJobSettingsSettingsTaskNotificationSettingsOutputReference;
    putNotificationSettings(value: DataDatabricksJobJobSettingsSettingsTaskNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): DataDatabricksJobJobSettingsSettingsTaskNotificationSettings | undefined;
    private _pipelineTask;
    get pipelineTask(): DataDatabricksJobJobSettingsSettingsTaskPipelineTaskOutputReference;
    putPipelineTask(value: DataDatabricksJobJobSettingsSettingsTaskPipelineTask): void;
    resetPipelineTask(): void;
    get pipelineTaskInput(): DataDatabricksJobJobSettingsSettingsTaskPipelineTask | undefined;
    private _powerBiTask;
    get powerBiTask(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTaskOutputReference;
    putPowerBiTask(value: DataDatabricksJobJobSettingsSettingsTaskPowerBiTask): void;
    resetPowerBiTask(): void;
    get powerBiTaskInput(): DataDatabricksJobJobSettingsSettingsTaskPowerBiTask | undefined;
    private _pythonWheelTask;
    get pythonWheelTask(): DataDatabricksJobJobSettingsSettingsTaskPythonWheelTaskOutputReference;
    putPythonWheelTask(value: DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask): void;
    resetPythonWheelTask(): void;
    get pythonWheelTaskInput(): DataDatabricksJobJobSettingsSettingsTaskPythonWheelTask | undefined;
    private _runJobTask;
    get runJobTask(): DataDatabricksJobJobSettingsSettingsTaskRunJobTaskOutputReference;
    putRunJobTask(value: DataDatabricksJobJobSettingsSettingsTaskRunJobTask): void;
    resetRunJobTask(): void;
    get runJobTaskInput(): DataDatabricksJobJobSettingsSettingsTaskRunJobTask | undefined;
    private _sparkJarTask;
    get sparkJarTask(): DataDatabricksJobJobSettingsSettingsTaskSparkJarTaskOutputReference;
    putSparkJarTask(value: DataDatabricksJobJobSettingsSettingsTaskSparkJarTask): void;
    resetSparkJarTask(): void;
    get sparkJarTaskInput(): DataDatabricksJobJobSettingsSettingsTaskSparkJarTask | undefined;
    private _sparkPythonTask;
    get sparkPythonTask(): DataDatabricksJobJobSettingsSettingsTaskSparkPythonTaskOutputReference;
    putSparkPythonTask(value: DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask): void;
    resetSparkPythonTask(): void;
    get sparkPythonTaskInput(): DataDatabricksJobJobSettingsSettingsTaskSparkPythonTask | undefined;
    private _sparkSubmitTask;
    get sparkSubmitTask(): DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTaskOutputReference;
    putSparkSubmitTask(value: DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask): void;
    resetSparkSubmitTask(): void;
    get sparkSubmitTaskInput(): DataDatabricksJobJobSettingsSettingsTaskSparkSubmitTask | undefined;
    private _sqlTask;
    get sqlTask(): DataDatabricksJobJobSettingsSettingsTaskSqlTaskOutputReference;
    putSqlTask(value: DataDatabricksJobJobSettingsSettingsTaskSqlTask): void;
    resetSqlTask(): void;
    get sqlTaskInput(): DataDatabricksJobJobSettingsSettingsTaskSqlTask | undefined;
    private _webhookNotifications;
    get webhookNotifications(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotificationsOutputReference;
    putWebhookNotifications(value: DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications): void;
    resetWebhookNotifications(): void;
    get webhookNotificationsInput(): DataDatabricksJobJobSettingsSettingsTaskWebhookNotifications | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTask[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTriggerFileArrival {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#min_time_between_triggers_seconds DataDatabricksJob#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#url DataDatabricksJob#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#wait_after_last_change_seconds DataDatabricksJob#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTriggerFileArrivalToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerFileArrivalOutputReference | DataDatabricksJobJobSettingsSettingsTriggerFileArrival): any;
export declare function dataDatabricksJobJobSettingsSettingsTriggerFileArrivalToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerFileArrivalOutputReference | DataDatabricksJobJobSettingsSettingsTriggerFileArrival): any;
export declare class DataDatabricksJobJobSettingsSettingsTriggerFileArrivalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTriggerFileArrival | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTriggerFileArrival | undefined);
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTriggerPeriodic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#interval DataDatabricksJob#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#unit DataDatabricksJob#unit}
    */
    readonly unit: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTriggerPeriodicToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerPeriodicOutputReference | DataDatabricksJobJobSettingsSettingsTriggerPeriodic): any;
export declare function dataDatabricksJobJobSettingsSettingsTriggerPeriodicToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerPeriodicOutputReference | DataDatabricksJobJobSettingsSettingsTriggerPeriodic): any;
export declare class DataDatabricksJobJobSettingsSettingsTriggerPeriodicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTriggerPeriodic | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTriggerPeriodic | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTriggerTableUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#condition DataDatabricksJob#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#min_time_between_triggers_seconds DataDatabricksJob#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#table_names DataDatabricksJob#table_names}
    */
    readonly tableNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#wait_after_last_change_seconds DataDatabricksJob#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTriggerTableUpdateToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerTableUpdateOutputReference | DataDatabricksJobJobSettingsSettingsTriggerTableUpdate): any;
export declare function dataDatabricksJobJobSettingsSettingsTriggerTableUpdateToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerTableUpdateOutputReference | DataDatabricksJobJobSettingsSettingsTriggerTableUpdate): any;
export declare class DataDatabricksJobJobSettingsSettingsTriggerTableUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTriggerTableUpdate | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTriggerTableUpdate | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _tableNames?;
    get tableNames(): string[];
    set tableNames(value: string[]);
    get tableNamesInput(): string[] | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pause_status DataDatabricksJob#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * file_arrival block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#file_arrival DataDatabricksJob#file_arrival}
    */
    readonly fileArrival?: DataDatabricksJobJobSettingsSettingsTriggerFileArrival;
    /**
    * periodic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#periodic DataDatabricksJob#periodic}
    */
    readonly periodic?: DataDatabricksJobJobSettingsSettingsTriggerPeriodic;
    /**
    * table_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#table_update DataDatabricksJob#table_update}
    */
    readonly tableUpdate?: DataDatabricksJobJobSettingsSettingsTriggerTableUpdate;
}
export declare function dataDatabricksJobJobSettingsSettingsTriggerToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerOutputReference | DataDatabricksJobJobSettingsSettingsTrigger): any;
export declare function dataDatabricksJobJobSettingsSettingsTriggerToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTriggerOutputReference | DataDatabricksJobJobSettingsSettingsTrigger): any;
export declare class DataDatabricksJobJobSettingsSettingsTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTrigger | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTrigger | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _fileArrival;
    get fileArrival(): DataDatabricksJobJobSettingsSettingsTriggerFileArrivalOutputReference;
    putFileArrival(value: DataDatabricksJobJobSettingsSettingsTriggerFileArrival): void;
    resetFileArrival(): void;
    get fileArrivalInput(): DataDatabricksJobJobSettingsSettingsTriggerFileArrival | undefined;
    private _periodic;
    get periodic(): DataDatabricksJobJobSettingsSettingsTriggerPeriodicOutputReference;
    putPeriodic(value: DataDatabricksJobJobSettingsSettingsTriggerPeriodic): void;
    resetPeriodic(): void;
    get periodicInput(): DataDatabricksJobJobSettingsSettingsTriggerPeriodic | undefined;
    private _tableUpdate;
    get tableUpdate(): DataDatabricksJobJobSettingsSettingsTriggerTableUpdateOutputReference;
    putTableUpdate(value: DataDatabricksJobJobSettingsSettingsTriggerTableUpdate): void;
    resetTableUpdate(): void;
    get tableUpdateInput(): DataDatabricksJobJobSettingsSettingsTriggerTableUpdate | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailureToTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailureToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailureOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStartToTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStartToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStartOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccessToTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccessToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccessOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_duration_warning_threshold_exceeded DataDatabricksJob#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_failure DataDatabricksJob#on_failure}
    */
    readonly onFailure?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_start DataDatabricksJob#on_start}
    */
    readonly onStart?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_streaming_backlog_exceeded DataDatabricksJob#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#on_success DataDatabricksJob#on_success}
    */
    readonly onSuccess?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsWebhookNotifications): any;
export declare function dataDatabricksJobJobSettingsSettingsWebhookNotificationsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsWebhookNotifications): any;
export declare class DataDatabricksJobJobSettingsSettingsWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsWebhookNotifications | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailureList;
    putOnFailure(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnFailure[] | undefined;
    private _onStart;
    get onStart(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStartList;
    putOnStart(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccessList;
    putOnSuccess(value: DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsWebhookNotificationsOnSuccess[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#description DataDatabricksJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#edit_mode DataDatabricksJob#edit_mode}
    */
    readonly editMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#existing_cluster_id DataDatabricksJob#existing_cluster_id}
    */
    readonly existingClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#format DataDatabricksJob#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#max_concurrent_runs DataDatabricksJob#max_concurrent_runs}
    */
    readonly maxConcurrentRuns?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#max_retries DataDatabricksJob#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#min_retry_interval_millis DataDatabricksJob#min_retry_interval_millis}
    */
    readonly minRetryIntervalMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#name DataDatabricksJob#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#retry_on_timeout DataDatabricksJob#retry_on_timeout}
    */
    readonly retryOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#tags DataDatabricksJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#timeout_seconds DataDatabricksJob#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * continuous block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#continuous DataDatabricksJob#continuous}
    */
    readonly continuous?: DataDatabricksJobJobSettingsSettingsContinuous;
    /**
    * dbt_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#dbt_task DataDatabricksJob#dbt_task}
    */
    readonly dbtTask?: DataDatabricksJobJobSettingsSettingsDbtTask;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#deployment DataDatabricksJob#deployment}
    */
    readonly deployment?: DataDatabricksJobJobSettingsSettingsDeployment;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#email_notifications DataDatabricksJob#email_notifications}
    */
    readonly emailNotifications?: DataDatabricksJobJobSettingsSettingsEmailNotifications;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#environment DataDatabricksJob#environment}
    */
    readonly environment?: DataDatabricksJobJobSettingsSettingsEnvironment[] | cdktn.IResolvable;
    /**
    * git_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#git_source DataDatabricksJob#git_source}
    */
    readonly gitSource?: DataDatabricksJobJobSettingsSettingsGitSource;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#health DataDatabricksJob#health}
    */
    readonly health?: DataDatabricksJobJobSettingsSettingsHealth;
    /**
    * job_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#job_cluster DataDatabricksJob#job_cluster}
    */
    readonly jobCluster?: DataDatabricksJobJobSettingsSettingsJobCluster[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#library DataDatabricksJob#library}
    */
    readonly library?: DataDatabricksJobJobSettingsSettingsLibrary[] | cdktn.IResolvable;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#new_cluster DataDatabricksJob#new_cluster}
    */
    readonly newCluster?: DataDatabricksJobJobSettingsSettingsNewCluster;
    /**
    * notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notebook_task DataDatabricksJob#notebook_task}
    */
    readonly notebookTask?: DataDatabricksJobJobSettingsSettingsNotebookTask;
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#notification_settings DataDatabricksJob#notification_settings}
    */
    readonly notificationSettings?: DataDatabricksJobJobSettingsSettingsNotificationSettings;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#parameter DataDatabricksJob#parameter}
    */
    readonly parameter?: DataDatabricksJobJobSettingsSettingsParameter[] | cdktn.IResolvable;
    /**
    * pipeline_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#pipeline_task DataDatabricksJob#pipeline_task}
    */
    readonly pipelineTask?: DataDatabricksJobJobSettingsSettingsPipelineTask;
    /**
    * python_wheel_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#python_wheel_task DataDatabricksJob#python_wheel_task}
    */
    readonly pythonWheelTask?: DataDatabricksJobJobSettingsSettingsPythonWheelTask;
    /**
    * queue block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#queue DataDatabricksJob#queue}
    */
    readonly queue?: DataDatabricksJobJobSettingsSettingsQueue;
    /**
    * run_as block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#run_as DataDatabricksJob#run_as}
    */
    readonly runAs?: DataDatabricksJobJobSettingsSettingsRunAs;
    /**
    * run_job_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#run_job_task DataDatabricksJob#run_job_task}
    */
    readonly runJobTask?: DataDatabricksJobJobSettingsSettingsRunJobTask;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#schedule DataDatabricksJob#schedule}
    */
    readonly schedule?: DataDatabricksJobJobSettingsSettingsSchedule;
    /**
    * spark_jar_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_jar_task DataDatabricksJob#spark_jar_task}
    */
    readonly sparkJarTask?: DataDatabricksJobJobSettingsSettingsSparkJarTask;
    /**
    * spark_python_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_python_task DataDatabricksJob#spark_python_task}
    */
    readonly sparkPythonTask?: DataDatabricksJobJobSettingsSettingsSparkPythonTask;
    /**
    * spark_submit_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#spark_submit_task DataDatabricksJob#spark_submit_task}
    */
    readonly sparkSubmitTask?: DataDatabricksJobJobSettingsSettingsSparkSubmitTask;
    /**
    * task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#task DataDatabricksJob#task}
    */
    readonly task?: DataDatabricksJobJobSettingsSettingsTask[] | cdktn.IResolvable;
    /**
    * trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#trigger DataDatabricksJob#trigger}
    */
    readonly trigger?: DataDatabricksJobJobSettingsSettingsTrigger;
    /**
    * webhook_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#webhook_notifications DataDatabricksJob#webhook_notifications}
    */
    readonly webhookNotifications?: DataDatabricksJobJobSettingsSettingsWebhookNotifications;
}
export declare function dataDatabricksJobJobSettingsSettingsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsOutputReference | DataDatabricksJobJobSettingsSettings): any;
export declare function dataDatabricksJobJobSettingsSettingsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsOutputReference | DataDatabricksJobJobSettingsSettings): any;
export declare class DataDatabricksJobJobSettingsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettings | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettings | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _editMode?;
    get editMode(): string;
    set editMode(value: string);
    resetEditMode(): void;
    get editModeInput(): string | undefined;
    private _existingClusterId?;
    get existingClusterId(): string;
    set existingClusterId(value: string);
    resetExistingClusterId(): void;
    get existingClusterIdInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _maxConcurrentRuns?;
    get maxConcurrentRuns(): number;
    set maxConcurrentRuns(value: number);
    resetMaxConcurrentRuns(): void;
    get maxConcurrentRunsInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minRetryIntervalMillis?;
    get minRetryIntervalMillis(): number;
    set minRetryIntervalMillis(value: number);
    resetMinRetryIntervalMillis(): void;
    get minRetryIntervalMillisInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _retryOnTimeout?;
    get retryOnTimeout(): boolean | cdktn.IResolvable;
    set retryOnTimeout(value: boolean | cdktn.IResolvable);
    resetRetryOnTimeout(): void;
    get retryOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _continuous;
    get continuous(): DataDatabricksJobJobSettingsSettingsContinuousOutputReference;
    putContinuous(value: DataDatabricksJobJobSettingsSettingsContinuous): void;
    resetContinuous(): void;
    get continuousInput(): DataDatabricksJobJobSettingsSettingsContinuous | undefined;
    private _dbtTask;
    get dbtTask(): DataDatabricksJobJobSettingsSettingsDbtTaskOutputReference;
    putDbtTask(value: DataDatabricksJobJobSettingsSettingsDbtTask): void;
    resetDbtTask(): void;
    get dbtTaskInput(): DataDatabricksJobJobSettingsSettingsDbtTask | undefined;
    private _deployment;
    get deployment(): DataDatabricksJobJobSettingsSettingsDeploymentOutputReference;
    putDeployment(value: DataDatabricksJobJobSettingsSettingsDeployment): void;
    resetDeployment(): void;
    get deploymentInput(): DataDatabricksJobJobSettingsSettingsDeployment | undefined;
    private _emailNotifications;
    get emailNotifications(): DataDatabricksJobJobSettingsSettingsEmailNotificationsOutputReference;
    putEmailNotifications(value: DataDatabricksJobJobSettingsSettingsEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): DataDatabricksJobJobSettingsSettingsEmailNotifications | undefined;
    private _environment;
    get environment(): DataDatabricksJobJobSettingsSettingsEnvironmentList;
    putEnvironment(value: DataDatabricksJobJobSettingsSettingsEnvironment[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsEnvironment[] | undefined;
    private _gitSource;
    get gitSource(): DataDatabricksJobJobSettingsSettingsGitSourceOutputReference;
    putGitSource(value: DataDatabricksJobJobSettingsSettingsGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): DataDatabricksJobJobSettingsSettingsGitSource | undefined;
    private _health;
    get health(): DataDatabricksJobJobSettingsSettingsHealthOutputReference;
    putHealth(value: DataDatabricksJobJobSettingsSettingsHealth): void;
    resetHealth(): void;
    get healthInput(): DataDatabricksJobJobSettingsSettingsHealth | undefined;
    private _jobCluster;
    get jobCluster(): DataDatabricksJobJobSettingsSettingsJobClusterList;
    putJobCluster(value: DataDatabricksJobJobSettingsSettingsJobCluster[] | cdktn.IResolvable): void;
    resetJobCluster(): void;
    get jobClusterInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsJobCluster[] | undefined;
    private _library;
    get library(): DataDatabricksJobJobSettingsSettingsLibraryList;
    putLibrary(value: DataDatabricksJobJobSettingsSettingsLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsLibrary[] | undefined;
    private _newCluster;
    get newCluster(): DataDatabricksJobJobSettingsSettingsNewClusterOutputReference;
    putNewCluster(value: DataDatabricksJobJobSettingsSettingsNewCluster): void;
    resetNewCluster(): void;
    get newClusterInput(): DataDatabricksJobJobSettingsSettingsNewCluster | undefined;
    private _notebookTask;
    get notebookTask(): DataDatabricksJobJobSettingsSettingsNotebookTaskOutputReference;
    putNotebookTask(value: DataDatabricksJobJobSettingsSettingsNotebookTask): void;
    resetNotebookTask(): void;
    get notebookTaskInput(): DataDatabricksJobJobSettingsSettingsNotebookTask | undefined;
    private _notificationSettings;
    get notificationSettings(): DataDatabricksJobJobSettingsSettingsNotificationSettingsOutputReference;
    putNotificationSettings(value: DataDatabricksJobJobSettingsSettingsNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): DataDatabricksJobJobSettingsSettingsNotificationSettings | undefined;
    private _parameter;
    get parameter(): DataDatabricksJobJobSettingsSettingsParameterList;
    putParameter(value: DataDatabricksJobJobSettingsSettingsParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsParameter[] | undefined;
    private _pipelineTask;
    get pipelineTask(): DataDatabricksJobJobSettingsSettingsPipelineTaskOutputReference;
    putPipelineTask(value: DataDatabricksJobJobSettingsSettingsPipelineTask): void;
    resetPipelineTask(): void;
    get pipelineTaskInput(): DataDatabricksJobJobSettingsSettingsPipelineTask | undefined;
    private _pythonWheelTask;
    get pythonWheelTask(): DataDatabricksJobJobSettingsSettingsPythonWheelTaskOutputReference;
    putPythonWheelTask(value: DataDatabricksJobJobSettingsSettingsPythonWheelTask): void;
    resetPythonWheelTask(): void;
    get pythonWheelTaskInput(): DataDatabricksJobJobSettingsSettingsPythonWheelTask | undefined;
    private _queue;
    get queue(): DataDatabricksJobJobSettingsSettingsQueueOutputReference;
    putQueue(value: DataDatabricksJobJobSettingsSettingsQueue): void;
    resetQueue(): void;
    get queueInput(): DataDatabricksJobJobSettingsSettingsQueue | undefined;
    private _runAs;
    get runAs(): DataDatabricksJobJobSettingsSettingsRunAsOutputReference;
    putRunAs(value: DataDatabricksJobJobSettingsSettingsRunAs): void;
    resetRunAs(): void;
    get runAsInput(): DataDatabricksJobJobSettingsSettingsRunAs | undefined;
    private _runJobTask;
    get runJobTask(): DataDatabricksJobJobSettingsSettingsRunJobTaskOutputReference;
    putRunJobTask(value: DataDatabricksJobJobSettingsSettingsRunJobTask): void;
    resetRunJobTask(): void;
    get runJobTaskInput(): DataDatabricksJobJobSettingsSettingsRunJobTask | undefined;
    private _schedule;
    get schedule(): DataDatabricksJobJobSettingsSettingsScheduleOutputReference;
    putSchedule(value: DataDatabricksJobJobSettingsSettingsSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): DataDatabricksJobJobSettingsSettingsSchedule | undefined;
    private _sparkJarTask;
    get sparkJarTask(): DataDatabricksJobJobSettingsSettingsSparkJarTaskOutputReference;
    putSparkJarTask(value: DataDatabricksJobJobSettingsSettingsSparkJarTask): void;
    resetSparkJarTask(): void;
    get sparkJarTaskInput(): DataDatabricksJobJobSettingsSettingsSparkJarTask | undefined;
    private _sparkPythonTask;
    get sparkPythonTask(): DataDatabricksJobJobSettingsSettingsSparkPythonTaskOutputReference;
    putSparkPythonTask(value: DataDatabricksJobJobSettingsSettingsSparkPythonTask): void;
    resetSparkPythonTask(): void;
    get sparkPythonTaskInput(): DataDatabricksJobJobSettingsSettingsSparkPythonTask | undefined;
    private _sparkSubmitTask;
    get sparkSubmitTask(): DataDatabricksJobJobSettingsSettingsSparkSubmitTaskOutputReference;
    putSparkSubmitTask(value: DataDatabricksJobJobSettingsSettingsSparkSubmitTask): void;
    resetSparkSubmitTask(): void;
    get sparkSubmitTaskInput(): DataDatabricksJobJobSettingsSettingsSparkSubmitTask | undefined;
    private _task;
    get task(): DataDatabricksJobJobSettingsSettingsTaskList;
    putTask(value: DataDatabricksJobJobSettingsSettingsTask[] | cdktn.IResolvable): void;
    resetTask(): void;
    get taskInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTask[] | undefined;
    private _trigger;
    get trigger(): DataDatabricksJobJobSettingsSettingsTriggerOutputReference;
    putTrigger(value: DataDatabricksJobJobSettingsSettingsTrigger): void;
    resetTrigger(): void;
    get triggerInput(): DataDatabricksJobJobSettingsSettingsTrigger | undefined;
    private _webhookNotifications;
    get webhookNotifications(): DataDatabricksJobJobSettingsSettingsWebhookNotificationsOutputReference;
    putWebhookNotifications(value: DataDatabricksJobJobSettingsSettingsWebhookNotifications): void;
    resetWebhookNotifications(): void;
    get webhookNotificationsInput(): DataDatabricksJobJobSettingsSettingsWebhookNotifications | undefined;
}
export interface DataDatabricksJobJobSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#created_time DataDatabricksJob#created_time}
    */
    readonly createdTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#creator_user_name DataDatabricksJob#creator_user_name}
    */
    readonly creatorUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#job_id DataDatabricksJob#job_id}
    */
    readonly jobId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#run_as_user_name DataDatabricksJob#run_as_user_name}
    */
    readonly runAsUserName?: string;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#settings DataDatabricksJob#settings}
    */
    readonly settings?: DataDatabricksJobJobSettingsSettings;
}
export declare function dataDatabricksJobJobSettingsToTerraform(struct?: DataDatabricksJobJobSettingsOutputReference | DataDatabricksJobJobSettings): any;
export declare function dataDatabricksJobJobSettingsToHclTerraform(struct?: DataDatabricksJobJobSettingsOutputReference | DataDatabricksJobJobSettings): any;
export declare class DataDatabricksJobJobSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettings | undefined;
    set internalValue(value: DataDatabricksJobJobSettings | undefined);
    private _createdTime?;
    get createdTime(): number;
    set createdTime(value: number);
    resetCreatedTime(): void;
    get createdTimeInput(): number | undefined;
    private _creatorUserName?;
    get creatorUserName(): string;
    set creatorUserName(value: string);
    resetCreatorUserName(): void;
    get creatorUserNameInput(): string | undefined;
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    resetJobId(): void;
    get jobIdInput(): number | undefined;
    private _runAsUserName?;
    get runAsUserName(): string;
    set runAsUserName(value: string);
    resetRunAsUserName(): void;
    get runAsUserNameInput(): string | undefined;
    private _settings;
    get settings(): DataDatabricksJobJobSettingsSettingsOutputReference;
    putSettings(value: DataDatabricksJobJobSettingsSettings): void;
    resetSettings(): void;
    get settingsInput(): DataDatabricksJobJobSettingsSettings | undefined;
}
export interface DataDatabricksJobProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/job#workspace_id DataDatabricksJob#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksJobProviderConfigToTerraform(struct?: DataDatabricksJobProviderConfigOutputReference | DataDatabricksJobProviderConfig): any;
export declare function dataDatabricksJobProviderConfigToHclTerraform(struct?: DataDatabricksJobProviderConfigOutputReference | DataDatabricksJobProviderConfig): any;
export declare class DataDatabricksJobProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobProviderConfig | undefined;
    set internalValue(value: DataDatabricksJobProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
