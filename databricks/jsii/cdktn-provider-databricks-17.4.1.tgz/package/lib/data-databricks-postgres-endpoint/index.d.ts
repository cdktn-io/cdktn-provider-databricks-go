/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#name DataDatabricksPostgresEndpoint#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#provider_config DataDatabricksPostgresEndpoint#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresEndpointProviderConfig;
}
export interface DataDatabricksPostgresEndpointProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#workspace_id DataDatabricksPostgresEndpoint#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresEndpointProviderConfigToTerraform(struct?: DataDatabricksPostgresEndpointProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresEndpointProviderConfigToHclTerraform(struct?: DataDatabricksPostgresEndpointProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresEndpointProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresEndpointSpecGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#enable_readable_secondaries DataDatabricksPostgresEndpoint#enable_readable_secondaries}
    */
    readonly enableReadableSecondaries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#max DataDatabricksPostgresEndpoint#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#min DataDatabricksPostgresEndpoint#min}
    */
    readonly min: number;
}
export declare function dataDatabricksPostgresEndpointSpecGroupToTerraform(struct?: DataDatabricksPostgresEndpointSpecGroup | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresEndpointSpecGroupToHclTerraform(struct?: DataDatabricksPostgresEndpointSpecGroup | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresEndpointSpecGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointSpecGroup | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointSpecGroup | cdktn.IResolvable | undefined);
    private _enableReadableSecondaries?;
    get enableReadableSecondaries(): boolean | cdktn.IResolvable;
    set enableReadableSecondaries(value: boolean | cdktn.IResolvable);
    resetEnableReadableSecondaries(): void;
    get enableReadableSecondariesInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface DataDatabricksPostgresEndpointSpecSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#pg_settings DataDatabricksPostgresEndpoint#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksPostgresEndpointSpecSettingsToTerraform(struct?: DataDatabricksPostgresEndpointSpecSettings | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresEndpointSpecSettingsToHclTerraform(struct?: DataDatabricksPostgresEndpointSpecSettings | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresEndpointSpecSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointSpecSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointSpecSettings | cdktn.IResolvable | undefined);
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksPostgresEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#autoscaling_limit_max_cu DataDatabricksPostgresEndpoint#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#autoscaling_limit_min_cu DataDatabricksPostgresEndpoint#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#disabled DataDatabricksPostgresEndpoint#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#endpoint_type DataDatabricksPostgresEndpoint#endpoint_type}
    */
    readonly endpointType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#group DataDatabricksPostgresEndpoint#group}
    */
    readonly group?: DataDatabricksPostgresEndpointSpecGroup;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#no_suspension DataDatabricksPostgresEndpoint#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#settings DataDatabricksPostgresEndpoint#settings}
    */
    readonly settings?: DataDatabricksPostgresEndpointSpecSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#suspend_timeout_duration DataDatabricksPostgresEndpoint#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresEndpointSpecToTerraform(struct?: DataDatabricksPostgresEndpointSpec): any;
export declare function dataDatabricksPostgresEndpointSpecToHclTerraform(struct?: DataDatabricksPostgresEndpointSpec): any;
export declare class DataDatabricksPostgresEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointSpec | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointSpec | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    get endpointTypeInput(): string | undefined;
    private _group;
    get group(): DataDatabricksPostgresEndpointSpecGroupOutputReference;
    putGroup(value: DataDatabricksPostgresEndpointSpecGroup): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | DataDatabricksPostgresEndpointSpecGroup | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _settings;
    get settings(): DataDatabricksPostgresEndpointSpecSettingsOutputReference;
    putSettings(value: DataDatabricksPostgresEndpointSpecSettings): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | DataDatabricksPostgresEndpointSpecSettings | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresEndpointStatusGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#max DataDatabricksPostgresEndpoint#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#min DataDatabricksPostgresEndpoint#min}
    */
    readonly min: number;
}
export declare function dataDatabricksPostgresEndpointStatusGroupToTerraform(struct?: DataDatabricksPostgresEndpointStatusGroup): any;
export declare function dataDatabricksPostgresEndpointStatusGroupToHclTerraform(struct?: DataDatabricksPostgresEndpointStatusGroup): any;
export declare class DataDatabricksPostgresEndpointStatusGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointStatusGroup | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointStatusGroup | undefined);
    get enableReadableSecondaries(): cdktn.IResolvable;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface DataDatabricksPostgresEndpointStatusHosts {
}
export declare function dataDatabricksPostgresEndpointStatusHostsToTerraform(struct?: DataDatabricksPostgresEndpointStatusHosts): any;
export declare function dataDatabricksPostgresEndpointStatusHostsToHclTerraform(struct?: DataDatabricksPostgresEndpointStatusHosts): any;
export declare class DataDatabricksPostgresEndpointStatusHostsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointStatusHosts | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointStatusHosts | undefined);
    get host(): string;
    get readOnlyHost(): string;
}
export interface DataDatabricksPostgresEndpointStatusSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#pg_settings DataDatabricksPostgresEndpoint#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksPostgresEndpointStatusSettingsToTerraform(struct?: DataDatabricksPostgresEndpointStatusSettings): any;
export declare function dataDatabricksPostgresEndpointStatusSettingsToHclTerraform(struct?: DataDatabricksPostgresEndpointStatusSettings): any;
export declare class DataDatabricksPostgresEndpointStatusSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointStatusSettings | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointStatusSettings | undefined);
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksPostgresEndpointStatus {
}
export declare function dataDatabricksPostgresEndpointStatusToTerraform(struct?: DataDatabricksPostgresEndpointStatus): any;
export declare function dataDatabricksPostgresEndpointStatusToHclTerraform(struct?: DataDatabricksPostgresEndpointStatus): any;
export declare class DataDatabricksPostgresEndpointStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresEndpointStatus | undefined;
    set internalValue(value: DataDatabricksPostgresEndpointStatus | undefined);
    get autoscalingLimitMaxCu(): number;
    get autoscalingLimitMinCu(): number;
    get currentState(): string;
    get disabled(): cdktn.IResolvable;
    get endpointId(): string;
    get endpointType(): string;
    private _group;
    get group(): DataDatabricksPostgresEndpointStatusGroupOutputReference;
    private _hosts;
    get hosts(): DataDatabricksPostgresEndpointStatusHostsOutputReference;
    get pendingState(): string;
    private _settings;
    get settings(): DataDatabricksPostgresEndpointStatusSettingsOutputReference;
    get suspendTimeoutDuration(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint databricks_postgres_endpoint}
*/
export declare class DataDatabricksPostgresEndpoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_endpoint";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresEndpoint to import
    * @param importFromId The id of the existing DataDatabricksPostgresEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/postgres_endpoint databricks_postgres_endpoint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresEndpointConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresEndpointConfig);
    get createTime(): string;
    get endpointId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresEndpointProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresEndpointProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresEndpointProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresEndpointSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresEndpointStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
