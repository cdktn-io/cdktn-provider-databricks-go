/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksFeatureEngineeringFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#full_name DataDatabricksFeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#provider_config DataDatabricksFeatureEngineeringFeature#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringFeatureProviderConfig;
}
export interface DataDatabricksFeatureEngineeringFeatureEntities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureEntitiesToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureEntities): any;
export declare function dataDatabricksFeatureEngineeringFeatureEntitiesToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureEntities): any;
export declare class DataDatabricksFeatureEngineeringFeatureEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureEntities | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureEntities | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeatureEntitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringFeatureEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeatureEntitiesOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#relative_sd DataDatabricksFeatureEngineeringFeature#relative_sd}
    */
    readonly relativeSd?: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _relativeSd?;
    get relativeSd(): number;
    set relativeSd(value: number);
    resetRelativeSd(): void;
    get relativeSdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#accuracy DataDatabricksFeatureEngineeringFeature#accuracy}
    */
    readonly accuracy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#percentile DataDatabricksFeatureEngineeringFeature#percentile}
    */
    readonly percentile: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined);
    private _accuracy?;
    get accuracy(): number;
    set accuracy(value: number);
    resetAccuracy(): void;
    get accuracyInput(): number | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    get percentileInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#offset DataDatabricksFeatureEngineeringFeature#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#delay DataDatabricksFeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#slide_duration DataDatabricksFeatureEngineeringFeature#slide_duration}
    */
    readonly slideDuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined);
    private _slideDuration?;
    get slideDuration(): string;
    set slideDuration(value: string);
    get slideDurationInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined);
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#continuous DataDatabricksFeatureEngineeringFeature#continuous}
    */
    readonly continuous?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#rolling DataDatabricksFeatureEngineeringFeature#rolling}
    */
    readonly rolling?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#sliding DataDatabricksFeatureEngineeringFeature#sliding}
    */
    readonly sliding?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#tumbling DataDatabricksFeatureEngineeringFeature#tumbling}
    */
    readonly tumbling?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined);
    private _continuous;
    get continuous(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousOutputReference;
    putContinuous(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous): void;
    resetContinuous(): void;
    get continuousInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | undefined;
    private _rolling;
    get rolling(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingOutputReference;
    putRolling(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling): void;
    resetRolling(): void;
    get rollingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | undefined;
    private _sliding;
    get sliding(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingOutputReference;
    putSliding(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding): void;
    resetSliding(): void;
    get slidingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | undefined;
    private _tumbling;
    get tumbling(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingOutputReference;
    putTumbling(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling): void;
    resetTumbling(): void;
    get tumblingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#approx_count_distinct DataDatabricksFeatureEngineeringFeature#approx_count_distinct}
    */
    readonly approxCountDistinct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#approx_percentile DataDatabricksFeatureEngineeringFeature#approx_percentile}
    */
    readonly approxPercentile?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#avg DataDatabricksFeatureEngineeringFeature#avg}
    */
    readonly avg?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#count_function DataDatabricksFeatureEngineeringFeature#count_function}
    */
    readonly countFunction?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#first DataDatabricksFeatureEngineeringFeature#first}
    */
    readonly first?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#last DataDatabricksFeatureEngineeringFeature#last}
    */
    readonly last?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#max DataDatabricksFeatureEngineeringFeature#max}
    */
    readonly max?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#min DataDatabricksFeatureEngineeringFeature#min}
    */
    readonly min?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#stddev_pop DataDatabricksFeatureEngineeringFeature#stddev_pop}
    */
    readonly stddevPop?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#stddev_samp DataDatabricksFeatureEngineeringFeature#stddev_samp}
    */
    readonly stddevSamp?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#sum DataDatabricksFeatureEngineeringFeature#sum}
    */
    readonly sum?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#time_window DataDatabricksFeatureEngineeringFeature#time_window}
    */
    readonly timeWindow?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#var_pop DataDatabricksFeatureEngineeringFeature#var_pop}
    */
    readonly varPop?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#var_samp DataDatabricksFeatureEngineeringFeature#var_samp}
    */
    readonly varSamp?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable | undefined);
    private _approxCountDistinct;
    get approxCountDistinct(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctOutputReference;
    putApproxCountDistinct(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct): void;
    resetApproxCountDistinct(): void;
    get approxCountDistinctInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | undefined;
    private _approxPercentile;
    get approxPercentile(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileOutputReference;
    putApproxPercentile(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile): void;
    resetApproxPercentile(): void;
    get approxPercentileInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | undefined;
    private _avg;
    get avg(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgOutputReference;
    putAvg(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg): void;
    resetAvg(): void;
    get avgInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | undefined;
    private _countFunction;
    get countFunction(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionOutputReference;
    putCountFunction(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction): void;
    resetCountFunction(): void;
    get countFunctionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | undefined;
    private _first;
    get first(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstOutputReference;
    putFirst(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst): void;
    resetFirst(): void;
    get firstInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | undefined;
    private _last;
    get last(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastOutputReference;
    putLast(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast): void;
    resetLast(): void;
    get lastInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | undefined;
    private _max;
    get max(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxOutputReference;
    putMax(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax): void;
    resetMax(): void;
    get maxInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | undefined;
    private _min;
    get min(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinOutputReference;
    putMin(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin): void;
    resetMin(): void;
    get minInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | undefined;
    private _stddevPop;
    get stddevPop(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopOutputReference;
    putStddevPop(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop): void;
    resetStddevPop(): void;
    get stddevPopInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | undefined;
    private _stddevSamp;
    get stddevSamp(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampOutputReference;
    putStddevSamp(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp): void;
    resetStddevSamp(): void;
    get stddevSampInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | undefined;
    private _sum;
    get sum(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumOutputReference;
    putSum(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum): void;
    resetSum(): void;
    get sumInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | undefined;
    private _timeWindow;
    get timeWindow(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowOutputReference;
    putTimeWindow(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | undefined;
    private _varPop;
    get varPop(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopOutputReference;
    putVarPop(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop): void;
    resetVarPop(): void;
    get varPopInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | undefined;
    private _varSamp;
    get varSamp(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampOutputReference;
    putVarSamp(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp): void;
    resetVarSamp(): void;
    get varSampInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#column DataDatabricksFeatureEngineeringFeature#column}
    */
    readonly column: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#key DataDatabricksFeatureEngineeringFeature#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#value DataDatabricksFeatureEngineeringFeature#value}
    */
    readonly value: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionExtraParametersToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionExtraParametersToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionExtraParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeatureFunctionExtraParametersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeatureFunctionExtraParametersOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeatureFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#aggregation_function DataDatabricksFeatureEngineeringFeature#aggregation_function}
    */
    readonly aggregationFunction?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#column_selection DataDatabricksFeatureEngineeringFeature#column_selection}
    */
    readonly columnSelection?: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#extra_parameters DataDatabricksFeatureEngineeringFeature#extra_parameters}
    */
    readonly extraParameters?: DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#function_type DataDatabricksFeatureEngineeringFeature#function_type}
    */
    readonly functionType?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunction): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunction): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunction | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunction | undefined);
    private _aggregationFunction;
    get aggregationFunction(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionOutputReference;
    putAggregationFunction(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction): void;
    resetAggregationFunction(): void;
    get aggregationFunctionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | undefined;
    private _columnSelection;
    get columnSelection(): DataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionOutputReference;
    putColumnSelection(value: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection): void;
    resetColumnSelection(): void;
    get columnSelectionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | undefined;
    private _extraParameters;
    get extraParameters(): DataDatabricksFeatureEngineeringFeatureFunctionExtraParametersList;
    putExtraParameters(value: DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters[] | cdktn.IResolvable): void;
    resetExtraParameters(): void;
    get extraParametersInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionExtraParameters[] | undefined;
    private _functionType?;
    get functionType(): string;
    set functionType(value: string);
    resetFunctionType(): void;
    get functionTypeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureLineageContextJobContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#job_id DataDatabricksFeatureEngineeringFeature#job_id}
    */
    readonly jobId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#job_run_id DataDatabricksFeatureEngineeringFeature#job_run_id}
    */
    readonly jobRunId?: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextJobContextToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextJobContextToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureLineageContextJobContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    resetJobId(): void;
    get jobIdInput(): number | undefined;
    private _jobRunId?;
    get jobRunId(): number;
    set jobRunId(value: number);
    resetJobRunId(): void;
    get jobRunIdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureLineageContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#job_context DataDatabricksFeatureEngineeringFeature#job_context}
    */
    readonly jobContext?: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#notebook_id DataDatabricksFeatureEngineeringFeature#notebook_id}
    */
    readonly notebookId?: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContext): any;
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContext): any;
export declare class DataDatabricksFeatureEngineeringFeatureLineageContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureLineageContext | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureLineageContext | undefined);
    private _jobContext;
    get jobContext(): DataDatabricksFeatureEngineeringFeatureLineageContextJobContextOutputReference;
    putJobContext(value: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext): void;
    resetJobContext(): void;
    get jobContextInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | undefined;
    private _notebookId?;
    get notebookId(): number;
    set notebookId(value: number);
    resetNotebookId(): void;
    get notebookIdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#workspace_id DataDatabricksFeatureEngineeringFeature#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#dataframe_schema DataDatabricksFeatureEngineeringFeature#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#entity_columns DataDatabricksFeatureEngineeringFeature#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#filter_condition DataDatabricksFeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#full_name DataDatabricksFeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#timeseries_column DataDatabricksFeatureEngineeringFeature#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#transformation_sql DataDatabricksFeatureEngineeringFeature#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#variant_expr_path DataDatabricksFeatureEngineeringFeature#variant_expr_path}
    */
    readonly variantExprPath: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable | undefined);
    private _variantExprPath?;
    get variantExprPath(): string;
    set variantExprPath(value: string);
    get variantExprPathInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#variant_expr_path DataDatabricksFeatureEngineeringFeature#variant_expr_path}
    */
    readonly variantExprPath: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable | undefined);
    private _variantExprPath?;
    get variantExprPath(): string;
    set variantExprPath(value: string);
    get variantExprPathInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceKafkaSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#entity_column_identifiers DataDatabricksFeatureEngineeringFeature#entity_column_identifiers}
    */
    readonly entityColumnIdentifiers?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#filter_condition DataDatabricksFeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#timeseries_column_identifier DataDatabricksFeatureEngineeringFeature#timeseries_column_identifier}
    */
    readonly timeseriesColumnIdentifier?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable | undefined);
    private _entityColumnIdentifiers;
    get entityColumnIdentifiers(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersList;
    putEntityColumnIdentifiers(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable): void;
    resetEntityColumnIdentifiers(): void;
    get entityColumnIdentifiersInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _timeseriesColumnIdentifier;
    get timeseriesColumnIdentifier(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierOutputReference;
    putTimeseriesColumnIdentifier(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier): void;
    resetTimeseriesColumnIdentifier(): void;
    get timeseriesColumnIdentifierInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#data_type DataDatabricksFeatureEngineeringFeature#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#fields DataDatabricksFeatureEngineeringFeature#fields}
    */
    readonly fields: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable | undefined);
    private _fields;
    get fields(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsList;
    putFields(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceRequestSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#flat_schema DataDatabricksFeatureEngineeringFeature#flat_schema}
    */
    readonly flatSchema?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable | undefined);
    private _flatSchema;
    get flatSchema(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaOutputReference;
    putFlatSchema(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema): void;
    resetFlatSchema(): void;
    get flatSchemaInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceStreamSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#filter_condition DataDatabricksFeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#full_name DataDatabricksFeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceStreamSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceStreamSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceStreamSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable | undefined);
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#delta_table_source DataDatabricksFeatureEngineeringFeature#delta_table_source}
    */
    readonly deltaTableSource?: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#kafka_source DataDatabricksFeatureEngineeringFeature#kafka_source}
    */
    readonly kafkaSource?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#request_source DataDatabricksFeatureEngineeringFeature#request_source}
    */
    readonly requestSource?: DataDatabricksFeatureEngineeringFeatureSourceRequestSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#stream_source DataDatabricksFeatureEngineeringFeature#stream_source}
    */
    readonly streamSource?: DataDatabricksFeatureEngineeringFeatureSourceStreamSource;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSource): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSource): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSource | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSource | undefined);
    private _deltaTableSource;
    get deltaTableSource(): DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | undefined;
    private _kafkaSource;
    get kafkaSource(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceOutputReference;
    putKafkaSource(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource): void;
    resetKafkaSource(): void;
    get kafkaSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | undefined;
    private _requestSource;
    get requestSource(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceOutputReference;
    putRequestSource(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSource): void;
    resetRequestSource(): void;
    get requestSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceRequestSource | undefined;
    private _streamSource;
    get streamSource(): DataDatabricksFeatureEngineeringFeatureSourceStreamSourceOutputReference;
    putStreamSource(value: DataDatabricksFeatureEngineeringFeatureSourceStreamSource): void;
    resetStreamSource(): void;
    get streamSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceStreamSource | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#offset DataDatabricksFeatureEngineeringFeature#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowContinuousToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowContinuousToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureTimeWindowContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureTimeWindowRolling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#delay DataDatabricksFeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowRollingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowRollingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureTimeWindowRollingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureTimeWindowSliding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#slide_duration DataDatabricksFeatureEngineeringFeature#slide_duration}
    */
    readonly slideDuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowSlidingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowSlidingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureTimeWindowSlidingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable | undefined);
    private _slideDuration?;
    get slideDuration(): string;
    set slideDuration(value: string);
    get slideDurationInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowTumblingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowTumblingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureTimeWindowTumblingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable | undefined);
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#continuous DataDatabricksFeatureEngineeringFeature#continuous}
    */
    readonly continuous?: DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#rolling DataDatabricksFeatureEngineeringFeature#rolling}
    */
    readonly rolling?: DataDatabricksFeatureEngineeringFeatureTimeWindowRolling;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#sliding DataDatabricksFeatureEngineeringFeature#sliding}
    */
    readonly sliding?: DataDatabricksFeatureEngineeringFeatureTimeWindowSliding;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#tumbling DataDatabricksFeatureEngineeringFeature#tumbling}
    */
    readonly tumbling?: DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling;
}
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindow): any;
export declare function dataDatabricksFeatureEngineeringFeatureTimeWindowToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeWindow): any;
export declare class DataDatabricksFeatureEngineeringFeatureTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureTimeWindow | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureTimeWindow | undefined);
    private _continuous;
    get continuous(): DataDatabricksFeatureEngineeringFeatureTimeWindowContinuousOutputReference;
    putContinuous(value: DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous): void;
    resetContinuous(): void;
    get continuousInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureTimeWindowContinuous | undefined;
    private _rolling;
    get rolling(): DataDatabricksFeatureEngineeringFeatureTimeWindowRollingOutputReference;
    putRolling(value: DataDatabricksFeatureEngineeringFeatureTimeWindowRolling): void;
    resetRolling(): void;
    get rollingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureTimeWindowRolling | undefined;
    private _sliding;
    get sliding(): DataDatabricksFeatureEngineeringFeatureTimeWindowSlidingOutputReference;
    putSliding(value: DataDatabricksFeatureEngineeringFeatureTimeWindowSliding): void;
    resetSliding(): void;
    get slidingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureTimeWindowSliding | undefined;
    private _tumbling;
    get tumbling(): DataDatabricksFeatureEngineeringFeatureTimeWindowTumblingOutputReference;
    putTumbling(value: DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling): void;
    resetTumbling(): void;
    get tumblingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureTimeWindowTumbling | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureTimeseriesColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureTimeseriesColumnToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeseriesColumn): any;
export declare function dataDatabricksFeatureEngineeringFeatureTimeseriesColumnToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeseriesColumn): any;
export declare class DataDatabricksFeatureEngineeringFeatureTimeseriesColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureTimeseriesColumn | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureTimeseriesColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature databricks_feature_engineering_feature}
*/
export declare class DataDatabricksFeatureEngineeringFeature extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_feature_engineering_feature";
    /**
    * Generates CDKTN code for importing a DataDatabricksFeatureEngineeringFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksFeatureEngineeringFeature to import
    * @param importFromId The id of the existing DataDatabricksFeatureEngineeringFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksFeatureEngineeringFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/feature_engineering_feature databricks_feature_engineering_feature} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksFeatureEngineeringFeatureConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksFeatureEngineeringFeatureConfig);
    get catalogName(): string;
    get createdAt(): string;
    get createdBy(): string;
    get description(): string;
    private _entities;
    get entities(): DataDatabricksFeatureEngineeringFeatureEntitiesList;
    get filterCondition(): string;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _function;
    get function(): DataDatabricksFeatureEngineeringFeatureFunctionOutputReference;
    get inputs(): string[];
    private _lineageContext;
    get lineageContext(): DataDatabricksFeatureEngineeringFeatureLineageContextOutputReference;
    get name(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringFeatureProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringFeatureProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureProviderConfig | undefined;
    get schemaName(): string;
    private _source;
    get source(): DataDatabricksFeatureEngineeringFeatureSourceOutputReference;
    private _timeWindow;
    get timeWindow(): DataDatabricksFeatureEngineeringFeatureTimeWindowOutputReference;
    private _timeseriesColumn;
    get timeseriesColumn(): DataDatabricksFeatureEngineeringFeatureTimeseriesColumnOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
