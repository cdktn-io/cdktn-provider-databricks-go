/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#comment Token#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#creation_time Token#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#expiry_time Token#expiry_time}
    */
    readonly expiryTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#id Token#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#lifetime_seconds Token#lifetime_seconds}
    */
    readonly lifetimeSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#token_id Token#token_id}
    */
    readonly tokenId?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#provider_config Token#provider_config}
    */
    readonly providerConfig?: TokenProviderConfig;
}
export interface TokenProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#workspace_id Token#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function tokenProviderConfigToTerraform(struct?: TokenProviderConfigOutputReference | TokenProviderConfig): any;
export declare function tokenProviderConfigToHclTerraform(struct?: TokenProviderConfigOutputReference | TokenProviderConfig): any;
export declare class TokenProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TokenProviderConfig | undefined;
    set internalValue(value: TokenProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token databricks_token}
*/
export declare class Token extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_token";
    /**
    * Generates CDKTN code for importing a Token resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Token to import
    * @param importFromId The id of the existing Token that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Token to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/token databricks_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TokenConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TokenConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _expiryTime?;
    get expiryTime(): number;
    set expiryTime(value: number);
    resetExpiryTime(): void;
    get expiryTimeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lifetimeSeconds?;
    get lifetimeSeconds(): number;
    set lifetimeSeconds(value: number);
    resetLifetimeSeconds(): void;
    get lifetimeSecondsInput(): number | undefined;
    private _tokenId?;
    get tokenId(): string;
    set tokenId(value: string);
    resetTokenId(): void;
    get tokenIdInput(): string | undefined;
    get tokenValue(): string;
    private _providerConfig;
    get providerConfig(): TokenProviderConfigOutputReference;
    putProviderConfig(value: TokenProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): TokenProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
