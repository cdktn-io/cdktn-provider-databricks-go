/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksNotebookPathsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths#id DataDatabricksNotebookPaths#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths#path DataDatabricksNotebookPaths#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths#recursive DataDatabricksNotebookPaths#recursive}
    */
    readonly recursive: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths#provider_config DataDatabricksNotebookPaths#provider_config}
    */
    readonly providerConfig?: DataDatabricksNotebookPathsProviderConfig;
}
export interface DataDatabricksNotebookPathsNotebookPathListStruct {
}
export declare function dataDatabricksNotebookPathsNotebookPathListStructToTerraform(struct?: DataDatabricksNotebookPathsNotebookPathListStruct): any;
export declare function dataDatabricksNotebookPathsNotebookPathListStructToHclTerraform(struct?: DataDatabricksNotebookPathsNotebookPathListStruct): any;
export declare class DataDatabricksNotebookPathsNotebookPathListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksNotebookPathsNotebookPathListStruct | undefined;
    set internalValue(value: DataDatabricksNotebookPathsNotebookPathListStruct | undefined);
    get language(): string;
    get path(): string;
}
export declare class DataDatabricksNotebookPathsNotebookPathListStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksNotebookPathsNotebookPathListStructOutputReference;
}
export interface DataDatabricksNotebookPathsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths#workspace_id DataDatabricksNotebookPaths#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksNotebookPathsProviderConfigToTerraform(struct?: DataDatabricksNotebookPathsProviderConfigOutputReference | DataDatabricksNotebookPathsProviderConfig): any;
export declare function dataDatabricksNotebookPathsProviderConfigToHclTerraform(struct?: DataDatabricksNotebookPathsProviderConfigOutputReference | DataDatabricksNotebookPathsProviderConfig): any;
export declare class DataDatabricksNotebookPathsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksNotebookPathsProviderConfig | undefined;
    set internalValue(value: DataDatabricksNotebookPathsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths databricks_notebook_paths}
*/
export declare class DataDatabricksNotebookPaths extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_notebook_paths";
    /**
    * Generates CDKTN code for importing a DataDatabricksNotebookPaths resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksNotebookPaths to import
    * @param importFromId The id of the existing DataDatabricksNotebookPaths that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksNotebookPaths to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/notebook_paths databricks_notebook_paths} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksNotebookPathsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksNotebookPathsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _notebookPathList;
    get notebookPathList(): DataDatabricksNotebookPathsNotebookPathListStructList;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _recursive?;
    get recursive(): boolean | cdktn.IResolvable;
    set recursive(value: boolean | cdktn.IResolvable);
    get recursiveInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksNotebookPathsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksNotebookPathsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksNotebookPathsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
