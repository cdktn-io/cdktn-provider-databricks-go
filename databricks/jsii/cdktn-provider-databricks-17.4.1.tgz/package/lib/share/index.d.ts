/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#comment Share#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#name Share#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#owner Share#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#storage_root Share#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#object Share#object}
    */
    readonly object?: ShareObject[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#provider_config Share#provider_config}
    */
    readonly providerConfig?: ShareProviderConfig[] | cdktn.IResolvable;
}
export interface ShareObjectPartitionValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#name Share#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#op Share#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#recipient_property_key Share#recipient_property_key}
    */
    readonly recipientPropertyKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#value Share#value}
    */
    readonly value?: string;
}
export declare function shareObjectPartitionValueToTerraform(struct?: ShareObjectPartitionValue | cdktn.IResolvable): any;
export declare function shareObjectPartitionValueToHclTerraform(struct?: ShareObjectPartitionValue | cdktn.IResolvable): any;
export declare class ShareObjectPartitionValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ShareObjectPartitionValue | cdktn.IResolvable | undefined;
    set internalValue(value: ShareObjectPartitionValue | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _recipientPropertyKey?;
    get recipientPropertyKey(): string;
    set recipientPropertyKey(value: string);
    resetRecipientPropertyKey(): void;
    get recipientPropertyKeyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ShareObjectPartitionValueList extends cdktn.ComplexList {
    internalValue?: ShareObjectPartitionValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ShareObjectPartitionValueOutputReference;
}
export interface ShareObjectPartition {
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#value Share#value}
    */
    readonly value?: ShareObjectPartitionValue[] | cdktn.IResolvable;
}
export declare function shareObjectPartitionToTerraform(struct?: ShareObjectPartition | cdktn.IResolvable): any;
export declare function shareObjectPartitionToHclTerraform(struct?: ShareObjectPartition | cdktn.IResolvable): any;
export declare class ShareObjectPartitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ShareObjectPartition | cdktn.IResolvable | undefined;
    set internalValue(value: ShareObjectPartition | cdktn.IResolvable | undefined);
    private _value;
    get value(): ShareObjectPartitionValueList;
    putValue(value: ShareObjectPartitionValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | ShareObjectPartitionValue[] | undefined;
}
export declare class ShareObjectPartitionList extends cdktn.ComplexList {
    internalValue?: ShareObjectPartition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ShareObjectPartitionOutputReference;
}
export interface ShareObject {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#cdf_enabled Share#cdf_enabled}
    */
    readonly cdfEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#comment Share#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#content Share#content}
    */
    readonly content?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#data_object_type Share#data_object_type}
    */
    readonly dataObjectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#history_data_sharing_status Share#history_data_sharing_status}
    */
    readonly historyDataSharingStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#name Share#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#shared_as Share#shared_as}
    */
    readonly sharedAs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#start_version Share#start_version}
    */
    readonly startVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#string_shared_as Share#string_shared_as}
    */
    readonly stringSharedAs?: string;
    /**
    * partition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#partition Share#partition}
    */
    readonly partition?: ShareObjectPartition[] | cdktn.IResolvable;
}
export declare function shareObjectToTerraform(struct?: ShareObject | cdktn.IResolvable): any;
export declare function shareObjectToHclTerraform(struct?: ShareObject | cdktn.IResolvable): any;
export declare class ShareObjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ShareObject | cdktn.IResolvable | undefined;
    set internalValue(value: ShareObject | cdktn.IResolvable | undefined);
    get addedAt(): number;
    get addedBy(): string;
    private _cdfEnabled?;
    get cdfEnabled(): boolean | cdktn.IResolvable;
    set cdfEnabled(value: boolean | cdktn.IResolvable);
    resetCdfEnabled(): void;
    get cdfEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _dataObjectType?;
    get dataObjectType(): string;
    set dataObjectType(value: string);
    get dataObjectTypeInput(): string | undefined;
    get effectiveCdfEnabled(): cdktn.IResolvable;
    get effectiveHistoryDataSharingStatus(): string;
    get effectiveSharedAs(): string;
    get effectiveStartVersion(): number;
    get effectiveStringSharedAs(): string;
    private _historyDataSharingStatus?;
    get historyDataSharingStatus(): string;
    set historyDataSharingStatus(value: string);
    resetHistoryDataSharingStatus(): void;
    get historyDataSharingStatusInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sharedAs?;
    get sharedAs(): string;
    set sharedAs(value: string);
    resetSharedAs(): void;
    get sharedAsInput(): string | undefined;
    private _startVersion?;
    get startVersion(): number;
    set startVersion(value: number);
    resetStartVersion(): void;
    get startVersionInput(): number | undefined;
    get status(): string;
    private _stringSharedAs?;
    get stringSharedAs(): string;
    set stringSharedAs(value: string);
    resetStringSharedAs(): void;
    get stringSharedAsInput(): string | undefined;
    private _partition;
    get partition(): ShareObjectPartitionList;
    putPartition(value: ShareObjectPartition[] | cdktn.IResolvable): void;
    resetPartition(): void;
    get partitionInput(): cdktn.IResolvable | ShareObjectPartition[] | undefined;
}
export declare class ShareObjectList extends cdktn.ComplexList {
    internalValue?: ShareObject[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ShareObjectOutputReference;
}
export interface ShareProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#workspace_id Share#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function shareProviderConfigToTerraform(struct?: ShareProviderConfig | cdktn.IResolvable): any;
export declare function shareProviderConfigToHclTerraform(struct?: ShareProviderConfig | cdktn.IResolvable): any;
export declare class ShareProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ShareProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ShareProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class ShareProviderConfigList extends cdktn.ComplexList {
    internalValue?: ShareProviderConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ShareProviderConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share databricks_share}
*/
export declare class Share extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_share";
    /**
    * Generates CDKTN code for importing a Share resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Share to import
    * @param importFromId The id of the existing Share that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Share to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/share databricks_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ShareConfig
    */
    constructor(scope: Construct, id: string, config: ShareConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdAt(): number;
    get createdBy(): string;
    get effectiveOwner(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    get storageLocation(): string;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    get updatedAt(): number;
    get updatedBy(): string;
    private _object;
    get object(): ShareObjectList;
    putObject(value: ShareObject[] | cdktn.IResolvable): void;
    resetObject(): void;
    get objectInput(): cdktn.IResolvable | ShareObject[] | undefined;
    private _providerConfig;
    get providerConfig(): ShareProviderConfigList;
    putProviderConfig(value: ShareProviderConfig[] | cdktn.IResolvable): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | ShareProviderConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
