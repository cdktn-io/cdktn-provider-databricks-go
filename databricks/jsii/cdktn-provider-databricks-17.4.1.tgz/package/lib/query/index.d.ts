/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface QueryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#apply_auto_limit Query#apply_auto_limit}
    */
    readonly applyAutoLimit?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#catalog Query#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#description Query#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#display_name Query#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#owner_user_name Query#owner_user_name}
    */
    readonly ownerUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#parent_path Query#parent_path}
    */
    readonly parentPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#query_text Query#query_text}
    */
    readonly queryText: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#run_as_mode Query#run_as_mode}
    */
    readonly runAsMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#schema Query#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#tags Query#tags}
    */
    readonly tags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#warehouse_id Query#warehouse_id}
    */
    readonly warehouseId: string;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#parameter Query#parameter}
    */
    readonly parameter?: QueryParameter[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#provider_config Query#provider_config}
    */
    readonly providerConfig?: QueryProviderConfig;
}
export interface QueryParameterDateRangeValueDateRangeValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#end Query#end}
    */
    readonly end: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#start Query#start}
    */
    readonly start: string;
}
export declare function queryParameterDateRangeValueDateRangeValueToTerraform(struct?: QueryParameterDateRangeValueDateRangeValueOutputReference | QueryParameterDateRangeValueDateRangeValue): any;
export declare function queryParameterDateRangeValueDateRangeValueToHclTerraform(struct?: QueryParameterDateRangeValueDateRangeValueOutputReference | QueryParameterDateRangeValueDateRangeValue): any;
export declare class QueryParameterDateRangeValueDateRangeValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterDateRangeValueDateRangeValue | undefined;
    set internalValue(value: QueryParameterDateRangeValueDateRangeValue | undefined);
    private _end?;
    get end(): string;
    set end(value: string);
    get endInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    get startInput(): string | undefined;
}
export interface QueryParameterDateRangeValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#dynamic_date_range_value Query#dynamic_date_range_value}
    */
    readonly dynamicDateRangeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#precision Query#precision}
    */
    readonly precision?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#start_day_of_week Query#start_day_of_week}
    */
    readonly startDayOfWeek?: number;
    /**
    * date_range_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#date_range_value Query#date_range_value}
    */
    readonly dateRangeValue?: QueryParameterDateRangeValueDateRangeValue;
}
export declare function queryParameterDateRangeValueToTerraform(struct?: QueryParameterDateRangeValueOutputReference | QueryParameterDateRangeValue): any;
export declare function queryParameterDateRangeValueToHclTerraform(struct?: QueryParameterDateRangeValueOutputReference | QueryParameterDateRangeValue): any;
export declare class QueryParameterDateRangeValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterDateRangeValue | undefined;
    set internalValue(value: QueryParameterDateRangeValue | undefined);
    private _dynamicDateRangeValue?;
    get dynamicDateRangeValue(): string;
    set dynamicDateRangeValue(value: string);
    resetDynamicDateRangeValue(): void;
    get dynamicDateRangeValueInput(): string | undefined;
    private _precision?;
    get precision(): string;
    set precision(value: string);
    resetPrecision(): void;
    get precisionInput(): string | undefined;
    private _startDayOfWeek?;
    get startDayOfWeek(): number;
    set startDayOfWeek(value: number);
    resetStartDayOfWeek(): void;
    get startDayOfWeekInput(): number | undefined;
    private _dateRangeValue;
    get dateRangeValue(): QueryParameterDateRangeValueDateRangeValueOutputReference;
    putDateRangeValue(value: QueryParameterDateRangeValueDateRangeValue): void;
    resetDateRangeValue(): void;
    get dateRangeValueInput(): QueryParameterDateRangeValueDateRangeValue | undefined;
}
export interface QueryParameterDateValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#date_value Query#date_value}
    */
    readonly dateValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#dynamic_date_value Query#dynamic_date_value}
    */
    readonly dynamicDateValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#precision Query#precision}
    */
    readonly precision?: string;
}
export declare function queryParameterDateValueToTerraform(struct?: QueryParameterDateValueOutputReference | QueryParameterDateValue): any;
export declare function queryParameterDateValueToHclTerraform(struct?: QueryParameterDateValueOutputReference | QueryParameterDateValue): any;
export declare class QueryParameterDateValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterDateValue | undefined;
    set internalValue(value: QueryParameterDateValue | undefined);
    private _dateValue?;
    get dateValue(): string;
    set dateValue(value: string);
    resetDateValue(): void;
    get dateValueInput(): string | undefined;
    private _dynamicDateValue?;
    get dynamicDateValue(): string;
    set dynamicDateValue(value: string);
    resetDynamicDateValue(): void;
    get dynamicDateValueInput(): string | undefined;
    private _precision?;
    get precision(): string;
    set precision(value: string);
    resetPrecision(): void;
    get precisionInput(): string | undefined;
}
export interface QueryParameterEnumValueMultiValuesOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#prefix Query#prefix}
    */
    readonly prefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#separator Query#separator}
    */
    readonly separator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#suffix Query#suffix}
    */
    readonly suffix?: string;
}
export declare function queryParameterEnumValueMultiValuesOptionsToTerraform(struct?: QueryParameterEnumValueMultiValuesOptionsOutputReference | QueryParameterEnumValueMultiValuesOptions): any;
export declare function queryParameterEnumValueMultiValuesOptionsToHclTerraform(struct?: QueryParameterEnumValueMultiValuesOptionsOutputReference | QueryParameterEnumValueMultiValuesOptions): any;
export declare class QueryParameterEnumValueMultiValuesOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterEnumValueMultiValuesOptions | undefined;
    set internalValue(value: QueryParameterEnumValueMultiValuesOptions | undefined);
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _separator?;
    get separator(): string;
    set separator(value: string);
    resetSeparator(): void;
    get separatorInput(): string | undefined;
    private _suffix?;
    get suffix(): string;
    set suffix(value: string);
    resetSuffix(): void;
    get suffixInput(): string | undefined;
}
export interface QueryParameterEnumValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#enum_options Query#enum_options}
    */
    readonly enumOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#values Query#values}
    */
    readonly values?: string[];
    /**
    * multi_values_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#multi_values_options Query#multi_values_options}
    */
    readonly multiValuesOptions?: QueryParameterEnumValueMultiValuesOptions;
}
export declare function queryParameterEnumValueToTerraform(struct?: QueryParameterEnumValueOutputReference | QueryParameterEnumValue): any;
export declare function queryParameterEnumValueToHclTerraform(struct?: QueryParameterEnumValueOutputReference | QueryParameterEnumValue): any;
export declare class QueryParameterEnumValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterEnumValue | undefined;
    set internalValue(value: QueryParameterEnumValue | undefined);
    private _enumOptions?;
    get enumOptions(): string;
    set enumOptions(value: string);
    resetEnumOptions(): void;
    get enumOptionsInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
    private _multiValuesOptions;
    get multiValuesOptions(): QueryParameterEnumValueMultiValuesOptionsOutputReference;
    putMultiValuesOptions(value: QueryParameterEnumValueMultiValuesOptions): void;
    resetMultiValuesOptions(): void;
    get multiValuesOptionsInput(): QueryParameterEnumValueMultiValuesOptions | undefined;
}
export interface QueryParameterNumericValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#value Query#value}
    */
    readonly value: number;
}
export declare function queryParameterNumericValueToTerraform(struct?: QueryParameterNumericValueOutputReference | QueryParameterNumericValue): any;
export declare function queryParameterNumericValueToHclTerraform(struct?: QueryParameterNumericValueOutputReference | QueryParameterNumericValue): any;
export declare class QueryParameterNumericValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterNumericValue | undefined;
    set internalValue(value: QueryParameterNumericValue | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface QueryParameterQueryBackedValueMultiValuesOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#prefix Query#prefix}
    */
    readonly prefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#separator Query#separator}
    */
    readonly separator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#suffix Query#suffix}
    */
    readonly suffix?: string;
}
export declare function queryParameterQueryBackedValueMultiValuesOptionsToTerraform(struct?: QueryParameterQueryBackedValueMultiValuesOptionsOutputReference | QueryParameterQueryBackedValueMultiValuesOptions): any;
export declare function queryParameterQueryBackedValueMultiValuesOptionsToHclTerraform(struct?: QueryParameterQueryBackedValueMultiValuesOptionsOutputReference | QueryParameterQueryBackedValueMultiValuesOptions): any;
export declare class QueryParameterQueryBackedValueMultiValuesOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterQueryBackedValueMultiValuesOptions | undefined;
    set internalValue(value: QueryParameterQueryBackedValueMultiValuesOptions | undefined);
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _separator?;
    get separator(): string;
    set separator(value: string);
    resetSeparator(): void;
    get separatorInput(): string | undefined;
    private _suffix?;
    get suffix(): string;
    set suffix(value: string);
    resetSuffix(): void;
    get suffixInput(): string | undefined;
}
export interface QueryParameterQueryBackedValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#query_id Query#query_id}
    */
    readonly queryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#values Query#values}
    */
    readonly values?: string[];
    /**
    * multi_values_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#multi_values_options Query#multi_values_options}
    */
    readonly multiValuesOptions?: QueryParameterQueryBackedValueMultiValuesOptions;
}
export declare function queryParameterQueryBackedValueToTerraform(struct?: QueryParameterQueryBackedValueOutputReference | QueryParameterQueryBackedValue): any;
export declare function queryParameterQueryBackedValueToHclTerraform(struct?: QueryParameterQueryBackedValueOutputReference | QueryParameterQueryBackedValue): any;
export declare class QueryParameterQueryBackedValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterQueryBackedValue | undefined;
    set internalValue(value: QueryParameterQueryBackedValue | undefined);
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
    private _multiValuesOptions;
    get multiValuesOptions(): QueryParameterQueryBackedValueMultiValuesOptionsOutputReference;
    putMultiValuesOptions(value: QueryParameterQueryBackedValueMultiValuesOptions): void;
    resetMultiValuesOptions(): void;
    get multiValuesOptionsInput(): QueryParameterQueryBackedValueMultiValuesOptions | undefined;
}
export interface QueryParameterTextValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#value Query#value}
    */
    readonly value: string;
}
export declare function queryParameterTextValueToTerraform(struct?: QueryParameterTextValueOutputReference | QueryParameterTextValue): any;
export declare function queryParameterTextValueToHclTerraform(struct?: QueryParameterTextValueOutputReference | QueryParameterTextValue): any;
export declare class QueryParameterTextValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryParameterTextValue | undefined;
    set internalValue(value: QueryParameterTextValue | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface QueryParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#name Query#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#title Query#title}
    */
    readonly title?: string;
    /**
    * date_range_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#date_range_value Query#date_range_value}
    */
    readonly dateRangeValue?: QueryParameterDateRangeValue;
    /**
    * date_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#date_value Query#date_value}
    */
    readonly dateValue?: QueryParameterDateValue;
    /**
    * enum_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#enum_value Query#enum_value}
    */
    readonly enumValue?: QueryParameterEnumValue;
    /**
    * numeric_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#numeric_value Query#numeric_value}
    */
    readonly numericValue?: QueryParameterNumericValue;
    /**
    * query_backed_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#query_backed_value Query#query_backed_value}
    */
    readonly queryBackedValue?: QueryParameterQueryBackedValue;
    /**
    * text_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#text_value Query#text_value}
    */
    readonly textValue?: QueryParameterTextValue;
}
export declare function queryParameterToTerraform(struct?: QueryParameter | cdktn.IResolvable): any;
export declare function queryParameterToHclTerraform(struct?: QueryParameter | cdktn.IResolvable): any;
export declare class QueryParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QueryParameter | cdktn.IResolvable | undefined;
    set internalValue(value: QueryParameter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _dateRangeValue;
    get dateRangeValue(): QueryParameterDateRangeValueOutputReference;
    putDateRangeValue(value: QueryParameterDateRangeValue): void;
    resetDateRangeValue(): void;
    get dateRangeValueInput(): QueryParameterDateRangeValue | undefined;
    private _dateValue;
    get dateValue(): QueryParameterDateValueOutputReference;
    putDateValue(value: QueryParameterDateValue): void;
    resetDateValue(): void;
    get dateValueInput(): QueryParameterDateValue | undefined;
    private _enumValue;
    get enumValue(): QueryParameterEnumValueOutputReference;
    putEnumValue(value: QueryParameterEnumValue): void;
    resetEnumValue(): void;
    get enumValueInput(): QueryParameterEnumValue | undefined;
    private _numericValue;
    get numericValue(): QueryParameterNumericValueOutputReference;
    putNumericValue(value: QueryParameterNumericValue): void;
    resetNumericValue(): void;
    get numericValueInput(): QueryParameterNumericValue | undefined;
    private _queryBackedValue;
    get queryBackedValue(): QueryParameterQueryBackedValueOutputReference;
    putQueryBackedValue(value: QueryParameterQueryBackedValue): void;
    resetQueryBackedValue(): void;
    get queryBackedValueInput(): QueryParameterQueryBackedValue | undefined;
    private _textValue;
    get textValue(): QueryParameterTextValueOutputReference;
    putTextValue(value: QueryParameterTextValue): void;
    resetTextValue(): void;
    get textValueInput(): QueryParameterTextValue | undefined;
}
export declare class QueryParameterList extends cdktn.ComplexList {
    internalValue?: QueryParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QueryParameterOutputReference;
}
export interface QueryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#workspace_id Query#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function queryProviderConfigToTerraform(struct?: QueryProviderConfigOutputReference | QueryProviderConfig): any;
export declare function queryProviderConfigToHclTerraform(struct?: QueryProviderConfigOutputReference | QueryProviderConfig): any;
export declare class QueryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): QueryProviderConfig | undefined;
    set internalValue(value: QueryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query databricks_query}
*/
export declare class Query extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_query";
    /**
    * Generates CDKTN code for importing a Query resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Query to import
    * @param importFromId The id of the existing Query that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Query to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/query databricks_query} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options QueryConfig
    */
    constructor(scope: Construct, id: string, config: QueryConfig);
    private _applyAutoLimit?;
    get applyAutoLimit(): boolean | cdktn.IResolvable;
    set applyAutoLimit(value: boolean | cdktn.IResolvable);
    resetApplyAutoLimit(): void;
    get applyAutoLimitInput(): boolean | cdktn.IResolvable | undefined;
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    get lastModifierUserName(): string;
    get lifecycleState(): string;
    private _ownerUserName?;
    get ownerUserName(): string;
    set ownerUserName(value: string);
    resetOwnerUserName(): void;
    get ownerUserNameInput(): string | undefined;
    private _parentPath?;
    get parentPath(): string;
    set parentPath(value: string);
    resetParentPath(): void;
    get parentPathInput(): string | undefined;
    private _queryText?;
    get queryText(): string;
    set queryText(value: string);
    get queryTextInput(): string | undefined;
    private _runAsMode?;
    get runAsMode(): string;
    set runAsMode(value: string);
    resetRunAsMode(): void;
    get runAsModeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updateTime(): string;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    private _parameter;
    get parameter(): QueryParameterList;
    putParameter(value: QueryParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | QueryParameter[] | undefined;
    private _providerConfig;
    get providerConfig(): QueryProviderConfigOutputReference;
    putProviderConfig(value: QueryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): QueryProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
