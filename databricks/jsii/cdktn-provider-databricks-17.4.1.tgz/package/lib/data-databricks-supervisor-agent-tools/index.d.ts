/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSupervisorAgentToolsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#page_size DataDatabricksSupervisorAgentTools#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#parent DataDatabricksSupervisorAgentTools#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#provider_config DataDatabricksSupervisorAgentTools#provider_config}
    */
    readonly providerConfig?: DataDatabricksSupervisorAgentToolsProviderConfig;
}
export interface DataDatabricksSupervisorAgentToolsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#workspace_id DataDatabricksSupervisorAgentTools#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSupervisorAgentToolsProviderConfigToTerraform(struct?: DataDatabricksSupervisorAgentToolsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSupervisorAgentToolsProviderConfigToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSupervisorAgentToolsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsToolsApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#name DataDatabricksSupervisorAgentTools#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolsToolsAppToTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsApp): any;
export declare function dataDatabricksSupervisorAgentToolsToolsAppToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsApp): any;
export declare class DataDatabricksSupervisorAgentToolsToolsAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsToolsApp | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsToolsApp | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsToolsGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#id DataDatabricksSupervisorAgentTools#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksSupervisorAgentToolsToolsGenieSpaceToTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsGenieSpace): any;
export declare function dataDatabricksSupervisorAgentToolsToolsGenieSpaceToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsGenieSpace): any;
export declare class DataDatabricksSupervisorAgentToolsToolsGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsToolsGenieSpace | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsToolsGenieSpace | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsToolsKnowledgeAssistant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#knowledge_assistant_id DataDatabricksSupervisorAgentTools#knowledge_assistant_id}
    */
    readonly knowledgeAssistantId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#serving_endpoint_name DataDatabricksSupervisorAgentTools#serving_endpoint_name}
    */
    readonly servingEndpointName?: string;
}
export declare function dataDatabricksSupervisorAgentToolsToolsKnowledgeAssistantToTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsKnowledgeAssistant): any;
export declare function dataDatabricksSupervisorAgentToolsToolsKnowledgeAssistantToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsKnowledgeAssistant): any;
export declare class DataDatabricksSupervisorAgentToolsToolsKnowledgeAssistantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsToolsKnowledgeAssistant | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsToolsKnowledgeAssistant | undefined);
    private _knowledgeAssistantId?;
    get knowledgeAssistantId(): string;
    set knowledgeAssistantId(value: string);
    get knowledgeAssistantIdInput(): string | undefined;
    private _servingEndpointName?;
    get servingEndpointName(): string;
    set servingEndpointName(value: string);
    resetServingEndpointName(): void;
    get servingEndpointNameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsToolsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#workspace_id DataDatabricksSupervisorAgentTools#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSupervisorAgentToolsToolsProviderConfigToTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSupervisorAgentToolsToolsProviderConfigToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSupervisorAgentToolsToolsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsToolsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsToolsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsToolsUcConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#name DataDatabricksSupervisorAgentTools#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolsToolsUcConnectionToTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsUcConnection): any;
export declare function dataDatabricksSupervisorAgentToolsToolsUcConnectionToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsUcConnection): any;
export declare class DataDatabricksSupervisorAgentToolsToolsUcConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsToolsUcConnection | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsToolsUcConnection | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsToolsUcFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#name DataDatabricksSupervisorAgentTools#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolsToolsUcFunctionToTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsUcFunction): any;
export declare function dataDatabricksSupervisorAgentToolsToolsUcFunctionToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsUcFunction): any;
export declare class DataDatabricksSupervisorAgentToolsToolsUcFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsToolsUcFunction | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsToolsUcFunction | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsToolsVolume {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#name DataDatabricksSupervisorAgentTools#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolsToolsVolumeToTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsVolume): any;
export declare function dataDatabricksSupervisorAgentToolsToolsVolumeToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsToolsVolume): any;
export declare class DataDatabricksSupervisorAgentToolsToolsVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolsToolsVolume | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsToolsVolume | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolsTools {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#name DataDatabricksSupervisorAgentTools#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#provider_config DataDatabricksSupervisorAgentTools#provider_config}
    */
    readonly providerConfig?: DataDatabricksSupervisorAgentToolsToolsProviderConfig;
}
export declare function dataDatabricksSupervisorAgentToolsToolsToTerraform(struct?: DataDatabricksSupervisorAgentToolsTools): any;
export declare function dataDatabricksSupervisorAgentToolsToolsToHclTerraform(struct?: DataDatabricksSupervisorAgentToolsTools): any;
export declare class DataDatabricksSupervisorAgentToolsToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksSupervisorAgentToolsTools | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolsTools | undefined);
    private _app;
    get app(): DataDatabricksSupervisorAgentToolsToolsAppOutputReference;
    get description(): string;
    private _genieSpace;
    get genieSpace(): DataDatabricksSupervisorAgentToolsToolsGenieSpaceOutputReference;
    get id(): string;
    private _knowledgeAssistant;
    get knowledgeAssistant(): DataDatabricksSupervisorAgentToolsToolsKnowledgeAssistantOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSupervisorAgentToolsToolsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSupervisorAgentToolsToolsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSupervisorAgentToolsToolsProviderConfig | undefined;
    get toolId(): string;
    get toolType(): string;
    private _ucConnection;
    get ucConnection(): DataDatabricksSupervisorAgentToolsToolsUcConnectionOutputReference;
    private _ucFunction;
    get ucFunction(): DataDatabricksSupervisorAgentToolsToolsUcFunctionOutputReference;
    private _volume;
    get volume(): DataDatabricksSupervisorAgentToolsToolsVolumeOutputReference;
}
export declare class DataDatabricksSupervisorAgentToolsToolsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksSupervisorAgentToolsTools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksSupervisorAgentToolsToolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools databricks_supervisor_agent_tools}
*/
export declare class DataDatabricksSupervisorAgentTools extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_supervisor_agent_tools";
    /**
    * Generates CDKTN code for importing a DataDatabricksSupervisorAgentTools resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSupervisorAgentTools to import
    * @param importFromId The id of the existing DataDatabricksSupervisorAgentTools that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSupervisorAgentTools to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tools databricks_supervisor_agent_tools} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSupervisorAgentToolsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksSupervisorAgentToolsConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSupervisorAgentToolsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSupervisorAgentToolsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSupervisorAgentToolsProviderConfig | undefined;
    private _tools;
    get tools(): DataDatabricksSupervisorAgentToolsToolsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
