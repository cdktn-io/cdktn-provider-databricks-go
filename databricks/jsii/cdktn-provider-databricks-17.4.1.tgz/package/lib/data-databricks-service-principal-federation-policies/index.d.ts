/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksServicePrincipalFederationPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#page_size DataDatabricksServicePrincipalFederationPolicies#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#service_principal_id DataDatabricksServicePrincipalFederationPolicies#service_principal_id}
    */
    readonly servicePrincipalId: number;
}
export interface DataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#audiences DataDatabricksServicePrincipalFederationPolicies#audiences}
    */
    readonly audiences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#issuer DataDatabricksServicePrincipalFederationPolicies#issuer}
    */
    readonly issuer?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#jwks_json DataDatabricksServicePrincipalFederationPolicies#jwks_json}
    */
    readonly jwksJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#jwks_uri DataDatabricksServicePrincipalFederationPolicies#jwks_uri}
    */
    readonly jwksUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#subject DataDatabricksServicePrincipalFederationPolicies#subject}
    */
    readonly subject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#subject_claim DataDatabricksServicePrincipalFederationPolicies#subject_claim}
    */
    readonly subjectClaim?: string;
}
export declare function dataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicyToTerraform(struct?: DataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicy): any;
export declare function dataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicyToHclTerraform(struct?: DataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicy): any;
export declare class DataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicy | undefined;
    set internalValue(value: DataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicy | undefined);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    resetAudiences(): void;
    get audiencesInput(): string[] | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
    private _jwksJson?;
    get jwksJson(): string;
    set jwksJson(value: string);
    resetJwksJson(): void;
    get jwksJsonInput(): string | undefined;
    private _jwksUri?;
    get jwksUri(): string;
    set jwksUri(value: string);
    resetJwksUri(): void;
    get jwksUriInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
    private _subjectClaim?;
    get subjectClaim(): string;
    set subjectClaim(value: string);
    resetSubjectClaim(): void;
    get subjectClaimInput(): string | undefined;
}
export interface DataDatabricksServicePrincipalFederationPoliciesPolicies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#policy_id DataDatabricksServicePrincipalFederationPolicies#policy_id}
    */
    readonly policyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#service_principal_id DataDatabricksServicePrincipalFederationPolicies#service_principal_id}
    */
    readonly servicePrincipalId: number;
}
export declare function dataDatabricksServicePrincipalFederationPoliciesPoliciesToTerraform(struct?: DataDatabricksServicePrincipalFederationPoliciesPolicies): any;
export declare function dataDatabricksServicePrincipalFederationPoliciesPoliciesToHclTerraform(struct?: DataDatabricksServicePrincipalFederationPoliciesPolicies): any;
export declare class DataDatabricksServicePrincipalFederationPoliciesPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServicePrincipalFederationPoliciesPolicies | undefined;
    set internalValue(value: DataDatabricksServicePrincipalFederationPoliciesPolicies | undefined);
    get createTime(): string;
    get description(): string;
    get name(): string;
    private _oidcPolicy;
    get oidcPolicy(): DataDatabricksServicePrincipalFederationPoliciesPoliciesOidcPolicyOutputReference;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): number;
    set servicePrincipalId(value: number);
    get servicePrincipalIdInput(): number | undefined;
    get uid(): string;
    get updateTime(): string;
}
export declare class DataDatabricksServicePrincipalFederationPoliciesPoliciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServicePrincipalFederationPoliciesPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServicePrincipalFederationPoliciesPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies databricks_service_principal_federation_policies}
*/
export declare class DataDatabricksServicePrincipalFederationPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_service_principal_federation_policies";
    /**
    * Generates CDKTN code for importing a DataDatabricksServicePrincipalFederationPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksServicePrincipalFederationPolicies to import
    * @param importFromId The id of the existing DataDatabricksServicePrincipalFederationPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksServicePrincipalFederationPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/service_principal_federation_policies databricks_service_principal_federation_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksServicePrincipalFederationPoliciesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksServicePrincipalFederationPoliciesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _policies;
    get policies(): DataDatabricksServicePrincipalFederationPoliciesPoliciesList;
    private _servicePrincipalId?;
    get servicePrincipalId(): number;
    set servicePrincipalId(value: number);
    get servicePrincipalIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
