/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSupervisorAgentToolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#name DataDatabricksSupervisorAgentTool#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#provider_config DataDatabricksSupervisorAgentTool#provider_config}
    */
    readonly providerConfig?: DataDatabricksSupervisorAgentToolProviderConfig;
}
export interface DataDatabricksSupervisorAgentToolApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#name DataDatabricksSupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolAppToTerraform(struct?: DataDatabricksSupervisorAgentToolApp): any;
export declare function dataDatabricksSupervisorAgentToolAppToHclTerraform(struct?: DataDatabricksSupervisorAgentToolApp): any;
export declare class DataDatabricksSupervisorAgentToolAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolApp | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolApp | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#id DataDatabricksSupervisorAgentTool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksSupervisorAgentToolGenieSpaceToTerraform(struct?: DataDatabricksSupervisorAgentToolGenieSpace): any;
export declare function dataDatabricksSupervisorAgentToolGenieSpaceToHclTerraform(struct?: DataDatabricksSupervisorAgentToolGenieSpace): any;
export declare class DataDatabricksSupervisorAgentToolGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolGenieSpace | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolGenieSpace | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolKnowledgeAssistant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#knowledge_assistant_id DataDatabricksSupervisorAgentTool#knowledge_assistant_id}
    */
    readonly knowledgeAssistantId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#serving_endpoint_name DataDatabricksSupervisorAgentTool#serving_endpoint_name}
    */
    readonly servingEndpointName?: string;
}
export declare function dataDatabricksSupervisorAgentToolKnowledgeAssistantToTerraform(struct?: DataDatabricksSupervisorAgentToolKnowledgeAssistant): any;
export declare function dataDatabricksSupervisorAgentToolKnowledgeAssistantToHclTerraform(struct?: DataDatabricksSupervisorAgentToolKnowledgeAssistant): any;
export declare class DataDatabricksSupervisorAgentToolKnowledgeAssistantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolKnowledgeAssistant | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolKnowledgeAssistant | undefined);
    private _knowledgeAssistantId?;
    get knowledgeAssistantId(): string;
    set knowledgeAssistantId(value: string);
    get knowledgeAssistantIdInput(): string | undefined;
    private _servingEndpointName?;
    get servingEndpointName(): string;
    set servingEndpointName(value: string);
    resetServingEndpointName(): void;
    get servingEndpointNameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#workspace_id DataDatabricksSupervisorAgentTool#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSupervisorAgentToolProviderConfigToTerraform(struct?: DataDatabricksSupervisorAgentToolProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSupervisorAgentToolProviderConfigToHclTerraform(struct?: DataDatabricksSupervisorAgentToolProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSupervisorAgentToolProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolUcConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#name DataDatabricksSupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolUcConnectionToTerraform(struct?: DataDatabricksSupervisorAgentToolUcConnection): any;
export declare function dataDatabricksSupervisorAgentToolUcConnectionToHclTerraform(struct?: DataDatabricksSupervisorAgentToolUcConnection): any;
export declare class DataDatabricksSupervisorAgentToolUcConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolUcConnection | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolUcConnection | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolUcFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#name DataDatabricksSupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolUcFunctionToTerraform(struct?: DataDatabricksSupervisorAgentToolUcFunction): any;
export declare function dataDatabricksSupervisorAgentToolUcFunctionToHclTerraform(struct?: DataDatabricksSupervisorAgentToolUcFunction): any;
export declare class DataDatabricksSupervisorAgentToolUcFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolUcFunction | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolUcFunction | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentToolVolume {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#name DataDatabricksSupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function dataDatabricksSupervisorAgentToolVolumeToTerraform(struct?: DataDatabricksSupervisorAgentToolVolume): any;
export declare function dataDatabricksSupervisorAgentToolVolumeToHclTerraform(struct?: DataDatabricksSupervisorAgentToolVolume): any;
export declare class DataDatabricksSupervisorAgentToolVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentToolVolume | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentToolVolume | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool databricks_supervisor_agent_tool}
*/
export declare class DataDatabricksSupervisorAgentTool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_supervisor_agent_tool";
    /**
    * Generates CDKTN code for importing a DataDatabricksSupervisorAgentTool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSupervisorAgentTool to import
    * @param importFromId The id of the existing DataDatabricksSupervisorAgentTool that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSupervisorAgentTool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/supervisor_agent_tool databricks_supervisor_agent_tool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSupervisorAgentToolConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksSupervisorAgentToolConfig);
    private _app;
    get app(): DataDatabricksSupervisorAgentToolAppOutputReference;
    get description(): string;
    private _genieSpace;
    get genieSpace(): DataDatabricksSupervisorAgentToolGenieSpaceOutputReference;
    get id(): string;
    private _knowledgeAssistant;
    get knowledgeAssistant(): DataDatabricksSupervisorAgentToolKnowledgeAssistantOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSupervisorAgentToolProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSupervisorAgentToolProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSupervisorAgentToolProviderConfig | undefined;
    get toolId(): string;
    get toolType(): string;
    private _ucConnection;
    get ucConnection(): DataDatabricksSupervisorAgentToolUcConnectionOutputReference;
    private _ucFunction;
    get ucFunction(): DataDatabricksSupervisorAgentToolUcFunctionOutputReference;
    private _volume;
    get volume(): DataDatabricksSupervisorAgentToolVolumeOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
