/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataQualityMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#anomaly_detection_config DataQualityMonitor#anomaly_detection_config}
    */
    readonly anomalyDetectionConfig?: DataQualityMonitorAnomalyDetectionConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#data_profiling_config DataQualityMonitor#data_profiling_config}
    */
    readonly dataProfilingConfig?: DataQualityMonitorDataProfilingConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#object_id DataQualityMonitor#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#object_type DataQualityMonitor#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#provider_config DataQualityMonitor#provider_config}
    */
    readonly providerConfig?: DataQualityMonitorProviderConfig;
}
export interface DataQualityMonitorAnomalyDetectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#excluded_table_full_names DataQualityMonitor#excluded_table_full_names}
    */
    readonly excludedTableFullNames?: string[];
}
export declare function dataQualityMonitorAnomalyDetectionConfigToTerraform(struct?: DataQualityMonitorAnomalyDetectionConfig | cdktn.IResolvable): any;
export declare function dataQualityMonitorAnomalyDetectionConfigToHclTerraform(struct?: DataQualityMonitorAnomalyDetectionConfig | cdktn.IResolvable): any;
export declare class DataQualityMonitorAnomalyDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorAnomalyDetectionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorAnomalyDetectionConfig | cdktn.IResolvable | undefined);
    private _excludedTableFullNames?;
    get excludedTableFullNames(): string[];
    set excludedTableFullNames(value: string[]);
    resetExcludedTableFullNames(): void;
    get excludedTableFullNamesInput(): string[] | undefined;
}
export interface DataQualityMonitorDataProfilingConfigCustomMetrics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#definition DataQualityMonitor#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#input_columns DataQualityMonitor#input_columns}
    */
    readonly inputColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#name DataQualityMonitor#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#output_data_type DataQualityMonitor#output_data_type}
    */
    readonly outputDataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#type DataQualityMonitor#type}
    */
    readonly type: string;
}
export declare function dataQualityMonitorDataProfilingConfigCustomMetricsToTerraform(struct?: DataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigCustomMetricsToHclTerraform(struct?: DataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _inputColumns?;
    get inputColumns(): string[];
    set inputColumns(value: string[]);
    get inputColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputDataType?;
    get outputDataType(): string;
    set outputDataType(value: string);
    get outputDataTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class DataQualityMonitorDataProfilingConfigCustomMetricsList extends cdktn.ComplexList {
    internalValue?: DataQualityMonitorDataProfilingConfigCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataQualityMonitorDataProfilingConfigCustomMetricsOutputReference;
}
export interface DataQualityMonitorDataProfilingConfigInferenceLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#granularities DataQualityMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#label_column DataQualityMonitor#label_column}
    */
    readonly labelColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#model_id_column DataQualityMonitor#model_id_column}
    */
    readonly modelIdColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#prediction_column DataQualityMonitor#prediction_column}
    */
    readonly predictionColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#problem_type DataQualityMonitor#problem_type}
    */
    readonly problemType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#timestamp_column DataQualityMonitor#timestamp_column}
    */
    readonly timestampColumn: string;
}
export declare function dataQualityMonitorDataProfilingConfigInferenceLogToTerraform(struct?: DataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigInferenceLogToHclTerraform(struct?: DataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigInferenceLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _labelColumn?;
    get labelColumn(): string;
    set labelColumn(value: string);
    resetLabelColumn(): void;
    get labelColumnInput(): string | undefined;
    private _modelIdColumn?;
    get modelIdColumn(): string;
    set modelIdColumn(value: string);
    get modelIdColumnInput(): string | undefined;
    private _predictionColumn?;
    get predictionColumn(): string;
    set predictionColumn(value: string);
    get predictionColumnInput(): string | undefined;
    private _problemType?;
    get problemType(): string;
    set problemType(value: string);
    get problemTypeInput(): string | undefined;
    private _timestampColumn?;
    get timestampColumn(): string;
    set timestampColumn(value: string);
    get timestampColumnInput(): string | undefined;
}
export interface DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#email_addresses DataQualityMonitor#email_addresses}
    */
    readonly emailAddresses?: string[];
}
export declare function dataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureToTerraform(struct?: DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureToHclTerraform(struct?: DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable | undefined);
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
}
export interface DataQualityMonitorDataProfilingConfigNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#on_failure DataQualityMonitor#on_failure}
    */
    readonly onFailure?: DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure;
}
export declare function dataQualityMonitorDataProfilingConfigNotificationSettingsToTerraform(struct?: DataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigNotificationSettingsToHclTerraform(struct?: DataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable | undefined);
    private _onFailure;
    get onFailure(): DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureOutputReference;
    putOnFailure(value: DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | undefined;
}
export interface DataQualityMonitorDataProfilingConfigSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#quartz_cron_expression DataQualityMonitor#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#timezone_id DataQualityMonitor#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function dataQualityMonitorDataProfilingConfigScheduleToTerraform(struct?: DataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigScheduleToHclTerraform(struct?: DataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable | undefined);
    get pauseStatus(): string;
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface DataQualityMonitorDataProfilingConfigSnapshot {
}
export declare function dataQualityMonitorDataProfilingConfigSnapshotToTerraform(struct?: DataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigSnapshotToHclTerraform(struct?: DataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigSnapshotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable | undefined);
}
export interface DataQualityMonitorDataProfilingConfigTimeSeries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#granularities DataQualityMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#timestamp_column DataQualityMonitor#timestamp_column}
    */
    readonly timestampColumn: string;
}
export declare function dataQualityMonitorDataProfilingConfigTimeSeriesToTerraform(struct?: DataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigTimeSeriesToHclTerraform(struct?: DataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigTimeSeriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _timestampColumn?;
    get timestampColumn(): string;
    set timestampColumn(value: string);
    get timestampColumnInput(): string | undefined;
}
export interface DataQualityMonitorDataProfilingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#assets_dir DataQualityMonitor#assets_dir}
    */
    readonly assetsDir?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#baseline_table_name DataQualityMonitor#baseline_table_name}
    */
    readonly baselineTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#custom_metrics DataQualityMonitor#custom_metrics}
    */
    readonly customMetrics?: DataQualityMonitorDataProfilingConfigCustomMetrics[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#inference_log DataQualityMonitor#inference_log}
    */
    readonly inferenceLog?: DataQualityMonitorDataProfilingConfigInferenceLog;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#notification_settings DataQualityMonitor#notification_settings}
    */
    readonly notificationSettings?: DataQualityMonitorDataProfilingConfigNotificationSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#output_schema_id DataQualityMonitor#output_schema_id}
    */
    readonly outputSchemaId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#schedule DataQualityMonitor#schedule}
    */
    readonly schedule?: DataQualityMonitorDataProfilingConfigSchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#skip_builtin_dashboard DataQualityMonitor#skip_builtin_dashboard}
    */
    readonly skipBuiltinDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#slicing_exprs DataQualityMonitor#slicing_exprs}
    */
    readonly slicingExprs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#snapshot DataQualityMonitor#snapshot}
    */
    readonly snapshot?: DataQualityMonitorDataProfilingConfigSnapshot;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#time_series DataQualityMonitor#time_series}
    */
    readonly timeSeries?: DataQualityMonitorDataProfilingConfigTimeSeries;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#warehouse_id DataQualityMonitor#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataQualityMonitorDataProfilingConfigToTerraform(struct?: DataQualityMonitorDataProfilingConfig | cdktn.IResolvable): any;
export declare function dataQualityMonitorDataProfilingConfigToHclTerraform(struct?: DataQualityMonitorDataProfilingConfig | cdktn.IResolvable): any;
export declare class DataQualityMonitorDataProfilingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorDataProfilingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorDataProfilingConfig | cdktn.IResolvable | undefined);
    private _assetsDir?;
    get assetsDir(): string;
    set assetsDir(value: string);
    resetAssetsDir(): void;
    get assetsDirInput(): string | undefined;
    private _baselineTableName?;
    get baselineTableName(): string;
    set baselineTableName(value: string);
    resetBaselineTableName(): void;
    get baselineTableNameInput(): string | undefined;
    private _customMetrics;
    get customMetrics(): DataQualityMonitorDataProfilingConfigCustomMetricsList;
    putCustomMetrics(value: DataQualityMonitorDataProfilingConfigCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfigCustomMetrics[] | undefined;
    get dashboardId(): string;
    get driftMetricsTableName(): string;
    get effectiveWarehouseId(): string;
    private _inferenceLog;
    get inferenceLog(): DataQualityMonitorDataProfilingConfigInferenceLogOutputReference;
    putInferenceLog(value: DataQualityMonitorDataProfilingConfigInferenceLog): void;
    resetInferenceLog(): void;
    get inferenceLogInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfigInferenceLog | undefined;
    get latestMonitorFailureMessage(): string;
    get monitorVersion(): number;
    get monitoredTableName(): string;
    private _notificationSettings;
    get notificationSettings(): DataQualityMonitorDataProfilingConfigNotificationSettingsOutputReference;
    putNotificationSettings(value: DataQualityMonitorDataProfilingConfigNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfigNotificationSettings | undefined;
    private _outputSchemaId?;
    get outputSchemaId(): string;
    set outputSchemaId(value: string);
    get outputSchemaIdInput(): string | undefined;
    get profileMetricsTableName(): string;
    private _schedule;
    get schedule(): DataQualityMonitorDataProfilingConfigScheduleOutputReference;
    putSchedule(value: DataQualityMonitorDataProfilingConfigSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfigSchedule | undefined;
    private _skipBuiltinDashboard?;
    get skipBuiltinDashboard(): boolean | cdktn.IResolvable;
    set skipBuiltinDashboard(value: boolean | cdktn.IResolvable);
    resetSkipBuiltinDashboard(): void;
    get skipBuiltinDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _slicingExprs?;
    get slicingExprs(): string[];
    set slicingExprs(value: string[]);
    resetSlicingExprs(): void;
    get slicingExprsInput(): string[] | undefined;
    private _snapshot;
    get snapshot(): DataQualityMonitorDataProfilingConfigSnapshotOutputReference;
    putSnapshot(value: DataQualityMonitorDataProfilingConfigSnapshot): void;
    resetSnapshot(): void;
    get snapshotInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfigSnapshot | undefined;
    get status(): string;
    private _timeSeries;
    get timeSeries(): DataQualityMonitorDataProfilingConfigTimeSeriesOutputReference;
    putTimeSeries(value: DataQualityMonitorDataProfilingConfigTimeSeries): void;
    resetTimeSeries(): void;
    get timeSeriesInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfigTimeSeries | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataQualityMonitorProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#workspace_id DataQualityMonitor#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataQualityMonitorProviderConfigToTerraform(struct?: DataQualityMonitorProviderConfig | cdktn.IResolvable): any;
export declare function dataQualityMonitorProviderConfigToHclTerraform(struct?: DataQualityMonitorProviderConfig | cdktn.IResolvable): any;
export declare class DataQualityMonitorProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityMonitorProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityMonitorProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor databricks_data_quality_monitor}
*/
export declare class DataQualityMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_data_quality_monitor";
    /**
    * Generates CDKTN code for importing a DataQualityMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataQualityMonitor to import
    * @param importFromId The id of the existing DataQualityMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataQualityMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/resources/data_quality_monitor databricks_data_quality_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataQualityMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DataQualityMonitorConfig);
    private _anomalyDetectionConfig;
    get anomalyDetectionConfig(): DataQualityMonitorAnomalyDetectionConfigOutputReference;
    putAnomalyDetectionConfig(value: DataQualityMonitorAnomalyDetectionConfig): void;
    resetAnomalyDetectionConfig(): void;
    get anomalyDetectionConfigInput(): cdktn.IResolvable | DataQualityMonitorAnomalyDetectionConfig | undefined;
    private _dataProfilingConfig;
    get dataProfilingConfig(): DataQualityMonitorDataProfilingConfigOutputReference;
    putDataProfilingConfig(value: DataQualityMonitorDataProfilingConfig): void;
    resetDataProfilingConfig(): void;
    get dataProfilingConfigInput(): cdktn.IResolvable | DataQualityMonitorDataProfilingConfig | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataQualityMonitorProviderConfigOutputReference;
    putProviderConfig(value: DataQualityMonitorProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataQualityMonitorProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
