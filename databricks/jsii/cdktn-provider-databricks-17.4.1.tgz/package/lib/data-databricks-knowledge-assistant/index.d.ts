/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksKnowledgeAssistantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistant#name DataDatabricksKnowledgeAssistant#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistant#provider_config DataDatabricksKnowledgeAssistant#provider_config}
    */
    readonly providerConfig?: DataDatabricksKnowledgeAssistantProviderConfig;
}
export interface DataDatabricksKnowledgeAssistantProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistant#workspace_id DataDatabricksKnowledgeAssistant#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksKnowledgeAssistantProviderConfigToTerraform(struct?: DataDatabricksKnowledgeAssistantProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksKnowledgeAssistantProviderConfigToHclTerraform(struct?: DataDatabricksKnowledgeAssistantProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksKnowledgeAssistantProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistant databricks_knowledge_assistant}
*/
export declare class DataDatabricksKnowledgeAssistant extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_knowledge_assistant";
    /**
    * Generates CDKTN code for importing a DataDatabricksKnowledgeAssistant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksKnowledgeAssistant to import
    * @param importFromId The id of the existing DataDatabricksKnowledgeAssistant that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksKnowledgeAssistant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.119.0/docs/data-sources/knowledge_assistant databricks_knowledge_assistant} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksKnowledgeAssistantConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksKnowledgeAssistantConfig);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get displayName(): string;
    get endpointName(): string;
    get errorInfo(): string;
    get experimentId(): string;
    get id(): string;
    get instructions(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksKnowledgeAssistantProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksKnowledgeAssistantProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksKnowledgeAssistantProviderConfig | undefined;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
