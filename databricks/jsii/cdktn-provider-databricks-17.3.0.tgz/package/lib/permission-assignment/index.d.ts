/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PermissionAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#group_name PermissionAssignment#group_name}
    */
    readonly groupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#id PermissionAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#permissions PermissionAssignment#permissions}
    */
    readonly permissions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#principal_id PermissionAssignment#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#service_principal_name PermissionAssignment#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#user_name PermissionAssignment#user_name}
    */
    readonly userName?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#provider_config PermissionAssignment#provider_config}
    */
    readonly providerConfig?: PermissionAssignmentProviderConfig;
}
export interface PermissionAssignmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#workspace_id PermissionAssignment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function permissionAssignmentProviderConfigToTerraform(struct?: PermissionAssignmentProviderConfigOutputReference | PermissionAssignmentProviderConfig): any;
export declare function permissionAssignmentProviderConfigToHclTerraform(struct?: PermissionAssignmentProviderConfigOutputReference | PermissionAssignmentProviderConfig): any;
export declare class PermissionAssignmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PermissionAssignmentProviderConfig | undefined;
    set internalValue(value: PermissionAssignmentProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment databricks_permission_assignment}
*/
export declare class PermissionAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_permission_assignment";
    /**
    * Generates CDKTN code for importing a PermissionAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PermissionAssignment to import
    * @param importFromId The id of the existing PermissionAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PermissionAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/permission_assignment databricks_permission_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PermissionAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: PermissionAssignmentConfig);
    get displayName(): string;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    get permissionsInput(): string[] | undefined;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PermissionAssignmentProviderConfigOutputReference;
    putProviderConfig(value: PermissionAssignmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): PermissionAssignmentProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
