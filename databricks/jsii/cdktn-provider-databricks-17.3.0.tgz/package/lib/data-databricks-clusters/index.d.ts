/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksClustersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#cluster_name_contains DataDatabricksClusters#cluster_name_contains}
    */
    readonly clusterNameContains?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#id DataDatabricksClusters#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#ids DataDatabricksClusters#ids}
    */
    readonly ids?: string[];
    /**
    * filter_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#filter_by DataDatabricksClusters#filter_by}
    */
    readonly filterBy?: DataDatabricksClustersFilterBy;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#provider_config DataDatabricksClusters#provider_config}
    */
    readonly providerConfig?: DataDatabricksClustersProviderConfig;
}
export interface DataDatabricksClustersFilterBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#cluster_sources DataDatabricksClusters#cluster_sources}
    */
    readonly clusterSources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#cluster_states DataDatabricksClusters#cluster_states}
    */
    readonly clusterStates?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#is_pinned DataDatabricksClusters#is_pinned}
    */
    readonly isPinned?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#policy_id DataDatabricksClusters#policy_id}
    */
    readonly policyId?: string;
}
export declare function dataDatabricksClustersFilterByToTerraform(struct?: DataDatabricksClustersFilterByOutputReference | DataDatabricksClustersFilterBy): any;
export declare function dataDatabricksClustersFilterByToHclTerraform(struct?: DataDatabricksClustersFilterByOutputReference | DataDatabricksClustersFilterBy): any;
export declare class DataDatabricksClustersFilterByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClustersFilterBy | undefined;
    set internalValue(value: DataDatabricksClustersFilterBy | undefined);
    private _clusterSources?;
    get clusterSources(): string[];
    set clusterSources(value: string[]);
    resetClusterSources(): void;
    get clusterSourcesInput(): string[] | undefined;
    private _clusterStates?;
    get clusterStates(): string[];
    set clusterStates(value: string[]);
    resetClusterStates(): void;
    get clusterStatesInput(): string[] | undefined;
    private _isPinned?;
    get isPinned(): boolean | cdktn.IResolvable;
    set isPinned(value: boolean | cdktn.IResolvable);
    resetIsPinned(): void;
    get isPinnedInput(): boolean | cdktn.IResolvable | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
}
export interface DataDatabricksClustersProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#workspace_id DataDatabricksClusters#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksClustersProviderConfigToTerraform(struct?: DataDatabricksClustersProviderConfigOutputReference | DataDatabricksClustersProviderConfig): any;
export declare function dataDatabricksClustersProviderConfigToHclTerraform(struct?: DataDatabricksClustersProviderConfigOutputReference | DataDatabricksClustersProviderConfig): any;
export declare class DataDatabricksClustersProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClustersProviderConfig | undefined;
    set internalValue(value: DataDatabricksClustersProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters databricks_clusters}
*/
export declare class DataDatabricksClusters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_clusters";
    /**
    * Generates CDKTN code for importing a DataDatabricksClusters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksClusters to import
    * @param importFromId The id of the existing DataDatabricksClusters that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksClusters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/clusters databricks_clusters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksClustersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksClustersConfig);
    private _clusterNameContains?;
    get clusterNameContains(): string;
    set clusterNameContains(value: string);
    resetClusterNameContains(): void;
    get clusterNameContainsInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _filterBy;
    get filterBy(): DataDatabricksClustersFilterByOutputReference;
    putFilterBy(value: DataDatabricksClustersFilterBy): void;
    resetFilterBy(): void;
    get filterByInput(): DataDatabricksClustersFilterBy | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksClustersProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksClustersProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksClustersProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
