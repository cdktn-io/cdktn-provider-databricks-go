/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClusterPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#definition ClusterPolicy#definition}
    */
    readonly definition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#description ClusterPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#id ClusterPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#max_clusters_per_user ClusterPolicy#max_clusters_per_user}
    */
    readonly maxClustersPerUser?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#name ClusterPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#policy_family_definition_overrides ClusterPolicy#policy_family_definition_overrides}
    */
    readonly policyFamilyDefinitionOverrides?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#policy_family_id ClusterPolicy#policy_family_id}
    */
    readonly policyFamilyId?: string;
    /**
    * libraries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#libraries ClusterPolicy#libraries}
    */
    readonly libraries?: ClusterPolicyLibraries[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#provider_config ClusterPolicy#provider_config}
    */
    readonly providerConfig?: ClusterPolicyProviderConfig;
}
export interface ClusterPolicyLibrariesCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#package ClusterPolicy#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#repo ClusterPolicy#repo}
    */
    readonly repo?: string;
}
export declare function clusterPolicyLibrariesCranToTerraform(struct?: ClusterPolicyLibrariesCranOutputReference | ClusterPolicyLibrariesCran): any;
export declare function clusterPolicyLibrariesCranToHclTerraform(struct?: ClusterPolicyLibrariesCranOutputReference | ClusterPolicyLibrariesCran): any;
export declare class ClusterPolicyLibrariesCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterPolicyLibrariesCran | undefined;
    set internalValue(value: ClusterPolicyLibrariesCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface ClusterPolicyLibrariesMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#coordinates ClusterPolicy#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#exclusions ClusterPolicy#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#repo ClusterPolicy#repo}
    */
    readonly repo?: string;
}
export declare function clusterPolicyLibrariesMavenToTerraform(struct?: ClusterPolicyLibrariesMavenOutputReference | ClusterPolicyLibrariesMaven): any;
export declare function clusterPolicyLibrariesMavenToHclTerraform(struct?: ClusterPolicyLibrariesMavenOutputReference | ClusterPolicyLibrariesMaven): any;
export declare class ClusterPolicyLibrariesMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterPolicyLibrariesMaven | undefined;
    set internalValue(value: ClusterPolicyLibrariesMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface ClusterPolicyLibrariesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#workspace_id ClusterPolicy#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function clusterPolicyLibrariesProviderConfigToTerraform(struct?: ClusterPolicyLibrariesProviderConfigOutputReference | ClusterPolicyLibrariesProviderConfig): any;
export declare function clusterPolicyLibrariesProviderConfigToHclTerraform(struct?: ClusterPolicyLibrariesProviderConfigOutputReference | ClusterPolicyLibrariesProviderConfig): any;
export declare class ClusterPolicyLibrariesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterPolicyLibrariesProviderConfig | undefined;
    set internalValue(value: ClusterPolicyLibrariesProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface ClusterPolicyLibrariesPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#package ClusterPolicy#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#repo ClusterPolicy#repo}
    */
    readonly repo?: string;
}
export declare function clusterPolicyLibrariesPypiToTerraform(struct?: ClusterPolicyLibrariesPypiOutputReference | ClusterPolicyLibrariesPypi): any;
export declare function clusterPolicyLibrariesPypiToHclTerraform(struct?: ClusterPolicyLibrariesPypiOutputReference | ClusterPolicyLibrariesPypi): any;
export declare class ClusterPolicyLibrariesPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterPolicyLibrariesPypi | undefined;
    set internalValue(value: ClusterPolicyLibrariesPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface ClusterPolicyLibraries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#egg ClusterPolicy#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#jar ClusterPolicy#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#requirements ClusterPolicy#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#whl ClusterPolicy#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#cran ClusterPolicy#cran}
    */
    readonly cran?: ClusterPolicyLibrariesCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#maven ClusterPolicy#maven}
    */
    readonly maven?: ClusterPolicyLibrariesMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#provider_config ClusterPolicy#provider_config}
    */
    readonly providerConfig?: ClusterPolicyLibrariesProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#pypi ClusterPolicy#pypi}
    */
    readonly pypi?: ClusterPolicyLibrariesPypi;
}
export declare function clusterPolicyLibrariesToTerraform(struct?: ClusterPolicyLibraries | cdktn.IResolvable): any;
export declare function clusterPolicyLibrariesToHclTerraform(struct?: ClusterPolicyLibraries | cdktn.IResolvable): any;
export declare class ClusterPolicyLibrariesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterPolicyLibraries | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterPolicyLibraries | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): ClusterPolicyLibrariesCranOutputReference;
    putCran(value: ClusterPolicyLibrariesCran): void;
    resetCran(): void;
    get cranInput(): ClusterPolicyLibrariesCran | undefined;
    private _maven;
    get maven(): ClusterPolicyLibrariesMavenOutputReference;
    putMaven(value: ClusterPolicyLibrariesMaven): void;
    resetMaven(): void;
    get mavenInput(): ClusterPolicyLibrariesMaven | undefined;
    private _providerConfig;
    get providerConfig(): ClusterPolicyLibrariesProviderConfigOutputReference;
    putProviderConfig(value: ClusterPolicyLibrariesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ClusterPolicyLibrariesProviderConfig | undefined;
    private _pypi;
    get pypi(): ClusterPolicyLibrariesPypiOutputReference;
    putPypi(value: ClusterPolicyLibrariesPypi): void;
    resetPypi(): void;
    get pypiInput(): ClusterPolicyLibrariesPypi | undefined;
}
export declare class ClusterPolicyLibrariesList extends cdktn.ComplexList {
    internalValue?: ClusterPolicyLibraries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterPolicyLibrariesOutputReference;
}
export interface ClusterPolicyProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#workspace_id ClusterPolicy#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function clusterPolicyProviderConfigToTerraform(struct?: ClusterPolicyProviderConfigOutputReference | ClusterPolicyProviderConfig): any;
export declare function clusterPolicyProviderConfigToHclTerraform(struct?: ClusterPolicyProviderConfigOutputReference | ClusterPolicyProviderConfig): any;
export declare class ClusterPolicyProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterPolicyProviderConfig | undefined;
    set internalValue(value: ClusterPolicyProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy databricks_cluster_policy}
*/
export declare class ClusterPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_cluster_policy";
    /**
    * Generates CDKTN code for importing a ClusterPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClusterPolicy to import
    * @param importFromId The id of the existing ClusterPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClusterPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/cluster_policy databricks_cluster_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClusterPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ClusterPolicyConfig);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    resetDefinition(): void;
    get definitionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxClustersPerUser?;
    get maxClustersPerUser(): number;
    set maxClustersPerUser(value: number);
    resetMaxClustersPerUser(): void;
    get maxClustersPerUserInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _policyFamilyDefinitionOverrides?;
    get policyFamilyDefinitionOverrides(): string;
    set policyFamilyDefinitionOverrides(value: string);
    resetPolicyFamilyDefinitionOverrides(): void;
    get policyFamilyDefinitionOverridesInput(): string | undefined;
    private _policyFamilyId?;
    get policyFamilyId(): string;
    set policyFamilyId(value: string);
    resetPolicyFamilyId(): void;
    get policyFamilyIdInput(): string | undefined;
    get policyId(): string;
    private _libraries;
    get libraries(): ClusterPolicyLibrariesList;
    putLibraries(value: ClusterPolicyLibraries[] | cdktn.IResolvable): void;
    resetLibraries(): void;
    get librariesInput(): cdktn.IResolvable | ClusterPolicyLibraries[] | undefined;
    private _providerConfig;
    get providerConfig(): ClusterPolicyProviderConfigOutputReference;
    putProviderConfig(value: ClusterPolicyProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ClusterPolicyProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
