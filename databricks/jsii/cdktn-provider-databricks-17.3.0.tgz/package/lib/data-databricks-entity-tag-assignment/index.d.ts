/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksEntityTagAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment#entity_name DataDatabricksEntityTagAssignment#entity_name}
    */
    readonly entityName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment#entity_type DataDatabricksEntityTagAssignment#entity_type}
    */
    readonly entityType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment#provider_config DataDatabricksEntityTagAssignment#provider_config}
    */
    readonly providerConfig?: DataDatabricksEntityTagAssignmentProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment#tag_key DataDatabricksEntityTagAssignment#tag_key}
    */
    readonly tagKey: string;
}
export interface DataDatabricksEntityTagAssignmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment#workspace_id DataDatabricksEntityTagAssignment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksEntityTagAssignmentProviderConfigToTerraform(struct?: DataDatabricksEntityTagAssignmentProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksEntityTagAssignmentProviderConfigToHclTerraform(struct?: DataDatabricksEntityTagAssignmentProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksEntityTagAssignmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEntityTagAssignmentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksEntityTagAssignmentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment databricks_entity_tag_assignment}
*/
export declare class DataDatabricksEntityTagAssignment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_entity_tag_assignment";
    /**
    * Generates CDKTN code for importing a DataDatabricksEntityTagAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksEntityTagAssignment to import
    * @param importFromId The id of the existing DataDatabricksEntityTagAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksEntityTagAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/entity_tag_assignment databricks_entity_tag_assignment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksEntityTagAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksEntityTagAssignmentConfig);
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    get entityNameInput(): string | undefined;
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    get entityTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksEntityTagAssignmentProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksEntityTagAssignmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksEntityTagAssignmentProviderConfig | undefined;
    get sourceType(): string;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    get tagValue(): string;
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
