/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#backend_type SecretScope#backend_type}
    */
    readonly backendType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#id SecretScope#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#initial_manage_principal SecretScope#initial_manage_principal}
    */
    readonly initialManagePrincipal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#name SecretScope#name}
    */
    readonly name: string;
    /**
    * keyvault_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#keyvault_metadata SecretScope#keyvault_metadata}
    */
    readonly keyvaultMetadata?: SecretScopeKeyvaultMetadata;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#provider_config SecretScope#provider_config}
    */
    readonly providerConfig?: SecretScopeProviderConfig;
}
export interface SecretScopeKeyvaultMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#dns_name SecretScope#dns_name}
    */
    readonly dnsName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#resource_id SecretScope#resource_id}
    */
    readonly resourceId: string;
}
export declare function secretScopeKeyvaultMetadataToTerraform(struct?: SecretScopeKeyvaultMetadataOutputReference | SecretScopeKeyvaultMetadata): any;
export declare function secretScopeKeyvaultMetadataToHclTerraform(struct?: SecretScopeKeyvaultMetadataOutputReference | SecretScopeKeyvaultMetadata): any;
export declare class SecretScopeKeyvaultMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecretScopeKeyvaultMetadata | undefined;
    set internalValue(value: SecretScopeKeyvaultMetadata | undefined);
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    get dnsNameInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
}
export interface SecretScopeProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#workspace_id SecretScope#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function secretScopeProviderConfigToTerraform(struct?: SecretScopeProviderConfigOutputReference | SecretScopeProviderConfig): any;
export declare function secretScopeProviderConfigToHclTerraform(struct?: SecretScopeProviderConfigOutputReference | SecretScopeProviderConfig): any;
export declare class SecretScopeProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecretScopeProviderConfig | undefined;
    set internalValue(value: SecretScopeProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope databricks_secret_scope}
*/
export declare class SecretScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_secret_scope";
    /**
    * Generates CDKTN code for importing a SecretScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretScope to import
    * @param importFromId The id of the existing SecretScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/secret_scope databricks_secret_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretScopeConfig
    */
    constructor(scope: Construct, id: string, config: SecretScopeConfig);
    private _backendType?;
    get backendType(): string;
    set backendType(value: string);
    resetBackendType(): void;
    get backendTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialManagePrincipal?;
    get initialManagePrincipal(): string;
    set initialManagePrincipal(value: string);
    resetInitialManagePrincipal(): void;
    get initialManagePrincipalInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _keyvaultMetadata;
    get keyvaultMetadata(): SecretScopeKeyvaultMetadataOutputReference;
    putKeyvaultMetadata(value: SecretScopeKeyvaultMetadata): void;
    resetKeyvaultMetadata(): void;
    get keyvaultMetadataInput(): SecretScopeKeyvaultMetadata | undefined;
    private _providerConfig;
    get providerConfig(): SecretScopeProviderConfigOutputReference;
    putProviderConfig(value: SecretScopeProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SecretScopeProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
