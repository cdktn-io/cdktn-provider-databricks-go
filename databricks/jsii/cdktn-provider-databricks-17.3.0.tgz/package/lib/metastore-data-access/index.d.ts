/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MetastoreDataAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#api MetastoreDataAccess#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#comment MetastoreDataAccess#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#force_destroy MetastoreDataAccess#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#force_update MetastoreDataAccess#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#id MetastoreDataAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#is_default MetastoreDataAccess#is_default}
    */
    readonly isDefault?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#isolation_mode MetastoreDataAccess#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#metastore_id MetastoreDataAccess#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#name MetastoreDataAccess#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#owner MetastoreDataAccess#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#read_only MetastoreDataAccess#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#skip_validation MetastoreDataAccess#skip_validation}
    */
    readonly skipValidation?: boolean | cdktn.IResolvable;
    /**
    * aws_iam_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#aws_iam_role MetastoreDataAccess#aws_iam_role}
    */
    readonly awsIamRole?: MetastoreDataAccessAwsIamRole;
    /**
    * azure_managed_identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#azure_managed_identity MetastoreDataAccess#azure_managed_identity}
    */
    readonly azureManagedIdentity?: MetastoreDataAccessAzureManagedIdentity;
    /**
    * azure_service_principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#azure_service_principal MetastoreDataAccess#azure_service_principal}
    */
    readonly azureServicePrincipal?: MetastoreDataAccessAzureServicePrincipal;
    /**
    * cloudflare_api_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#cloudflare_api_token MetastoreDataAccess#cloudflare_api_token}
    */
    readonly cloudflareApiToken?: MetastoreDataAccessCloudflareApiToken;
    /**
    * databricks_gcp_service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#databricks_gcp_service_account MetastoreDataAccess#databricks_gcp_service_account}
    */
    readonly databricksGcpServiceAccount?: MetastoreDataAccessDatabricksGcpServiceAccount;
    /**
    * gcp_service_account_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#gcp_service_account_key MetastoreDataAccess#gcp_service_account_key}
    */
    readonly gcpServiceAccountKey?: MetastoreDataAccessGcpServiceAccountKey;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#provider_config MetastoreDataAccess#provider_config}
    */
    readonly providerConfig?: MetastoreDataAccessProviderConfig;
}
export interface MetastoreDataAccessAwsIamRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#external_id MetastoreDataAccess#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#role_arn MetastoreDataAccess#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#unity_catalog_iam_arn MetastoreDataAccess#unity_catalog_iam_arn}
    */
    readonly unityCatalogIamArn?: string;
}
export declare function metastoreDataAccessAwsIamRoleToTerraform(struct?: MetastoreDataAccessAwsIamRoleOutputReference | MetastoreDataAccessAwsIamRole): any;
export declare function metastoreDataAccessAwsIamRoleToHclTerraform(struct?: MetastoreDataAccessAwsIamRoleOutputReference | MetastoreDataAccessAwsIamRole): any;
export declare class MetastoreDataAccessAwsIamRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreDataAccessAwsIamRole | undefined;
    set internalValue(value: MetastoreDataAccessAwsIamRole | undefined);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _unityCatalogIamArn?;
    get unityCatalogIamArn(): string;
    set unityCatalogIamArn(value: string);
    resetUnityCatalogIamArn(): void;
    get unityCatalogIamArnInput(): string | undefined;
}
export interface MetastoreDataAccessAzureManagedIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#access_connector_id MetastoreDataAccess#access_connector_id}
    */
    readonly accessConnectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#credential_id MetastoreDataAccess#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#managed_identity_id MetastoreDataAccess#managed_identity_id}
    */
    readonly managedIdentityId?: string;
}
export declare function metastoreDataAccessAzureManagedIdentityToTerraform(struct?: MetastoreDataAccessAzureManagedIdentityOutputReference | MetastoreDataAccessAzureManagedIdentity): any;
export declare function metastoreDataAccessAzureManagedIdentityToHclTerraform(struct?: MetastoreDataAccessAzureManagedIdentityOutputReference | MetastoreDataAccessAzureManagedIdentity): any;
export declare class MetastoreDataAccessAzureManagedIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreDataAccessAzureManagedIdentity | undefined;
    set internalValue(value: MetastoreDataAccessAzureManagedIdentity | undefined);
    private _accessConnectorId?;
    get accessConnectorId(): string;
    set accessConnectorId(value: string);
    get accessConnectorIdInput(): string | undefined;
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _managedIdentityId?;
    get managedIdentityId(): string;
    set managedIdentityId(value: string);
    resetManagedIdentityId(): void;
    get managedIdentityIdInput(): string | undefined;
}
export interface MetastoreDataAccessAzureServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#application_id MetastoreDataAccess#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#client_secret MetastoreDataAccess#client_secret}
    */
    readonly clientSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#directory_id MetastoreDataAccess#directory_id}
    */
    readonly directoryId: string;
}
export declare function metastoreDataAccessAzureServicePrincipalToTerraform(struct?: MetastoreDataAccessAzureServicePrincipalOutputReference | MetastoreDataAccessAzureServicePrincipal): any;
export declare function metastoreDataAccessAzureServicePrincipalToHclTerraform(struct?: MetastoreDataAccessAzureServicePrincipalOutputReference | MetastoreDataAccessAzureServicePrincipal): any;
export declare class MetastoreDataAccessAzureServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreDataAccessAzureServicePrincipal | undefined;
    set internalValue(value: MetastoreDataAccessAzureServicePrincipal | undefined);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
}
export interface MetastoreDataAccessCloudflareApiToken {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#access_key_id MetastoreDataAccess#access_key_id}
    */
    readonly accessKeyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#account_id MetastoreDataAccess#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#secret_access_key MetastoreDataAccess#secret_access_key}
    */
    readonly secretAccessKey: string;
}
export declare function metastoreDataAccessCloudflareApiTokenToTerraform(struct?: MetastoreDataAccessCloudflareApiTokenOutputReference | MetastoreDataAccessCloudflareApiToken): any;
export declare function metastoreDataAccessCloudflareApiTokenToHclTerraform(struct?: MetastoreDataAccessCloudflareApiTokenOutputReference | MetastoreDataAccessCloudflareApiToken): any;
export declare class MetastoreDataAccessCloudflareApiTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreDataAccessCloudflareApiToken | undefined;
    set internalValue(value: MetastoreDataAccessCloudflareApiToken | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    get accessKeyIdInput(): string | undefined;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    get secretAccessKeyInput(): string | undefined;
}
export interface MetastoreDataAccessDatabricksGcpServiceAccount {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#credential_id MetastoreDataAccess#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#email MetastoreDataAccess#email}
    */
    readonly email?: string;
}
export declare function metastoreDataAccessDatabricksGcpServiceAccountToTerraform(struct?: MetastoreDataAccessDatabricksGcpServiceAccountOutputReference | MetastoreDataAccessDatabricksGcpServiceAccount): any;
export declare function metastoreDataAccessDatabricksGcpServiceAccountToHclTerraform(struct?: MetastoreDataAccessDatabricksGcpServiceAccountOutputReference | MetastoreDataAccessDatabricksGcpServiceAccount): any;
export declare class MetastoreDataAccessDatabricksGcpServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreDataAccessDatabricksGcpServiceAccount | undefined;
    set internalValue(value: MetastoreDataAccessDatabricksGcpServiceAccount | undefined);
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface MetastoreDataAccessGcpServiceAccountKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#email MetastoreDataAccess#email}
    */
    readonly email: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#private_key MetastoreDataAccess#private_key}
    */
    readonly privateKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#private_key_id MetastoreDataAccess#private_key_id}
    */
    readonly privateKeyId: string;
}
export declare function metastoreDataAccessGcpServiceAccountKeyToTerraform(struct?: MetastoreDataAccessGcpServiceAccountKeyOutputReference | MetastoreDataAccessGcpServiceAccountKey): any;
export declare function metastoreDataAccessGcpServiceAccountKeyToHclTerraform(struct?: MetastoreDataAccessGcpServiceAccountKeyOutputReference | MetastoreDataAccessGcpServiceAccountKey): any;
export declare class MetastoreDataAccessGcpServiceAccountKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreDataAccessGcpServiceAccountKey | undefined;
    set internalValue(value: MetastoreDataAccessGcpServiceAccountKey | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _privateKeyId?;
    get privateKeyId(): string;
    set privateKeyId(value: string);
    get privateKeyIdInput(): string | undefined;
}
export interface MetastoreDataAccessProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#workspace_id MetastoreDataAccess#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function metastoreDataAccessProviderConfigToTerraform(struct?: MetastoreDataAccessProviderConfigOutputReference | MetastoreDataAccessProviderConfig): any;
export declare function metastoreDataAccessProviderConfigToHclTerraform(struct?: MetastoreDataAccessProviderConfigOutputReference | MetastoreDataAccessProviderConfig): any;
export declare class MetastoreDataAccessProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreDataAccessProviderConfig | undefined;
    set internalValue(value: MetastoreDataAccessProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access databricks_metastore_data_access}
*/
export declare class MetastoreDataAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_metastore_data_access";
    /**
    * Generates CDKTN code for importing a MetastoreDataAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MetastoreDataAccess to import
    * @param importFromId The id of the existing MetastoreDataAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MetastoreDataAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/metastore_data_access databricks_metastore_data_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MetastoreDataAccessConfig
    */
    constructor(scope: Construct, id: string, config: MetastoreDataAccessConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isDefault?;
    get isDefault(): boolean | cdktn.IResolvable;
    set isDefault(value: boolean | cdktn.IResolvable);
    resetIsDefault(): void;
    get isDefaultInput(): boolean | cdktn.IResolvable | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _skipValidation?;
    get skipValidation(): boolean | cdktn.IResolvable;
    set skipValidation(value: boolean | cdktn.IResolvable);
    resetSkipValidation(): void;
    get skipValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _awsIamRole;
    get awsIamRole(): MetastoreDataAccessAwsIamRoleOutputReference;
    putAwsIamRole(value: MetastoreDataAccessAwsIamRole): void;
    resetAwsIamRole(): void;
    get awsIamRoleInput(): MetastoreDataAccessAwsIamRole | undefined;
    private _azureManagedIdentity;
    get azureManagedIdentity(): MetastoreDataAccessAzureManagedIdentityOutputReference;
    putAzureManagedIdentity(value: MetastoreDataAccessAzureManagedIdentity): void;
    resetAzureManagedIdentity(): void;
    get azureManagedIdentityInput(): MetastoreDataAccessAzureManagedIdentity | undefined;
    private _azureServicePrincipal;
    get azureServicePrincipal(): MetastoreDataAccessAzureServicePrincipalOutputReference;
    putAzureServicePrincipal(value: MetastoreDataAccessAzureServicePrincipal): void;
    resetAzureServicePrincipal(): void;
    get azureServicePrincipalInput(): MetastoreDataAccessAzureServicePrincipal | undefined;
    private _cloudflareApiToken;
    get cloudflareApiToken(): MetastoreDataAccessCloudflareApiTokenOutputReference;
    putCloudflareApiToken(value: MetastoreDataAccessCloudflareApiToken): void;
    resetCloudflareApiToken(): void;
    get cloudflareApiTokenInput(): MetastoreDataAccessCloudflareApiToken | undefined;
    private _databricksGcpServiceAccount;
    get databricksGcpServiceAccount(): MetastoreDataAccessDatabricksGcpServiceAccountOutputReference;
    putDatabricksGcpServiceAccount(value: MetastoreDataAccessDatabricksGcpServiceAccount): void;
    resetDatabricksGcpServiceAccount(): void;
    get databricksGcpServiceAccountInput(): MetastoreDataAccessDatabricksGcpServiceAccount | undefined;
    private _gcpServiceAccountKey;
    get gcpServiceAccountKey(): MetastoreDataAccessGcpServiceAccountKeyOutputReference;
    putGcpServiceAccountKey(value: MetastoreDataAccessGcpServiceAccountKey): void;
    resetGcpServiceAccountKey(): void;
    get gcpServiceAccountKeyInput(): MetastoreDataAccessGcpServiceAccountKey | undefined;
    private _providerConfig;
    get providerConfig(): MetastoreDataAccessProviderConfigOutputReference;
    putProviderConfig(value: MetastoreDataAccessProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): MetastoreDataAccessProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
