/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess, DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference, DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess, DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessOutputReference, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessOutputReference } from './structs0';
export interface DataDatabricksAccountNetworkPolicyIngressDryRun {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/account_network_policy#cross_workspace_access DataDatabricksAccountNetworkPolicy#cross_workspace_access}
    */
    readonly crossWorkspaceAccess?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/account_network_policy#private_access DataDatabricksAccountNetworkPolicy#private_access}
    */
    readonly privateAccess?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/account_network_policy#public_access DataDatabricksAccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRun): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRun): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRun | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRun | undefined);
    private _crossWorkspaceAccess;
    get crossWorkspaceAccess(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference;
    putCrossWorkspaceAccess(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess): void;
    resetCrossWorkspaceAccess(): void;
    get crossWorkspaceAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | undefined;
    private _privateAccess;
    get privateAccess(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessOutputReference;
    putPrivateAccess(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessOutputReference;
    putPublicAccess(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess | undefined;
}
