/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess, AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference, AccountNetworkPolicyIngressDryRunPrivateAccess, AccountNetworkPolicyIngressDryRunPrivateAccessOutputReference, AccountNetworkPolicyIngressDryRunPublicAccess, AccountNetworkPolicyIngressDryRunPublicAccessOutputReference } from './structs0';
export interface AccountNetworkPolicyIngressDryRun {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/account_network_policy#cross_workspace_access AccountNetworkPolicy#cross_workspace_access}
    */
    readonly crossWorkspaceAccess?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/account_network_policy#private_access AccountNetworkPolicy#private_access}
    */
    readonly privateAccess?: AccountNetworkPolicyIngressDryRunPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/account_network_policy#public_access AccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: AccountNetworkPolicyIngressDryRunPublicAccess;
}
export declare function accountNetworkPolicyIngressDryRunToTerraform(struct?: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunToHclTerraform(struct?: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRun | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable | undefined);
    private _crossWorkspaceAccess;
    get crossWorkspaceAccess(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference;
    putCrossWorkspaceAccess(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess): void;
    resetCrossWorkspaceAccess(): void;
    get crossWorkspaceAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | undefined;
    private _privateAccess;
    get privateAccess(): AccountNetworkPolicyIngressDryRunPrivateAccessOutputReference;
    putPrivateAccess(value: AccountNetworkPolicyIngressDryRunPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): AccountNetworkPolicyIngressDryRunPublicAccessOutputReference;
    putPublicAccess(value: AccountNetworkPolicyIngressDryRunPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccess | undefined;
}
