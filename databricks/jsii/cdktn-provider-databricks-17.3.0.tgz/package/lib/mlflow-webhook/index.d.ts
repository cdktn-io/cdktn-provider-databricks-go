/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MlflowWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#description MlflowWebhook#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#events MlflowWebhook#events}
    */
    readonly events: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#id MlflowWebhook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#model_name MlflowWebhook#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#status MlflowWebhook#status}
    */
    readonly status?: string;
    /**
    * http_url_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#http_url_spec MlflowWebhook#http_url_spec}
    */
    readonly httpUrlSpec?: MlflowWebhookHttpUrlSpec;
    /**
    * job_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#job_spec MlflowWebhook#job_spec}
    */
    readonly jobSpec?: MlflowWebhookJobSpec;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#provider_config MlflowWebhook#provider_config}
    */
    readonly providerConfig?: MlflowWebhookProviderConfig;
}
export interface MlflowWebhookHttpUrlSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#authorization MlflowWebhook#authorization}
    */
    readonly authorization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#enable_ssl_verification MlflowWebhook#enable_ssl_verification}
    */
    readonly enableSslVerification?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#secret MlflowWebhook#secret}
    */
    readonly secret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#url MlflowWebhook#url}
    */
    readonly url: string;
}
export declare function mlflowWebhookHttpUrlSpecToTerraform(struct?: MlflowWebhookHttpUrlSpecOutputReference | MlflowWebhookHttpUrlSpec): any;
export declare function mlflowWebhookHttpUrlSpecToHclTerraform(struct?: MlflowWebhookHttpUrlSpecOutputReference | MlflowWebhookHttpUrlSpec): any;
export declare class MlflowWebhookHttpUrlSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MlflowWebhookHttpUrlSpec | undefined;
    set internalValue(value: MlflowWebhookHttpUrlSpec | undefined);
    private _authorization?;
    get authorization(): string;
    set authorization(value: string);
    resetAuthorization(): void;
    get authorizationInput(): string | undefined;
    private _enableSslVerification?;
    get enableSslVerification(): boolean | cdktn.IResolvable;
    set enableSslVerification(value: boolean | cdktn.IResolvable);
    resetEnableSslVerification(): void;
    get enableSslVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    resetSecret(): void;
    get secretInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface MlflowWebhookJobSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#access_token MlflowWebhook#access_token}
    */
    readonly accessToken: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#job_id MlflowWebhook#job_id}
    */
    readonly jobId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#workspace_url MlflowWebhook#workspace_url}
    */
    readonly workspaceUrl?: string;
}
export declare function mlflowWebhookJobSpecToTerraform(struct?: MlflowWebhookJobSpecOutputReference | MlflowWebhookJobSpec): any;
export declare function mlflowWebhookJobSpecToHclTerraform(struct?: MlflowWebhookJobSpecOutputReference | MlflowWebhookJobSpec): any;
export declare class MlflowWebhookJobSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MlflowWebhookJobSpec | undefined;
    set internalValue(value: MlflowWebhookJobSpec | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    get accessTokenInput(): string | undefined;
    private _jobId?;
    get jobId(): string;
    set jobId(value: string);
    get jobIdInput(): string | undefined;
    private _workspaceUrl?;
    get workspaceUrl(): string;
    set workspaceUrl(value: string);
    resetWorkspaceUrl(): void;
    get workspaceUrlInput(): string | undefined;
}
export interface MlflowWebhookProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#workspace_id MlflowWebhook#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function mlflowWebhookProviderConfigToTerraform(struct?: MlflowWebhookProviderConfigOutputReference | MlflowWebhookProviderConfig): any;
export declare function mlflowWebhookProviderConfigToHclTerraform(struct?: MlflowWebhookProviderConfigOutputReference | MlflowWebhookProviderConfig): any;
export declare class MlflowWebhookProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MlflowWebhookProviderConfig | undefined;
    set internalValue(value: MlflowWebhookProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook databricks_mlflow_webhook}
*/
export declare class MlflowWebhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mlflow_webhook";
    /**
    * Generates CDKTN code for importing a MlflowWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MlflowWebhook to import
    * @param importFromId The id of the existing MlflowWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MlflowWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/resources/mlflow_webhook databricks_mlflow_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MlflowWebhookConfig
    */
    constructor(scope: Construct, id: string, config: MlflowWebhookConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _events?;
    get events(): string[];
    set events(value: string[]);
    get eventsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _httpUrlSpec;
    get httpUrlSpec(): MlflowWebhookHttpUrlSpecOutputReference;
    putHttpUrlSpec(value: MlflowWebhookHttpUrlSpec): void;
    resetHttpUrlSpec(): void;
    get httpUrlSpecInput(): MlflowWebhookHttpUrlSpec | undefined;
    private _jobSpec;
    get jobSpec(): MlflowWebhookJobSpecOutputReference;
    putJobSpec(value: MlflowWebhookJobSpec): void;
    resetJobSpec(): void;
    get jobSpecInput(): MlflowWebhookJobSpec | undefined;
    private _providerConfig;
    get providerConfig(): MlflowWebhookProviderConfigOutputReference;
    putProviderConfig(value: MlflowWebhookProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): MlflowWebhookProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
