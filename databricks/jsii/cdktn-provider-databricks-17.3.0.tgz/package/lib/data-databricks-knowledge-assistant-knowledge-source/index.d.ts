/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksKnowledgeAssistantKnowledgeSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#name DataDatabricksKnowledgeAssistantKnowledgeSource#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#provider_config DataDatabricksKnowledgeAssistantKnowledgeSource#provider_config}
    */
    readonly providerConfig?: DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourceFileTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#file_col DataDatabricksKnowledgeAssistantKnowledgeSource#file_col}
    */
    readonly fileCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#table_name DataDatabricksKnowledgeAssistantKnowledgeSource#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceFileTableToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceFileTable): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceFileTableToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceFileTable): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourceFileTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourceFileTable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourceFileTable | undefined);
    private _fileCol?;
    get fileCol(): string;
    set fileCol(value: string);
    get fileColInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourceFiles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#path DataDatabricksKnowledgeAssistantKnowledgeSource#path}
    */
    readonly path: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceFilesToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceFiles): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceFilesToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceFiles): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourceFilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourceFiles | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourceFiles | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourceIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#doc_uri_col DataDatabricksKnowledgeAssistantKnowledgeSource#doc_uri_col}
    */
    readonly docUriCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#index_name DataDatabricksKnowledgeAssistantKnowledgeSource#index_name}
    */
    readonly indexName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#text_col DataDatabricksKnowledgeAssistantKnowledgeSource#text_col}
    */
    readonly textCol: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceIndexToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceIndex): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceIndexToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceIndex): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourceIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourceIndex | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourceIndex | undefined);
    private _docUriCol?;
    get docUriCol(): string;
    set docUriCol(value: string);
    get docUriColInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _textCol?;
    get textCol(): string;
    set textCol(value: string);
    get textColInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#workspace_id DataDatabricksKnowledgeAssistantKnowledgeSource#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfigToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfigToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source databricks_knowledge_assistant_knowledge_source}
*/
export declare class DataDatabricksKnowledgeAssistantKnowledgeSource extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_knowledge_assistant_knowledge_source";
    /**
    * Generates CDKTN code for importing a DataDatabricksKnowledgeAssistantKnowledgeSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksKnowledgeAssistantKnowledgeSource to import
    * @param importFromId The id of the existing DataDatabricksKnowledgeAssistantKnowledgeSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksKnowledgeAssistantKnowledgeSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.117.0/docs/data-sources/knowledge_assistant_knowledge_source databricks_knowledge_assistant_knowledge_source} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksKnowledgeAssistantKnowledgeSourceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksKnowledgeAssistantKnowledgeSourceConfig);
    get createTime(): string;
    get description(): string;
    get displayName(): string;
    private _fileTable;
    get fileTable(): DataDatabricksKnowledgeAssistantKnowledgeSourceFileTableOutputReference;
    private _files;
    get files(): DataDatabricksKnowledgeAssistantKnowledgeSourceFilesOutputReference;
    get id(): string;
    private _index;
    get index(): DataDatabricksKnowledgeAssistantKnowledgeSourceIndexOutputReference;
    get knowledgeCutoffTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksKnowledgeAssistantKnowledgeSourceProviderConfig | undefined;
    get sourceType(): string;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
